import Layout from '@/Layout/Layout'

function Attendance() {
  return (
    <Layout>Attendance</Layout>
  )
}

export default Attendance