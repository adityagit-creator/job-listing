import React, { useEffect, useState } from 'react';
import Layout from '@/Layout/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  FaBriefcase,
  FaGraduationCap,
  FaChartLine,
  FaUsers,
  FaBuilding,
  FaRupeeSign,
  FaUserGraduate,
  FaCalendarCheck,
} from 'react-icons/fa';
import { useNavigate } from 'react-router-dom';
import { usePlacement } from '@/hooks/usePlacement';
import { PlacementStats } from '@/types/placement';

const Home = () => {
  const navigate = useNavigate();
  const { fetchPlacementStats } = usePlacement();
  const [stats, setStats] = useState<PlacementStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadStats = async () => {
      try {
        const currentYear = new Date().getFullYear();
        const data = await fetchPlacementStats(currentYear);
        setStats(data);
      } catch (error) {
        console.error('Error loading stats:', error);
      } finally {
        setLoading(false);
      }
    };
    loadStats();
  }, []);

  const quickActions = [
    {
      title: 'Student Management',
      icon: FaUsers,
      path: '/coordinator/student-management',
      color: 'bg-blue-500',
    },
    {
      title: 'Company Management',
      icon: FaBuilding,
      path: '/coordinator/job-management',
      color: 'bg-purple-500',
    },
    {
      title: 'Schedule Assessment',
      icon: FaCalendarCheck,
      path: '/coordinator/assessment-scheduling',
      color: 'bg-green-500',
    },
  ];

  if (loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-screen">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-8">
        {/* Header Section */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">Training & Placement Dashboard</h1>
            <p className="text-gray-600 mt-1">Overview of placement activities and statistics</p>
          </div>
          <div className="flex space-x-4">
            <Button onClick={() => navigate('/coordinator/reports')}>
              <FaChartLine className="mr-2" /> View Reports
            </Button>
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="hover:shadow-lg transition-shadow">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Placement Rate</p>
                  <h3 className="text-2xl font-bold mt-1">
                    {stats ? ((stats.placedStudents / stats.totalStudents) * 100).toFixed(1) : 0}%
                  </h3>
                  <p className="text-xs text-green-600 mt-1">+5% from last year</p>
                </div>
                <div className="bg-blue-100 p-3 rounded-full">
                  <FaGraduationCap className="h-6 w-6 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Placed Students</p>
                  <h3 className="text-2xl font-bold mt-1">{stats?.placedStudents || 0}</h3>
                  <p className="text-xs text-gray-600 mt-1">
                    out of {stats?.totalStudents || 0} eligible
                  </p>
                </div>
                <div className="bg-purple-100 p-3 rounded-full">
                  <FaUserGraduate className="h-6 w-6 text-purple-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Average Package</p>
                  <h3 className="text-2xl font-bold mt-1">₹8.5 LPA</h3>
                  <p className="text-xs text-green-600 mt-1">+1.2 LPA from last year</p>
                </div>
                <div className="bg-green-100 p-3 rounded-full">
                  <FaRupeeSign className="h-6 w-6 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Companies Visited</p>
                  <h3 className="text-2xl font-bold mt-1">42</h3>
                  <p className="text-xs text-green-600 mt-1">8 scheduled this month</p>
                </div>
                <div className="bg-orange-100 p-3 rounded-full">
                  <FaBriefcase className="h-6 w-6 text-orange-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {quickActions.map((action) => (
            <Card
              key={action.title}
              className="hover:shadow-lg transition-all cursor-pointer group"
              onClick={() => navigate(action.path)}
            >
              <CardContent className="p-6">
                <div className="flex items-center space-x-4">
                  <div className={`${action.color} p-4 rounded-lg text-white`}>
                    <action.icon className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="font-semibold group-hover:text-indigo-600 transition-colors">
                      {action.title}
                    </h3>
                    <p className="text-sm text-gray-600 mt-1">Manage and track progress</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Branch-wise Statistics */}
        <Card>
          <CardHeader>
            <CardTitle>Branch-wise Placement Statistics</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {stats?.branchWiseStats && Object.entries(stats.branchWiseStats).map(([branch, data]) => (
                <div key={branch} className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium">{branch}</span>
                      <span className="text-sm text-gray-600">
                        {((data.placed / data.total) * 100).toFixed(1)}%
                      </span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div
                        className="bg-indigo-600 h-2 rounded-full"
                        style={{ width: `${(data.placed / data.total) * 100}%` }}
                      />
                    </div>
                    <div className="flex justify-between mt-1 text-xs text-gray-500">
                      <span>{data.placed} placed</span>
                      <span>₹{data.averagePackage.toFixed(1)} LPA avg.</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Recent Activities */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Activities</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start space-x-4">
                <div className="bg-blue-100 p-2 rounded-full">
                  <FaBriefcase className="h-4 w-4 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm font-medium">Google scheduled campus drive</p>
                  <p className="text-xs text-gray-600">2 hours ago</p>
                </div>
              </div>
              <div className="flex items-start space-x-4">
                <div className="bg-green-100 p-2 rounded-full">
                  <FaUserGraduate className="h-4 w-4 text-green-600" />
                </div>
                <div>
                  <p className="text-sm font-medium">15 students placed at Microsoft</p>
                  <p className="text-xs text-gray-600">1 day ago</p>
                </div>
              </div>
              <div className="flex items-start space-x-4">
                <div className="bg-purple-100 p-2 rounded-full">
                  <FaCalendarCheck className="h-4 w-4 text-purple-600" />
                </div>
                <div>
                  <p className="text-sm font-medium">Amazon assessment scheduled</p>
                  <p className="text-xs text-gray-600">2 days ago</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
};

export default Home;