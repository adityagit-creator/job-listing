import Layout from '@/Layout/Layout'

function ManageGrades() {
  return (
    <Layout>ManageGrades</Layout>
  )
}

export default ManageGrades