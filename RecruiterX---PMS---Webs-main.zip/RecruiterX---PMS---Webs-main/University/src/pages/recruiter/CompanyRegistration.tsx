import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { toast } from 'react-hot-toast';
import { companyRegistrationSchema } from '@/lib/validations/placement';
import type { z } from 'zod';
import { FaBuilding, FaUpload } from 'react-icons/fa';
import usePlacement from '@/hooks/usePlacement';

type CompanyRegistrationFormValues = z.infer<typeof companyRegistrationSchema>;

const CompanyRegistration = () => {
  const { addCompany, uploadDocument } = usePlacement();
  const [uploading, setUploading] = useState(false);

  const form = useForm<CompanyRegistrationFormValues>({
    resolver: zodResolver(companyRegistrationSchema),
    defaultValues: {
      name: '',
      industry: '',
      description: '',
      website: '',
      hrContactName: '',
      hrEmail: '',
      hrPhone: '',
      registrationNumber: '',
      documents: [],
    },
  });

  const handleFileUpload = async (file: File, type: string) => {
    try {
      setUploading(true);
      const url = await uploadDocument(file, '1', 'other'); // Using default company ID
      return { type, url };
    } catch (err) {
      toast.error('Failed to upload document');
      throw err;
    } finally {
      setUploading(false);
    }
  };

  const onSubmit = async (data: CompanyRegistrationFormValues) => {
    try {
      await addCompany({
        ...data,
        status: 'inactive',
        jobPostings: [],
      });
      toast.success('Company registration submitted successfully');
      form.reset();
    } catch (err) {
      toast.error('Failed to submit registration');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-2">
        <FaBuilding className="h-6 w-6 text-indigo-600" />
        <h1 className="text-2xl font-bold">Company Registration</h1>
      </div>

      <div className="border rounded-lg p-6">
        <h2 className="text-xl font-semibold mb-4">Company Information</h2>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                Company Name
              </label>
              <input
                {...form.register('name')}
                id="name"
                type="text"
                placeholder="Enter company name"
                className="mt-1 block w-full border border-gray-300 rounded-md sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
              />
              {form.formState.errors.name && (
                <p className="text-red-600 text-sm">{form.formState.errors.name.message}</p>
              )}
            </div>

            <div>
              <label htmlFor="industry" className="block text-sm font-medium text-gray-700">
                Industry
              </label>
              <input
                {...form.register('industry')}
                id="industry"
                type="text"
                placeholder="Enter industry"
                className="mt-1 block w-full border border-gray-300 rounded-md sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
              />
              {form.formState.errors.industry && (
                <p className="text-red-600 text-sm">{form.formState.errors.industry.message}</p>
              )}
            </div>

            <div>
              <label htmlFor="website" className="block text-sm font-medium text-gray-700">
                Website
              </label>
              <input
                {...form.register('website')}
                id="website"
                type="url"
                placeholder="https://example.com"
                className="mt-1 block w-full border border-gray-300 rounded-md sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
              />
              {form.formState.errors.website && (
                <p className="text-red-600 text-sm">{form.formState.errors.website.message}</p>
              )}
            </div>

            <div>
              <label htmlFor="registrationNumber" className="block text-sm font-medium text-gray-700">
                Registration Number
              </label>
              <input
                {...form.register('registrationNumber')}
                id="registrationNumber"
                type="text"
                placeholder="Enter registration number"
                className="mt-1 block w-full border border-gray-300 rounded-md sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
              />
              {form.formState.errors.registrationNumber && (
                <p className="text-red-600 text-sm">{form.formState.errors.registrationNumber.message}</p>
              )}
            </div>
          </div>

          <div>
            <label htmlFor="description" className="block text-sm font-medium text-gray-700">
              Company Description
            </label>
            <textarea
              {...form.register('description')}
              id="description"
              placeholder="Enter company description"
              rows={4}
              className="mt-1 block w-full border border-gray-300 rounded-md sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            />
            {form.formState.errors.description && (
              <p className="text-red-600 text-sm">{form.formState.errors.description.message}</p>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <label htmlFor="hrContactName" className="block text-sm font-medium text-gray-700">
                HR Contact Name
              </label>
              <input
                {...form.register('hrContactName')}
                id="hrContactName"
                type="text"
                placeholder="Enter HR name"
                className="mt-1 block w-full border border-gray-300 rounded-md sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
              />
              {form.formState.errors.hrContactName && (
                <p className="text-red-600 text-sm">{form.formState.errors.hrContactName.message}</p>
              )}
            </div>

            <div>
              <label htmlFor="hrEmail" className="block text-sm font-medium text-gray-700">
                HR Email
              </label>
              <input
                {...form.register('hrEmail')}
                id="hrEmail"
                type="email"
                placeholder="hr@company.com"
                className="mt-1 block w-full border border-gray-300 rounded-md sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
              />
              {form.formState.errors.hrEmail && (
                <p className="text-red-600 text-sm">{form.formState.errors.hrEmail.message}</p>
              )}
            </div>

            <div>
              <label htmlFor="hrPhone" className="block text-sm font-medium text-gray-700">
                HR Phone
              </label>
              <input
                {...form.register('hrPhone')}
                id="hrPhone"
                type="text"
                placeholder="+91 9876543210"
                className="mt-1 block w-full border border-gray-300 rounded-md sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
              />
              {form.formState.errors.hrPhone && (
                <p className="text-red-600 text-sm">{form.formState.errors.hrPhone.message}</p>
              )}
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="font-semibold">Required Documents</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-2">
                  Company Registration Certificate
                </label>
                <div className="flex items-center space-x-2">
                  <input
                    type="file"
                    accept=".pdf,.doc,.docx"
                    onChange={async (e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        try {
                          const doc = await handleFileUpload(file, 'registration');
                          const currentDocs = form.getValues('documents');
                          form.setValue('documents', [...currentDocs, doc]);
                        } catch (err) {
                          console.error(err);
                        }
                      }
                    }}
                    className="mt-1 block w-full border border-gray-300 rounded-md sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  />
                  <button
                    type="button"
                    disabled={uploading}
                    className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                  >
                    <FaUpload className={uploading ? 'animate-bounce' : ''} />
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">
                  Tax Registration Document
                </label>
                <div className="flex items-center space-x-2">
                  <input
                    type="file"
                    accept=".pdf,.doc,.docx"
                    onChange={async (e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        try {
                          const doc = await handleFileUpload(file, 'tax');
                          const currentDocs = form.getValues('documents');
                          form.setValue('documents', [...currentDocs, doc]);
                        } catch (err) {
                          console.error(err);
                        }
                      }
                    }}
                    className="mt-1 block w-full border border-gray-300 rounded-md sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  />
                  <button
                    type="button"
                    disabled={uploading}
                    className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                  >
                    <FaUpload className={uploading ? 'animate-bounce' : ''} />
                  </button>
                </div>
              </div>
            </div>
          </div>

          <div className="flex justify-end">
            <button
              type="submit"
              className="inline-flex justify-center py-2 px-4 border border-transparent sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
              disabled={form.formState.isSubmitting || uploading}
            >
              {form.formState.isSubmitting ? 'Submitting...' : 'Submit Registration'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CompanyRegistration;
