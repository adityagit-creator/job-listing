import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  FaBriefcase,
  FaUsers,
  FaUserCheck,
  FaCalendarCheck,
  FaPlus,
} from 'react-icons/fa';
import usePlacement from '@/hooks/usePlacement';

const RecruiterDashboard = () => {
  const navigate = useNavigate();
  const {
    jobPostings,
    applications,
    loading,
    error,
    fetchJobPostings,
    fetchApplications,
  } = usePlacement();

  useEffect(() => {
    fetchJobPostings();
    fetchApplications();
  }, []);

  const activeJobPostings = jobPostings.filter(job => job.status === 'open');
  const totalApplications = applications.length;
  const shortlistedCandidates = applications.filter(app => 
    app.status === 'shortlisted' || app.status === 'interviewed'
  ).length;
  const selectedCandidates = applications.filter(app => app.status === 'selected').length;

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Recruiter Dashboard</h1>
        <Button
          onClick={() => navigate('/recruiter/job-posting')}
          className="bg-indigo-600 hover:bg-indigo-700"
        >
          <FaPlus className="mr-2 h-4 w-4" />
          Post New Job
        </Button>
      </div>

      {/* Overview Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Active Jobs</CardTitle>
            <FaBriefcase className="h-4 w-4 text-indigo-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activeJobPostings.length}</div>
            <p className="text-xs text-gray-500">
              {jobPostings.length} total postings
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Applications</CardTitle>
            <FaUsers className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalApplications}</div>
            <p className="text-xs text-gray-500">
              Across all job postings
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Shortlisted</CardTitle>
            <FaUserCheck className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{shortlistedCandidates}</div>
            <p className="text-xs text-gray-500">
              Candidates in process
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Selected</CardTitle>
            <FaCalendarCheck className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{selectedCandidates}</div>
            <p className="text-xs text-gray-500">
              Offers made
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Recent Job Postings */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Job Postings</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {activeJobPostings.slice(0, 5).map((job) => (
              <div
                key={job.id}
                className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50"
              >
                <div>
                  <h3 className="font-semibold">{job.title}</h3>
                  <p className="text-sm text-gray-600">
                    Applications: {applications.filter(app => app.jobId === job.id).length}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium">
                    CTC: {job.package.ctc} LPA
                  </p>
                  <p className="text-xs text-gray-500">
                    Deadline: {job.deadline.toLocaleDateString()}
                  </p>
                </div>
              </div>
            ))}
          </div>
          {activeJobPostings.length > 5 && (
            <Button
              variant="link"
              className="mt-4 w-full"
              onClick={() => navigate('/recruiter/job-posting')}
            >
              View All Job Postings
            </Button>
          )}
        </CardContent>
      </Card>

      {/* Recent Applications */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Applications</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {applications.slice(0, 5).map((application) => {
              const job = jobPostings.find(j => j.id === application.jobId);
              return (
                <div
                  key={application.id}
                  className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50"
                >
                  <div>
                    <h3 className="font-semibold">{job?.title}</h3>
                    <p className="text-sm text-gray-600">
                      Applied: {application.appliedAt.toLocaleDateString()}
                    </p>
                  </div>
                  <div>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      application.status === 'selected'
                        ? 'bg-green-100 text-green-800'
                        : application.status === 'shortlisted'
                        ? 'bg-blue-100 text-blue-800'
                        : application.status === 'rejected'
                        ? 'bg-red-100 text-red-800'
                        : 'bg-gray-100 text-gray-800'
                    }`}>
                      {application.status.charAt(0).toUpperCase() + application.status.slice(1)}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
          {applications.length > 5 && (
            <Button
              variant="link"
              className="mt-4 w-full"
              onClick={() => navigate('/recruiter/candidates')}
            >
              View All Applications
            </Button>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default RecruiterDashboard; 