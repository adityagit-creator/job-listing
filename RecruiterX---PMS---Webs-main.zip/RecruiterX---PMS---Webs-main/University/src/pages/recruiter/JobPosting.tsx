import React, { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { toast } from 'react-hot-toast';
import { jobPostingSchema } from '@/lib/validations/placement';
import type { z } from 'zod';
import { FaBriefcase, FaUsers } from 'react-icons/fa';
import Layout from '@/Layout/Layout';
import usePlacement from '@/hooks/usePlacement';
import { Student } from '@/types/placement';

type JobPostingFormValues = z.infer<typeof jobPostingSchema>;

const JobPosting = () => {
  const { addJobPosting, fetchStudents, students } = usePlacement();
  const [matchedStudents, setMatchedStudents] = useState<Student[]>([]);

  const form = useForm<JobPostingFormValues>({
    resolver: zodResolver(jobPostingSchema),
    defaultValues: {
      companyId: '1', // Default company ID
      title: '',
      description: '',
      eligibilityCriteria: {
        minimumCGPA: 7.0,
        allowedBranches: [],
        otherRequirements: '',
      },
      package: {
        ctc: 0,
        breakup: '',
      },
      deadline: new Date(),
    },
  });

  useEffect(() => {
    fetchStudents();
  }, []);

  // AI-driven candidate matching based on job requirements
  const matchCandidates = (formData: JobPostingFormValues) => {
    const matches = students.filter(student => {
      // Basic eligibility check
      const meetsBasicCriteria =
        student.cgpa >= formData.eligibilityCriteria.minimumCGPA &&
        formData.eligibilityCriteria.allowedBranches.includes(student.branch);

      if (!meetsBasicCriteria) return false;

      // Add more sophisticated matching logic here
      // For example:
      // - Skills matching
      // - Previous internship experience
      // - Academic performance in relevant subjects
      // - Projects and achievements

      return true;
    });

    setMatchedStudents(matches);
  };

  const onSubmit = async (data: JobPostingFormValues) => {
    try {
      await addJobPosting(data);
      toast.success('Job posting created successfully');
      matchCandidates(data);
      form.reset();
    } catch (err) {
      toast.error('Failed to create job posting');
    }
  };

  const branches = [
    { value: 'CSE', label: 'Computer Science' },
    { value: 'ECE', label: 'Electronics' },
    { value: 'ME', label: 'Mechanical' },
    { value: 'CE', label: 'Civil' },
    { value: 'IT', label: 'Information Technology' },
  ];

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex items-center space-x-2">
          <FaBriefcase className="h-6 w-6 text-indigo-600" />
          <h1 className="text-2xl font-bold">Post New Job</h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <div className="border rounded-lg p-6">
              <h2 className="text-xl font-semibold mb-4">Job Details</h2>
              <p className="mb-6">Fill in the job requirements and eligibility criteria</p>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div>
                  <label htmlFor="title" className="block text-sm font-medium text-gray-700">
                    Job Title
                  </label>
                  <input
                    {...form.register('title')}
                    id="title"
                    type="text"
                    placeholder="e.g. Software Engineer"
                    className="mt-1 block w-full border border-gray-300 rounded-md sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  />
                  {form.formState.errors.title && (
                    <p className="text-red-600 text-sm">{form.formState.errors.title.message}</p>
                  )}
                </div>

                <div>
                  <label htmlFor="description" className="block text-sm font-medium text-gray-700">
                    Job Description
                  </label>
                  <textarea
                    {...form.register('description')}
                    id="description"
                    placeholder="Enter detailed job description"
                    rows={4}
                    className="mt-1 block w-full border border-gray-300 rounded-md sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  />
                  {form.formState.errors.description && (
                    <p className="text-red-600 text-sm">{form.formState.errors.description.message}</p>
                  )}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="minimumCGPA" className="block text-sm font-medium text-gray-700">
                      Minimum CGPA
                    </label>
                    <input
                      {...form.register('eligibilityCriteria.minimumCGPA', { valueAsNumber: true })}
                      id="minimumCGPA"
                      type="number"
                      step="0.1"
                      className="mt-1 block w-full border border-gray-300 rounded-md sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                    />
                    {form.formState.errors.eligibilityCriteria?.minimumCGPA && (
                      <p className="text-red-600 text-sm">{form.formState.errors.eligibilityCriteria.minimumCGPA.message}</p>
                    )}
                  </div>

                  <div>
                    <label htmlFor="ctc" className="block text-sm font-medium text-gray-700">
                      CTC (LPA)
                    </label>
                    <input
                      {...form.register('package.ctc', { valueAsNumber: true })}
                      id="ctc"
                      type="number"
                      step="0.1"
                      className="mt-1 block w-full border border-gray-300 rounded-md sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                    />
                    {form.formState.errors.package?.ctc && (
                      <p className="text-red-600 text-sm">{form.formState.errors.package.ctc.message}</p>
                    )}
                  </div>
                </div>

                <div>
                  <label htmlFor="packageBreakup" className="block text-sm font-medium text-gray-700">
                    Package Breakup
                  </label>
                  <textarea
                    {...form.register('package.breakup')}
                    id="packageBreakup"
                    placeholder="Enter salary breakup details"
                    rows={3}
                    className="mt-1 block w-full border border-gray-300 rounded-md sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  />
                  {form.formState.errors.package?.breakup && (
                    <p className="text-red-600 text-sm">{form.formState.errors.package.breakup.message}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Eligible Branches</label>
                  <div className="grid grid-cols-2 gap-4 mt-2">
                    {branches.map((branch) => (
                      <div key={branch.value} className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          id={branch.value}
                          value={branch.value}
                          {...form.register('eligibilityCriteria.allowedBranches')}
                          className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                        />
                        <label htmlFor={branch.value} className="text-sm text-gray-700">
                          {branch.label}
                        </label>
                      </div>
                    ))}
                  </div>
                  {form.formState.errors.eligibilityCriteria?.allowedBranches && (
                    <p className="text-red-600 text-sm">{form.formState.errors.eligibilityCriteria.allowedBranches.message}</p>
                  )}
                </div>

                <div>
                  <label htmlFor="otherRequirements" className="block text-sm font-medium text-gray-700">
                    Other Requirements
                  </label>
                  <textarea
                    {...form.register('eligibilityCriteria.otherRequirements')}
                    id="otherRequirements"
                    placeholder="Enter additional requirements"
                    rows={3}
                    className="mt-1 block w-full border border-gray-300 rounded-md sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  />
                  {form.formState.errors.eligibilityCriteria?.otherRequirements && (
                    <p className="text-red-600 text-sm">{form.formState.errors.eligibilityCriteria.otherRequirements.message}</p>
                  )}
                </div>

                <div>
                  <label htmlFor="deadline" className="block text-sm font-medium text-gray-700">
                    Application Deadline
                  </label>
                  <input
                    {...form.register('deadline', { valueAsDate: true })}
                    id="deadline"
                    type="date"
                    className="mt-1 block w-full border border-gray-300 rounded-md sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  />
                  {form.formState.errors.deadline && (
                    <p className="text-red-600 text-sm">{form.formState.errors.deadline.message}</p>
                  )}
                </div>

                <div className="flex justify-end">
                  <button
                    type="submit"
                    className="inline-flex justify-center py-2 px-4 border border-transparent sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                    disabled={form.formState.isSubmitting}
                  >
                    {form.formState.isSubmitting ? 'Posting...' : 'Post Job'}
                  </button>
                </div>
              </form>
            </div>
          </div>

          <div>
            <div className="border rounded-lg p-6">
              <div className="flex items-center space-x-2 mb-4">
                <FaUsers className="h-5 w-5" />
                <span className="text-lg font-semibold">Matched Candidates</span>
              </div>
              <p className="mb-4">{matchedStudents.length} candidates match your requirements</p>
              <div className="space-y-4">
                {matchedStudents.map((student) => (
                  <div
                    key={student.id}
                    className="flex items-start justify-between p-3 border rounded-lg"
                  >
                    <div>
                      <h3 className="font-semibold">{student.name}</h3>
                      <p className="text-sm text-gray-600">{student.branch}</p>
                      <p className="text-sm text-gray-600">CGPA: {student.cgpa}</p>
                    </div>
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                      {student.placementStatus}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default JobPosting;
