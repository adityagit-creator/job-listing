import { useState } from "react";
import { Link } from "react-router-dom";
import { collection, orderBy, query } from "firebase/firestore";
import { db } from "@/config/FirebaseConfig";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader } from "@/helpers/utility";
import Layout from "@/Layout/Layout";
import { DollarSign } from "lucide-react";
import { utils, writeFile } from "xlsx";
import { useCollection } from "react-firebase-hooks/firestore";
const ITEMS_PER_PAGE = 30; // Show 10 items per page

interface User {
  uid?: string;
  name: string;
  phoneNumber: string;
  email: string;
  isVerified?: boolean;
  mobileNumber?: string;
  collegeName?: string;
  coupon?: string;
}

function Students() {
  const [currentPage, setCurrentPage] = useState(1);
  const [filter, setFilter] = useState<"all" | "paid" | "free">("all");
  const [search, setSearch] = useState("");

  // Query Firestore with React Firebase Hooks
  const usersQuery = query(
    collection(db, "users"),
    orderBy("createdAt", "desc")
  );
  const [snapshot, isLoading, error] = useCollection(usersQuery);

  // Parse data from snapshot
  const users: User[] =
    snapshot?.docs.map((doc) => {
      const data = doc.data();
      return {
        uid: doc.id,
        name: data.name || "Unknown",
        phoneNumber: data.phoneNumber || "N/A",
        email: data.email || "Unknown",
        isVerified: data.isVerified || false,
        collegeName: data.collegeName || "N/A",
        coupon: data.subscription?.promoCode || "N/A",
      };
    }) || [];

  const paidCount = users.filter((user) => user.isVerified).length;
  const freeCount = users.filter((user) => !user.isVerified).length;

  const filteredUsers = users.filter((user) => {
    if (filter === "paid" && !user.isVerified) return false;
    if (filter === "free" && user.isVerified) return false;
    if (
      search &&
      !(
        user.name.toLowerCase().includes(search.toLowerCase()) ||
        user.email.toLowerCase().includes(search.toLowerCase())
      )
    ) {
      return false;
    }
    return true;
  });

  const paginatedUsers = filteredUsers.slice(
    (currentPage - 1) * ITEMS_PER_PAGE,
    currentPage * ITEMS_PER_PAGE
  );
  const totalPages = Math.ceil(filteredUsers.length / ITEMS_PER_PAGE);

  const handleDownloadExcel = () => {
    const formattedData = users.map((user) => ({
      UID: user.uid,
      Name: user.name,
      "Phone Number": user.phoneNumber,
      Email: user.email,
      "College Name": user.collegeName || "N/A",
      "Subscription Status": user.isVerified ? "Paid" : "Free",
      "Coupon Code": user.coupon || "N/A",
    }));

    const worksheet = utils.json_to_sheet(formattedData);
    const workbook = utils.book_new();
    utils.book_append_sheet(workbook, worksheet, "Users");
    writeFile(workbook, "UsersData.xlsx");
  };

  const handleNext = () => {
    if (currentPage < totalPages) setCurrentPage((prev) => prev + 1);
  };

  const handlePrevious = () => {
    if (currentPage > 1) setCurrentPage((prev) => prev - 1);
  };

  if (error) {
    return <div>Error loading users: {error.message}</div>;
  }
  return (
    <Layout>
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-lg font-bold">User List</h1>
      </div>

      <div className="grid gap-4 grid-cols-1 md:gap-8 lg:grid-cols-3">
        <Card className="none">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-lg font-semibold">Total User</CardTitle>
            <DollarSign className="h-4 w-4 text-gray-900" />
          </CardHeader>
          <CardContent>
            <div className="text-5xl font-bold"> {users.length}</div>
          </CardContent>
        </Card>
        <Card className="none">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-lg font-semibold">Paid User</CardTitle>
            <DollarSign className="h-4 w-4 text-gray-900" />
          </CardHeader>
          <CardContent>
            <div className="text-5xl font-bold"> {paidCount}</div>
          </CardContent>
        </Card>
        <Card className="none">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-lg font-semibold">Free User</CardTitle>
            <DollarSign className="h-4 w-4 text-gray-900" />
          </CardHeader>
          <CardContent>
            <div className="text-5xl font-bold"> {freeCount}</div>
          </CardContent>
        </Card>
      </div>
      <div className="flex h-14  w-full space-x-4">
        <div className=" flex-1  h-full rounded-lg border border-gray-200 bg-gray-50  px-4 focus-within:border-blue-300  sm:block sm:w-70 lg:w-88">
          <div className="flex h-full w-full items-center space-x-4">
            <span>
              <svg
                className="stroke-gray-900 "
                width="21"
                height="22"
                viewBox="0 0 21 22"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <circle
                  cx="9.80204"
                  cy="10.6761"
                  r="8.98856"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></circle>
                <path
                  d="M16.0537 17.3945L19.5777 20.9094"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
            </span>
            <label htmlFor="listSearch" className="w-full">
              <input
                type="text"
                id="listSearch"
                placeholder="Search by name or email"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="search-input w-full border-none bg-gray-50 px-0 text-sm tracking-wide text-gray-600 placeholder:text-sm placeholder:font-medium placeholder:text-gray-500 focus:outline-none focus:ring-0 "
              />
            </label>
          </div>
        </div>
      </div>

      <div className="flex justify-between items-center mb-4">
        <div className="flex items-center space-x-2">
          <Button
            className={`px-4 py-2 rounded-md font-medium transition-all ${
              filter === "all"
                ? "bg-blue-500 text-white md"
                : "bg-gray-100 text-gray-800 hover:bg-gray-200"
            }`}
            onClick={() => setFilter("all")}
          >
            All
          </Button>
          <Button
            className={`px-4 py-2 rounded-md font-medium transition-all ${
              filter === "paid"
                ? "bg-green-500 text-white md"
                : "bg-gray-100 text-gray-800 hover:bg-gray-200"
            }`}
            onClick={() => setFilter("paid")}
          >
            Paid Users
          </Button>
          <Button
            className={`px-4 py-2 rounded-md font-medium transition-all ${
              filter === "free"
                ? "bg-red-500 text-white md"
                : "bg-gray-100 text-gray-800 hover:bg-gray-200"
            }`}
            onClick={() => setFilter("free")}
          >
            Free Users
          </Button>
        </div>
        <Button
          className="bg-indigo-500 hover:bg-indigo-600 text-white"
          onClick={handleDownloadExcel}
        >
          Download Excel
        </Button>
      </div>

      <Card className="none overflow-x-scroll relative">
        <CardHeader>
          <CardTitle>Users</CardTitle>
          <CardDescription>Manage your users</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center items-center h-96">
              <Loader />
            </div>
          ) : (
            <Table className="overflow-x-auto">
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Mobile</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Coupon</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {paginatedUsers.map((user) => (
                  <TableRow key={user.uid}>
                    <TableCell>{user.name}</TableCell>
                    <TableCell>{user.phoneNumber}</TableCell>
                    <TableCell>{user.email}</TableCell>
                    <TableCell className="uppercase">{user.coupon}</TableCell>
                    <TableCell>
                      <Badge className="bg-accent_color">
                        {user.isVerified ? "Subscribed" : "Free User"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Link to={`/viewStudent/${user.uid}`}>
                        <Button className="bg-accent_color">View</Button>
                      </Link>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button
            variant="outline"
            onClick={handlePrevious}
            disabled={currentPage === 1}
          >
            Previous
          </Button>
          <span>
            Page {currentPage} of {totalPages}
          </span>
          <Button
            variant="outline"
            onClick={handleNext}
            disabled={currentPage === totalPages}
          >
            Next
          </Button>
        </CardFooter>
      </Card>
    </Layout>
  );
}

export default Students;
