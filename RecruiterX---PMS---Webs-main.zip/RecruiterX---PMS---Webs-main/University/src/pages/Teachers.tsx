import { useState, useEffect } from "react";
import { db } from "@/config/FirebaseConfig";
import Layout from "@/Layout/Layout";
import {
  collection,
  doc,
  DocumentData,
  onSnapshot,
  Query,
  query,
  updateDoc,
  where,
} from "firebase/firestore";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Link } from "react-router-dom";
import { EyeOpenIcon } from "@radix-ui/react-icons";
import { PlusCircleIcon } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import toast from "react-hot-toast";
import { Loader } from "@/helpers/utility"; // Assuming you have a Loader component

export interface Teacher {
  id: string;
  name: string;
  ownerId: string;
  address: string;
  availability: string;
  brand: string;
  category: string;
  district: string;
  industry: string;
  insuranceImage: string;
  TeacherImage: string;
  price: number;
  pricingOption: string;
  rcBookImage: string;
  status: string;
  updatedAt: string;
}

const Teachers = () => {
  const [Teachers, setTeachers] = useState<Teacher[]>([]);
  const [isLoading, setIsLoading] = useState(true); // Loader state
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory] = useState("All");
  const [searchCriterion, setSearchCriterion] = useState("id");
  const [selectedIndustry, setSelectedIndustry] = useState("All");

  const categories = [
    "All",
    "Forestry",
    "Agriculture",
    "Construction",
    "Travel",
    "Cleanup",
    "Utility",
  ];

  const fetchTeachers = () => {
    setIsLoading(true); // Start loading
    let TeacherRef: Query<DocumentData> = collection(db, "Teachers");

    if (selectedCategory !== "All") {
      TeacherRef = query(TeacherRef, where("industry", "==", selectedCategory));
    }

    onSnapshot(TeacherRef, (snapshot) => {
      const data = snapshot.docs.map((doc) => {
        const docData = doc.data();
        return {
          id: doc.id,
          name: docData.name || "",
          ownerId: docData.ownerId || "",
          address: docData.address || "",
          availability: docData.availability || "",
          brand: docData.brand || "",
          category: docData.category || "",
          district: docData.district || "",
          industry: docData.industry || "",
          insuranceImage: docData.insuranceImage || "",
          TeacherImage: docData.TeacherImage || "",
          price: docData.price || 0,
          pricingOption: docData.pricingOption || "",
          rcBookImage: docData.rcBookImage || "",
          status: docData.status || "",
          updatedAt: docData.updatedAt || "",
        };
      });
      setTeachers(data as Teacher[]);
      setIsLoading(false); // End loading
    });
  };

  const fetchTeacherByCriteria = () => {
    setIsLoading(true); // Start loading
    let TeacherRef: Query<DocumentData> = collection(db, "Teachers");

    if (searchQuery) {
      TeacherRef = query(TeacherRef, where(searchCriterion, "==", searchQuery));
    }

    if (selectedIndustry !== "All") {
      TeacherRef = query(TeacherRef, where("industry", "==", selectedIndustry));
    }

    onSnapshot(TeacherRef, (snapshot) => {
      const data = snapshot.docs.map((doc) => {
        const docData = doc.data();
        return {
          id: doc.id,
          name: docData.name || "",
          ownerId: docData.ownerId || "",
          address: docData.address || "",
          availability: docData.availability || "",
          brand: docData.brand || "",
          category: docData.category || "",
          district: docData.district || "",
          industry: docData.industry || "",
          insuranceImage: docData.insuranceImage || "",
          TeacherImage: docData.TeacherImage || "",
          price: docData.price || 0,
          pricingOption: docData.pricingOption || "",
          rcBookImage: docData.rcBookImage || "",
          status: docData.status || "",
          updatedAt: docData.updatedAt || "",
        };
      });
      setTeachers(data as Teacher[]);
      setIsLoading(false); // End loading
    });
  };

  const placeHolderText = (searchCriterion: string) => {
    switch (searchCriterion) {
      case "id":
        return "Teacher ID";
      case "name":
        return "Teacher Name";
      case "ownerId":
        return "Owner ID";
      default:
        return "Search";
    }
  };

  const handleAvailabilityChange = async (value: string, TeacherId: string) => {
    try {
      const TeacherRef = doc(db, "Teachers", TeacherId);
      await updateDoc(TeacherRef, {
        availability: value,
      });
      toast.success("Availability changed successfully");
    } catch (err) {
      console.error("Cannot change the availability of the Teacher", err);
    }
  };

  useEffect(() => {
    fetchTeachers();
  }, []);

  return (
    <Layout>
      <main className="p-4">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-2xl font-semibold">Teachers</h1>
          <Link to="/AddTeachers">
            <Button className="py-3 px-4 bg-accent_color rounded-lg text-white font-medium text-sm">
              <PlusCircleIcon className="size-4 mr-2" />
              Add Teacher
            </Button>
          </Link>
        </div>
        <div className="bg-white border border-gray-200 rounded-lg p-4 mb-4 flex items-center gap-4 text-sm">
          <div className="flex items-center flex-1">
            <input
              type="text"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring focus:border-blue-300"
              placeholder={placeHolderText(searchCriterion)}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <div className="flex items-center">
            <span className="mr-2">Search by</span>
            <select
              className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring focus:border-blue-300"
              value={searchCriterion}
              onChange={(e) => setSearchCriterion(e.target.value)}
            >
              <option value="id">Teacher ID</option>
              <option value="ownerId">Owner ID</option>
              <option value="name">Teacher Name</option>
            </select>
          </div>
          <div className="flex items-center">
            <span className="mr-2">Industry</span>
            <select
              className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring focus:border-blue-300"
              value={selectedIndustry}
              onChange={(e) => setSelectedIndustry(e.target.value)}
            >
              {categories.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>
          <div>
            <Button
              className="py-3 px-10 bg-accent_color rounded-lg text-white font-medium text-sm"
              onClick={fetchTeacherByCriteria}
            >
              Search
            </Button>
          </div>
        </div>

        <div className="grid auto-rows-max items-start gap-4 md:gap-8 lg:col-span-2">
          <Card className="border-0 border-white none">
            <CardContent>
              {isLoading ? (
                <div className="flex justify-center items-center h-96">
                  <Loader /> {/* Render the Loader when loading */}
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Teacher</TableHead>
                      <TableHead>Teacher Name</TableHead>
                      <TableHead>Teacher ID</TableHead>
                      <TableHead>Industry</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>District</TableHead>
                      <TableHead>Price</TableHead>
                      <TableHead>Availability</TableHead>
                      <TableHead>Action</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {Teachers.map((Teacher) => (
                      <TableRow key={Teacher.id}>
                        <TableCell>
                          <img
                            src={Teacher.TeacherImage}
                            className="h-16 w-16 rounded-lg"
                            alt={Teacher.name}
                          />
                        </TableCell>
                        <TableCell className="capitalize">
                          {Teacher.name}
                        </TableCell>
                        <TableCell className="capitalize">
                          {Teacher.id}
                        </TableCell>
                        <TableCell className="capitalize">
                          {Teacher.industry}
                        </TableCell>
                        <TableCell className="capitalize">
                          {Teacher.category}
                        </TableCell>
                        <TableCell className="capitalize">
                          {Teacher.district}
                        </TableCell>
                        <TableCell className="capitalize">
                          {`₹${Teacher.price}/${Teacher.pricingOption}`}
                        </TableCell>
                        <TableCell className="capitalize">
                          <Select
                            defaultValue={Teacher.availability}
                            onValueChange={(value) =>
                              handleAvailabilityChange(value, Teacher.id)
                            }
                          >
                            <SelectTrigger>
                              <SelectValue></SelectValue>
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="available">
                                Available
                              </SelectItem>
                              <SelectItem value="unavailable">
                                Unavailable
                              </SelectItem>
                            </SelectContent>
                          </Select>
                        </TableCell>
                        <TableCell>
                          <Link to={`/Teachers/${Teacher.id}`}>
                            <Button className="py-3 px-4 bg-accent_color rounded-lg text-white font-medium text-sm">
                              <EyeOpenIcon />
                            </Button>
                          </Link>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </Layout>
  );
};

export default Teachers;
