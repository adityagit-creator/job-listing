import React, { useState, useEffect } from 'react';
import { toast } from 'react-hot-toast';
import {
  Building,
  Search,
  Plus,
  MoreHorizontal,
  Globe,
  Mail,
  Phone,
  Users,
  Briefcase,
} from 'lucide-react';
import Layout from '@/Layout/Layout';
import { useRecruiter } from '@/hooks/useRecruiter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import CardLoading from '@/components/Helpers/card-loading';

const RecruiterManagement = () => {
  const {
    recruiters,
    loading,
    error,
    fetchRecruiters,
    createRecruiter,
    updateRecruiterDetails,
    removeRecruiter,
    toggleRecruiterStatus,
  } = useRecruiter();

  const [showAddDialog, setShowAddDialog] = useState(false);
  const [filters, setFilters] = useState({
    search: '',
    industry: '',
    status: '',
  });

  const [formData, setFormData] = useState({
    companyName: '',
    industry: '',
    hrContactName: '',
    hrEmail: '',
    hrPhone: '',
    companyWebsite: '',
    companyDescription: '',
  });

  useEffect(() => {
    fetchRecruiters();
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await createRecruiter({
        ...formData,
        status: 'active',
        registrationDate: new Date(),
        jobPostings: 0,
        hiringHistory: [],
        documents: [],
        createdAt: new Date(),
        updatedAt: new Date(),
      });
      setShowAddDialog(false);
      resetForm();
      toast.success('Recruiter added successfully');
    } catch (error) {
      toast.error('Failed to add recruiter');
    }
  };

  const handleStatusToggle = async (id: string, currentStatus: 'active' | 'inactive') => {
    try {
      await toggleRecruiterStatus(id, currentStatus === 'active' ? 'inactive' : 'active');
      toast.success('Status updated successfully');
    } catch (error) {
      toast.error('Failed to update status');
    }
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this recruiter?')) {
      try {
        await removeRecruiter(id);
        toast.success('Recruiter deleted successfully');
      } catch (error) {
        toast.error('Failed to delete recruiter');
      }
    }
  };

  const resetForm = () => {
    setFormData({
      companyName: '',
      industry: '',
      hrContactName: '',
      hrEmail: '',
      hrPhone: '',
      companyWebsite: '',
      companyDescription: '',
    });
  };

  if (loading) {
    return (
      <Layout>
        <div className="container mx-auto max-w-7xl p-6">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {[1, 2, 3].map((i) => (
              <CardLoading key={i} />
            ))}
          </div>
        </div>
      </Layout>
    );
  }

  if (error) {
    return (
      <Layout>
        <div className="flex h-[50vh] items-center justify-center">
          <Card className="w-full max-w-md p-6">
            <div className="text-center">
              <h3 className="mt-2 text-lg font-semibold">Error Loading Recruiters</h3>
              <p className="mt-1 text-gray-500">{error}</p>
            </div>
          </Card>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto max-w-7xl p-6">
        {/* Header */}
        <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Recruiter Management</h1>
            <p className="mt-1 text-gray-500">
              Manage company recruiters and their activities
            </p>
          </div>
          <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
            <DialogTrigger asChild>
              <Button size="sm" className="h-10">
                <Plus className="mr-2 h-4 w-4" />
                Add Recruiter
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[600px]">
              <DialogHeader>
                <DialogTitle>Add New Recruiter</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="mt-4 space-y-6">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div>
                    <label className="text-sm font-medium">Company Name</label>
                    <Input
                      name="companyName"
                      value={formData.companyName}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Industry</label>
                    <Input
                      name="industry"
                      value={formData.industry}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">HR Contact Name</label>
                    <Input
                      name="hrContactName"
                      value={formData.hrContactName}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">HR Email</label>
                    <Input
                      type="email"
                      name="hrEmail"
                      value={formData.hrEmail}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">HR Phone</label>
                    <Input
                      name="hrPhone"
                      value={formData.hrPhone}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Company Website</label>
                    <Input
                      type="url"
                      name="companyWebsite"
                      value={formData.companyWebsite}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="text-sm font-medium">Company Description</label>
                    <textarea
                      name="companyDescription"
                      value={formData.companyDescription}
                      onChange={handleInputChange}
                      required
                      rows={3}
                      className="mt-1 w-full rounded-md border border-gray-300 p-2"
                    />
                  </div>
                </div>
                <div className="flex justify-end">
                  <Button type="submit">Add Recruiter</Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <CardContent className="p-4">
            <div className="grid gap-4 md:grid-cols-3">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                <Input
                  placeholder="Search recruiters..."
                  value={filters.search}
                  onChange={(e) => setFilters({ ...filters, search: e.target.value })}
                  className="pl-9"
                />
              </div>
              <select
                className="rounded-md border border-gray-300 p-2"
                value={filters.industry}
                onChange={(e) => setFilters({ ...filters, industry: e.target.value })}
              >
                <option value="">All Industries</option>
                <option value="Technology">Technology</option>
                <option value="Finance">Finance</option>
                <option value="Healthcare">Healthcare</option>
                <option value="Manufacturing">Manufacturing</option>
              </select>
              <select
                className="rounded-md border border-gray-300 p-2"
                value={filters.status}
                onChange={(e) => setFilters({ ...filters, status: e.target.value })}
              >
                <option value="">All Status</option>
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
              </select>
            </div>
          </CardContent>
        </Card>

        {/* Recruiter Grid */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {recruiters.map((recruiter) => (
            <Card key={recruiter.id} className="overflow-hidden hover:shadow-lg transition-shadow">
              <CardHeader className="border-b bg-gray-50/50 p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                      <Building className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <CardTitle className="text-lg font-semibold">
                        {recruiter.companyName}
                      </CardTitle>
                      <p className="text-sm text-gray-500">{recruiter.industry}</p>
                    </div>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => handleStatusToggle(recruiter.id, recruiter.status)}>
                        {recruiter.status === 'active' ? 'Deactivate' : 'Activate'}
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleDelete(recruiter.id)}>
                        Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </CardHeader>
              <CardContent className="p-4">
                <div className="space-y-4">
                  <div className="flex items-center text-sm">
                    <Globe className="mr-2 h-4 w-4 text-gray-400" />
                    <a
                      href={recruiter.companyWebsite}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-primary hover:underline"
                    >
                      {recruiter.companyWebsite}
                    </a>
                  </div>
                  <div className="flex items-center text-sm">
                    <Mail className="mr-2 h-4 w-4 text-gray-400" />
                    <span>{recruiter.hrEmail}</span>
                  </div>
                  <div className="flex items-center text-sm">
                    <Phone className="mr-2 h-4 w-4 text-gray-400" />
                    <span>{recruiter.hrPhone}</span>
                  </div>
                  <div className="flex items-center justify-between border-t pt-4">
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center text-sm">
                        <Briefcase className="mr-1 h-4 w-4 text-gray-400" />
                        <span>{recruiter.jobPostings} Jobs</span>
                      </div>
                      <div className="flex items-center text-sm">
                        <Users className="mr-1 h-4 w-4 text-gray-400" />
                        <span>
                          {recruiter.hiringHistory.reduce((acc, curr) => acc + curr.studentsHired, 0)} Hired
                        </span>
                      </div>
                    </div>
                    <Badge
                      variant={recruiter.status === 'active' ? 'success' : 'secondary'}
                      className="capitalize"
                    >
                      {recruiter.status}
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {recruiters.length === 0 && (
          <Card className="p-12 text-center">
            <Building className="mx-auto h-12 w-12 text-gray-400" />
            <h3 className="mt-4 text-lg font-semibold">No Recruiters Found</h3>
            <p className="mt-1 text-gray-500">Add your first recruiter to get started</p>
          </Card>
        )}
      </div>
    </Layout>
  );
};

export default RecruiterManagement; 