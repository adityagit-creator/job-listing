import Layout from '@/Layout/Layout';
import React from 'react';

const ReportsInsights = () => {
  return (
    <Layout>
      <h1 className="text-2xl font-bold mb-6">Reports & Insights</h1>

      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-semibold mb-2">Placement Rate</h3>
          <div className="text-3xl font-bold text-blue-600">85%</div>
          <p className="text-gray-600">+5% from last year</p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-semibold mb-2">Average Package</h3>
          <div className="text-3xl font-bold text-green-600">8.5 LPA</div>
          <p className="text-gray-600">+1.2 LPA from last year</p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-semibold mb-2">Companies Visited</h3>
          <div className="text-3xl font-bold text-purple-600">42</div>
          <p className="text-gray-600">+8 from last year</p>
        </div>
      </div>

      {/* Branch-wise Statistics */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-xl font-semibold mb-4">Branch-wise Placement</h2>
          <div className="space-y-4">
            {/* Chart would go here */}
            <div className="h-64 bg-gray-100 rounded flex items-center justify-center">
              Branch-wise Placement Chart
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-xl font-semibold mb-4">Package Distribution</h2>
          <div className="space-y-4">
            {/* Chart would go here */}
            <div className="h-64 bg-gray-100 rounded flex items-center justify-center">
              Package Distribution Chart
            </div>
          </div>
        </div>
      </div>

      {/* Detailed Reports */}
      <div className="bg-white p-6 rounded-lg shadow">
        <h2 className="text-xl font-semibold mb-4">Detailed Reports</h2>
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 border rounded">
            <div>
              <h3 className="font-semibold">Placement Summary Report</h3>
              <p className="text-gray-600">Complete placement statistics for 2024 batch</p>
            </div>
            <button className="bg-blue-600 text-white px-4 py-2 rounded">
              Download
            </button>
          </div>
          <div className="flex items-center justify-between p-4 border rounded">
            <div>
              <h3 className="font-semibold">Company Engagement Report</h3>
              <p className="text-gray-600">Recruiter participation and feedback analysis</p>
            </div>
            <button className="bg-blue-600 text-white px-4 py-2 rounded">
              Download
            </button>
          </div>
          <div className="flex items-center justify-between p-4 border rounded">
            <div>
              <h3 className="font-semibold">Student Performance Analytics</h3>
              <p className="text-gray-600">Assessment and interview performance trends</p>
            </div>
            <button className="bg-blue-600 text-white px-4 py-2 rounded">
              Download
            </button>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default ReportsInsights; 