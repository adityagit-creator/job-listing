import Layout from '@/Layout/Layout'

function Assignments() {
  return (
    <Layout>Assignments</Layout>
  )
}

export default Assignments