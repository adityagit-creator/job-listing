import React, { useState } from 'react';
import axios from 'axios';
import * as XLSX from 'xlsx';

// Define the structure of a business object
interface Business {
  name: string;
  address: string;
  rating: string | number;
  latitude: number;
  longitude: number;
  website: string;
  phone: string;
  email: string;
}

const BusinessListing: React.FC = () => {
  // State to hold form inputs and business data
  const [cityName, setCityName] = useState<string>('');
  const [radius, setRadius] = useState<number>(5000); // Default radius is 5000 meters
  const [businessType, setBusinessType] = useState<string>('');
  const [businesses, setBusinesses] = useState<Business[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // Replace with your Google API Key
  const API_KEY = 'AIzaSyAbBHiSRlVVKMfZqUvwhmYgrMVb9QX0VCw';

  // Function to geocode the city name into latitude and longitude
  const geocodeCity = async (city: string): Promise<{ lat: number; lng: number } | null> => {
    const geocodeUrl = `https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(
      city
    )}&key=${API_KEY}`;

    try {
      const response = await axios.get(geocodeUrl);
      if (response.data.results.length > 0) {
        const { lat, lng } = response.data.results[0].geometry.location;
        return { lat, lng };
      } else {
        setError('City not found. Please enter a valid city name.');
        return null;
      }
    } catch (error) {
      setError('Failed to geocode city. Please try again.');
      return null;
    }
  };

  // Function to handle the API request
  const fetchBusinessData = async () => {
    if (!cityName || !businessType) {
      setError('City name and business type are required!');
      return;
    }

    setLoading(true);
    setError(null);

    // Step 1: Geocode the city name to get latitude and longitude
    const coordinates = await geocodeCity(cityName);
    if (!coordinates) {
      setLoading(false);
      return;
    }

    const { lat, lng } = coordinates;

    // Step 2: Fetch businesses using the coordinates
    const url = `https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=${lat},${lng}&radius=${radius}&type=${businessType}&key=${API_KEY}`;

    try {
      const response = await axios.get(url);
      const businessesData: Business[] = response.data.results.map((business: any) => ({
        name: business.name,
        address: business.vicinity,
        rating: business.rating || 'N/A',
        latitude: business.geometry.location.lat,
        longitude: business.geometry.location.lng,
        website: business.website || 'N/A',
        phone: business.formatted_phone_number || 'N/A',
        email: 'N/A', // You won't get emails directly from the API
      }));
      setBusinesses(businessesData);
    } catch (error) {
      setError('Failed to fetch business data. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // Function to export data to Excel
  const exportToExcel = () => {
    const ws = XLSX.utils.json_to_sheet(businesses);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Businesses');
    XLSX.writeFile(wb, 'Business_List.xlsx');
  };

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold text-center mb-6">Business Listing</h1>

      {error && <p className="text-red-500 text-center mb-4">{error}</p>}

      <div className="space-y-4 max-w-md mx-auto">
        <div>
          <label className="block text-sm font-medium text-gray-700">City Name:</label>
          <input
            type="text"
            value={cityName}
            onChange={(e) => setCityName(e.target.value)}
            placeholder="e.g., New York"
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Radius (meters):</label>
          <input
            type="number"
            value={radius}
            onChange={(e) => setRadius(Number(e.target.value))}
            placeholder="e.g., 5000"
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Business Type (e.g., restaurant):</label>
          <input
            type="text"
            value={businessType}
            onChange={(e) => setBusinessType(e.target.value)}
            placeholder="e.g., restaurant"
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <button
          onClick={fetchBusinessData}
          disabled={loading}
          className="w-full bg-blue-500 text-white py-2 px-4 rounded-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:bg-blue-300"
        >
          {loading ? 'Loading...' : 'Fetch Businesses'}
        </button>
      </div>

      {businesses.length > 0 && (
        <div className="mt-8">
          <button
            onClick={exportToExcel}
            className="mb-4 bg-green-500 text-white py-2 px-4 rounded-md hover:bg-green-600 focus:outline-none focus:ring-2 focus:ring-green-500"
          >
            Export to Excel
          </button>
          <table className="min-w-full bg-white border border-gray-200">
            <thead>
              <tr className="bg-gray-100">
                <th className="py-2 px-4 border-b">Name</th>
                <th className="py-2 px-4 border-b">Address</th>
                <th className="py-2 px-4 border-b">Rating</th>
                <th className="py-2 px-4 border-b">Latitude</th>
                <th className="py-2 px-4 border-b">Longitude</th>
                <th className="py-2 px-4 border-b">Website</th>
              </tr>
            </thead>
            <tbody>
              {businesses.map((business, index) => (
                <tr key={index} className="hover:bg-gray-50">
                  <td className="py-2 px-4 border-b">{business.name}</td>
                  <td className="py-2 px-4 border-b">{business.address}</td>
                  <td className="py-2 px-4 border-b">{business.rating}</td>
                  <td className="py-2 px-4 border-b">{business.latitude}</td>
                  <td className="py-2 px-4 border-b">{business.longitude}</td>
                  <td className="py-2 px-4 border-b">{business.website}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default BusinessListing;