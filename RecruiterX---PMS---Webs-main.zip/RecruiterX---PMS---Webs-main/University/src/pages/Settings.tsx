import React, { useState } from 'react';
import Layout from "@/Layout/Layout";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  FaEnvelope,
  FaWhatsapp,
  FaCog,
  FaBell,
  FaFile,
  FaSave,
} from 'react-icons/fa';
import { toast } from 'react-hot-toast';

interface SettingsSection {
  id: string;
  icon: React.ReactNode;
  title: string;
  description: string;
}

const Settings = () => {
  const [activeSection, setActiveSection] = useState<string>('email');
  const [settings, setSettings] = useState({
    email: {
      offerLetterTemplate: '',
      interviewInviteTemplate: '',
      placementUpdateTemplate: '',
      fromEmail: '',
      replyToEmail: '',
    },
    whatsapp: {
      enabled: false,
      apiKey: '',
      templateName: '',
      phoneNumberId: '',
    },
    system: {
      allowBulkUpload: true,
      autoVerifyDocuments: false,
      requireApproval: true,
      maxFileSize: 5,
    },
    notifications: {
      sendEmailNotifications: true,
      sendWhatsAppNotifications: false,
      sendAppNotifications: true,
      notifyUnplacedStudents: true,
      notifyNewOpportunities: true,
    },
    documents: {
      allowedFileTypes: '.pdf,.doc,.docx',
      maxDocumentsPerStudent: 10,
      requireTranscript: true,
      requireResume: true,
    }
  });

  const sections: SettingsSection[] = [
    {
      id: 'email',
      icon: <FaEnvelope className="h-5 w-5" />,
      title: 'Email Templates',
      description: 'Configure email templates for various notifications'
    },
    {
      id: 'whatsapp',
      icon: <FaWhatsapp className="h-5 w-5" />,
      title: 'WhatsApp Integration',
      description: 'Setup WhatsApp Business API integration'
    },
    {
      id: 'system',
      icon: <FaCog className="h-5 w-5" />,
      title: 'System Preferences',
      description: 'Configure general system settings'
    },
    {
      id: 'notifications',
      icon: <FaBell className="h-5 w-5" />,
      title: 'Notification Settings',
      description: 'Manage notification preferences'
    },
    {
      id: 'documents',
      icon: <FaFile className="h-5 w-5" />,
      title: 'Document Settings',
      description: 'Configure document upload settings'
    }
  ];

  const handleSettingChange = (section: string, setting: string, value: any) => {
    setSettings(prev => ({
      ...prev,
      [section]: {
        ...prev[section],
        [setting]: value
      }
    }));
  };

  const handleSave = async () => {
    try {
      // TODO: Implement settings save functionality
      toast.success('Settings saved successfully');
    } catch (error) {
      toast.error('Failed to save settings');
    }
  };

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold">Settings</h1>
            <p className="text-gray-600">Configure placement system settings</p>
          </div>
          <Button onClick={handleSave} className="flex items-center gap-2">
            <FaSave className="h-4 w-4" />
            Save Changes
          </Button>
        </div>

        <div className="grid grid-cols-12 gap-6">
          {/* Settings Navigation */}
          <div className="col-span-12 md:col-span-3">
            <Card className="p-4">
              <nav className="space-y-2">
                {sections.map((section) => (
                  <button
                    key={section.id}
                    onClick={() => setActiveSection(section.id)}
                    className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${
                      activeSection === section.id
                        ? 'bg-primary text-white'
                        : 'hover:bg-gray-100'
                    }`}
                  >
                    {section.icon}
                    <span>{section.title}</span>
                  </button>
                ))}
              </nav>
            </Card>
          </div>

          {/* Settings Content */}
          <div className="col-span-12 md:col-span-9">
            <Card className="p-6">
              {activeSection === 'email' && (
                <div className="space-y-6">
                  <h2 className="text-xl font-semibold">Email Templates</h2>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium mb-1">From Email</label>
                      <Input
                        value={settings.email.fromEmail}
                        onChange={(e) => handleSettingChange('email', 'fromEmail', e.target.value)}
                        placeholder="noreply@university.edu"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">Reply-To Email</label>
                      <Input
                        value={settings.email.replyToEmail}
                        onChange={(e) => handleSettingChange('email', 'replyToEmail', e.target.value)}
                        placeholder="placement@university.edu"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">Offer Letter Template</label>
                      <Textarea
                        value={settings.email.offerLetterTemplate}
                        onChange={(e) => handleSettingChange('email', 'offerLetterTemplate', e.target.value)}
                        rows={4}
                        placeholder="Enter offer letter email template..."
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">Interview Invite Template</label>
                      <Textarea
                        value={settings.email.interviewInviteTemplate}
                        onChange={(e) => handleSettingChange('email', 'interviewInviteTemplate', e.target.value)}
                        rows={4}
                        placeholder="Enter interview invitation email template..."
                      />
                    </div>
                  </div>
                </div>
              )}

              {activeSection === 'whatsapp' && (
                <div className="space-y-6">
                  <h2 className="text-xl font-semibold">WhatsApp Integration</h2>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium">Enable WhatsApp Notifications</h3>
                        <p className="text-sm text-gray-500">Allow sending notifications via WhatsApp</p>
                      </div>
                      <Switch
                        checked={settings.whatsapp.enabled}
                        onCheckedChange={(checked) => handleSettingChange('whatsapp', 'enabled', checked)}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">API Key</label>
                      <Input
                        type="password"
                        value={settings.whatsapp.apiKey}
                        onChange={(e) => handleSettingChange('whatsapp', 'apiKey', e.target.value)}
                        placeholder="Enter WhatsApp Business API Key"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">Phone Number ID</label>
                      <Input
                        value={settings.whatsapp.phoneNumberId}
                        onChange={(e) => handleSettingChange('whatsapp', 'phoneNumberId', e.target.value)}
                        placeholder="Enter WhatsApp Phone Number ID"
                      />
                    </div>
                  </div>
                </div>
              )}

              {activeSection === 'system' && (
                <div className="space-y-6">
                  <h2 className="text-xl font-semibold">System Preferences</h2>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium">Allow Bulk Upload</h3>
                        <p className="text-sm text-gray-500">Enable bulk upload of student data</p>
                      </div>
                      <Switch
                        checked={settings.system.allowBulkUpload}
                        onCheckedChange={(checked) => handleSettingChange('system', 'allowBulkUpload', checked)}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium">Auto-verify Documents</h3>
                        <p className="text-sm text-gray-500">Automatically verify uploaded documents</p>
                      </div>
                      <Switch
                        checked={settings.system.autoVerifyDocuments}
                        onCheckedChange={(checked) => handleSettingChange('system', 'autoVerifyDocuments', checked)}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">Max File Size (MB)</label>
                      <Input
                        type="number"
                        value={settings.system.maxFileSize}
                        onChange={(e) => handleSettingChange('system', 'maxFileSize', parseInt(e.target.value))}
                        min={1}
                        max={20}
                      />
                    </div>
                  </div>
                </div>
              )}

              {activeSection === 'notifications' && (
                <div className="space-y-6">
                  <h2 className="text-xl font-semibold">Notification Settings</h2>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium">Email Notifications</h3>
                        <p className="text-sm text-gray-500">Send notifications via email</p>
                      </div>
                      <Switch
                        checked={settings.notifications.sendEmailNotifications}
                        onCheckedChange={(checked) => handleSettingChange('notifications', 'sendEmailNotifications', checked)}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium">WhatsApp Notifications</h3>
                        <p className="text-sm text-gray-500">Send notifications via WhatsApp</p>
                      </div>
                      <Switch
                        checked={settings.notifications.sendWhatsAppNotifications}
                        onCheckedChange={(checked) => handleSettingChange('notifications', 'sendWhatsAppNotifications', checked)}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium">Notify Unplaced Students</h3>
                        <p className="text-sm text-gray-500">Send regular updates to unplaced students</p>
                      </div>
                      <Switch
                        checked={settings.notifications.notifyUnplacedStudents}
                        onCheckedChange={(checked) => handleSettingChange('notifications', 'notifyUnplacedStudents', checked)}
                      />
                    </div>
                  </div>
                </div>
              )}

              {activeSection === 'documents' && (
                <div className="space-y-6">
                  <h2 className="text-xl font-semibold">Document Settings</h2>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium mb-1">Allowed File Types</label>
                      <Input
                        value={settings.documents.allowedFileTypes}
                        onChange={(e) => handleSettingChange('documents', 'allowedFileTypes', e.target.value)}
                        placeholder=".pdf,.doc,.docx"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">Max Documents per Student</label>
                      <Input
                        type="number"
                        value={settings.documents.maxDocumentsPerStudent}
                        onChange={(e) => handleSettingChange('documents', 'maxDocumentsPerStudent', parseInt(e.target.value))}
                        min={1}
                        max={20}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium">Require Transcript</h3>
                        <p className="text-sm text-gray-500">Make transcript upload mandatory</p>
                      </div>
                      <Switch
                        checked={settings.documents.requireTranscript}
                        onCheckedChange={(checked) => handleSettingChange('documents', 'requireTranscript', checked)}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium">Require Resume</h3>
                        <p className="text-sm text-gray-500">Make resume upload mandatory</p>
                      </div>
                      <Switch
                        checked={settings.documents.requireResume}
                        onCheckedChange={(checked) => handleSettingChange('documents', 'requireResume', checked)}
                      />
                    </div>
                  </div>
                </div>
              )}
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Settings;
