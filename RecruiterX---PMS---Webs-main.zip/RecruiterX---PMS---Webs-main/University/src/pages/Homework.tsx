import Layout from '@/Layout/Layout'

function Homework() {
  return (
    <Layout>Homework</Layout>
  )
}

export default Homework