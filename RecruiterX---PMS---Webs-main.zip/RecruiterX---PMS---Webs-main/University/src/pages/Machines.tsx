
import Layout from "@/Layout/Layout";// Assuming you have a Loader component

import ExamListPage from "@/components/Quizes/ExamList";

const Machines = () => {

  return (
    <Layout>
      <ExamListPage/>
     
    </Layout>
  );
};

export default Machines;
