import React from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useNavigate } from "react-router-dom";
import { toast } from "react-hot-toast";
import * as z from "zod";
import { FaGraduationCap } from "react-icons/fa";

const resetPasswordSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
});

type ResetPasswordFormValues = z.infer<typeof resetPasswordSchema>;

const ResetPassword = () => {
  const navigate = useNavigate();

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<ResetPasswordFormValues>({
    resolver: zodResolver(resetPasswordSchema),
  });

  const onSubmit = async (data: ResetPasswordFormValues) => {
    try {
      // Simulate reset password request (Replace with actual API call)
      await new Promise((resolve) => setTimeout(resolve, 1000));
      toast.success("Password reset email sent successfully");
      navigate("/auth/login");
    } catch (err) {
      toast.error("Failed to send reset email");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 px-6">
      <div className="w-full max-w-md bg-white lg rounded-lg p-6">
        {/* Header */}
        <div className="text-center">
          <FaGraduationCap className="h-12 w-12 text-indigo-600 mx-auto" />
          <h2 className="text-2xl font-bold mt-2">Reset Password</h2>
          <p className="text-gray-600 text-sm mt-1">
            Enter your email to receive a reset link.
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit(onSubmit)} className="mt-6 space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Email
            </label>
            <input
              type="email"
              {...register("email")}
              placeholder="Enter your email"
              className="mt-1 p-2 w-full border rounded-md focus:ring focus:ring-indigo-300"
            />
            {errors.email && (
              <p className="text-red-500 text-xs mt-1">{errors.email.message}</p>
            )}
          </div>

          <button
            type="submit"
            className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-2 rounded-md"
            disabled={isSubmitting}
          >
            {isSubmitting ? "Sending..." : "Send Reset Link"}
          </button>
        </form>

        {/* Footer */}
        <div className="mt-4 text-center">
          <button
            className="text-indigo-600 text-sm hover:underline"
            onClick={() => navigate("/auth/login")}
          >
            Back to Login
          </button>
        </div>
      </div>
    </div>
  );
};

export default ResetPassword;
