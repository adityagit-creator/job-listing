import React, { useEffect, useState } from 'react';
import Layout from '@/Layout/Layout';
import usePlacement from '@/hooks/usePlacement';
import { Student } from '@/types/placement';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { toast } from 'react-hot-toast';
import { FaWhatsapp, FaEnvelope, FaSms } from 'react-icons/fa';

const BulkCommunication = () => {
  const {
    students,
    loading,
    error,
    fetchStudents,
    sendBulkMessage,
  } = usePlacement();

  const [messageType, setMessageType] = useState<'email' | 'sms' | 'whatsapp'>('email');
  const [subject, setSubject] = useState('');
  const [content, setContent] = useState('');
  const [selectedStudents, setSelectedStudents] = useState<string[]>([]);
  const [filters, setFilters] = useState({
    branch: '',
    placementStatus: '',
  });

  useEffect(() => {
    fetchStudents();
  }, []);

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      const filteredStudents = students
        .filter(student => 
          (!filters.branch || student.branch === filters.branch) &&
          (!filters.placementStatus || student.placementStatus === filters.placementStatus)
        )
        .map(student => student.id);
      setSelectedStudents(filteredStudents);
    } else {
      setSelectedStudents([]);
    }
  };

  const handleStudentSelect = (studentId: string, checked: boolean) => {
    if (checked) {
      setSelectedStudents([...selectedStudents, studentId]);
    } else {
      setSelectedStudents(selectedStudents.filter(id => id !== studentId));
    }
  };

  const handleSendMessage = async () => {
    if (!selectedStudents.length) {
      toast.error('Please select at least one student');
      return;
    }

    if (!content) {
      toast.error('Please enter message content');
      return;
    }

    try {
      await sendBulkMessage(messageType, subject, content, selectedStudents);
      toast.success('Message sent successfully');
      setSubject('');
      setContent('');
      setSelectedStudents([]);
    } catch (err) {
      toast.error('Failed to send message');
    }
  };

  const filteredStudents = students.filter(student => 
    (!filters.branch || student.branch === filters.branch) &&
    (!filters.placementStatus || student.placementStatus === filters.placementStatus)
  );

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;

  return (
    <Layout>
      <div className="space-y-6">
        <h1 className="text-2xl font-bold">Bulk Communication</h1>

        {/* Message Type Selection */}
        <Card className="p-4">
          <div className="flex space-x-4">
            <Button
              variant={messageType === 'email' ? 'default' : 'outline'}
              onClick={() => setMessageType('email')}
            >
              <FaEnvelope className="mr-2" />
              Email
            </Button>
            <Button
              variant={messageType === 'whatsapp' ? 'default' : 'outline'}
              onClick={() => setMessageType('whatsapp')}
            >
              <FaWhatsapp className="mr-2" />
              WhatsApp
            </Button>
            <Button
              variant={messageType === 'sms' ? 'default' : 'outline'}
              onClick={() => setMessageType('sms')}
            >
              <FaSms className="mr-2" />
              SMS
            </Button>
          </div>
        </Card>

        {/* Filters */}
        <Card className="p-4">
          <h2 className="text-lg font-semibold mb-4">Filters</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block mb-1">Branch</label>
              <select
                className="w-full p-2 border rounded"
                value={filters.branch}
                onChange={(e) => setFilters({ ...filters, branch: e.target.value })}
              >
                <option value="">All Branches</option>
                <option value="CSE">Computer Science</option>
                <option value="ECE">Electronics</option>
                <option value="ME">Mechanical</option>
              </select>
            </div>
            <div>
              <label className="block mb-1">Placement Status</label>
              <select
                className="w-full p-2 border rounded"
                value={filters.placementStatus}
                onChange={(e) => setFilters({ ...filters, placementStatus: e.target.value })}
              >
                <option value="">All Status</option>
                <option value="placed">Placed</option>
                <option value="unplaced">Unplaced</option>
                <option value="inprocess">In Process</option>
              </select>
            </div>
          </div>
        </Card>

        {/* Message Composition */}
        <Card className="p-4">
          <h2 className="text-lg font-semibold mb-4">Compose Message</h2>
          {messageType === 'email' && (
            <div className="mb-4">
              <label className="block mb-1">Subject</label>
              <Input
                type="text"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="Enter email subject"
              />
            </div>
          )}
          <div>
            <label className="block mb-1">Message Content</label>
            <Textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              rows={6}
              placeholder="Enter your message"
            />
          </div>
        </Card>

        {/* Student Selection */}
        <Card className="p-4">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-semibold">Select Recipients</h2>
            <div className="flex items-center space-x-2">
              <Checkbox
                checked={selectedStudents.length === filteredStudents.length}
                onCheckedChange={handleSelectAll}
              />
              <span>Select All</span>
            </div>
          </div>
          <div className="space-y-2">
            {filteredStudents.map((student) => (
              <div key={student.id} className="flex items-center space-x-2 p-2 hover:bg-gray-50 rounded">
                <Checkbox
                  checked={selectedStudents.includes(student.id)}
                  onCheckedChange={(checked) => handleStudentSelect(student.id, checked as boolean)}
                />
                <span>{student.name} - {student.rollNumber}</span>
                <span className="text-gray-500">({student.branch})</span>
              </div>
            ))}
          </div>
        </Card>

        {/* Send Button */}
        <div className="flex justify-end">
          <Button
            onClick={handleSendMessage}
            disabled={!selectedStudents.length || !content}
            className="bg-indigo-600 hover:bg-indigo-700"
          >
            Send Message ({selectedStudents.length} recipients)
          </Button>
        </div>
      </div>
    </Layout>
  );
};

export default BulkCommunication; 