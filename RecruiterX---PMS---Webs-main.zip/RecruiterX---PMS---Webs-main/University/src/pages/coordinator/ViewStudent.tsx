import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { toast } from 'react-hot-toast';
import {
  User,
  GraduationCap,
  Briefcase,
  FileText,
  CheckCircle,
  XCircle,
  Pencil,
  ArrowLeft
} from 'lucide-react';
import Layout from '@/Layout/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useStudent } from '@/hooks/useStudent';
import CardLoading from '@/components/Helpers/card-loading';


const ViewStudent = () => {
  const { id } = useParams<{ id: string }>();
  const {
    selectedStudent,
    loading,
    error,
    fetchStudentById,
    updateStudentPlacementStatus,
  } = useStudent();
  const [isEditing, setIsEditing] = useState(false);

  useEffect(() => {
    if (id) fetchStudentById(id);
  }, [id]);

  const handleStatusUpdate = async (status: 'placed' | 'unplaced') => {
    try {
      if (!id) return;
      await updateStudentPlacementStatus(id, status);
      toast.success(`Student marked as ${status}`);
    } catch (error) {
      toast.error('Failed to update status');
    }
  };

  if (error) {
    return (
      <Layout>
        <div className="flex h-[50vh] items-center justify-center">
          <Card className="w-full max-w-md p-6">
            <div className="text-center">
              <XCircle className="mx-auto h-12 w-12 text-red-500" />
              <h3 className="mt-4 text-lg font-semibold">Error Loading Student</h3>
              <p className="mt-2 text-gray-600">{error}</p>
              <Button className="mt-4" variant="outline" onClick={() => window.history.back()}>
                <ArrowLeft className="mr-2 h-4 w-4" />
                Go Back
              </Button>
            </div>
          </Card>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto max-w-7xl px-4 py-6">
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Student Profile</h1>
            {selectedStudent && (
              <p className="mt-1 text-gray-500">
                {selectedStudent.rollNumber} · {selectedStudent.branch}
              </p>
            )}
          </div>
          <div className="flex gap-3">
            <Button variant="outline" onClick={() => window.history.back()}>
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back
            </Button>
            <Button onClick={() => setIsEditing(!isEditing)}>
              <Pencil className="mr-2 h-4 w-4" />
              {isEditing ? 'View Mode' : 'Edit Mode'}
            </Button>
          </div>
        </div>

        {loading ? (
          <div className="grid gap-6 md:grid-cols-2">
            {[1, 2, 3, 4].map((i) => (
              <Card key={i} className="overflow-hidden">
                <CardHeader className="pb-4">
                  <CardLoading className="h-6 w-1/3" />
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[1, 2, 3].map((j) => (
                      <div key={j}>
                        <CardLoading className="h-4 w-1/4 mb-1" />
                        <CardLoading className="h-4 w-3/4" />
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          selectedStudent && (
            <div className="grid gap-6 md:grid-cols-2">
              <Card className="overflow-hidden">
                <CardHeader className="border-b bg-gray-50/50">
                  <CardTitle className="flex items-center text-lg">
                    <User className="mr-2 h-5 w-5" />
                    Personal Information
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-6">
                  <dl className="space-y-4">
                    {[
                      { label: 'Name', value: selectedStudent.name },
                      { label: 'Email', value: selectedStudent.email },
                      { label: 'Phone', value: selectedStudent.phone },
                    ].map((item) => (
                      <div key={item.label}>
                        <dt className="text-sm font-medium text-gray-500">{item.label}</dt>
                        <dd className="mt-1">{item.value}</dd>
                      </div>
                    ))}
                  </dl>
                </CardContent>
              </Card>

              <Card className="overflow-hidden">
                <CardHeader className="border-b bg-gray-50/50">
                  <CardTitle className="flex items-center text-lg">
                    <GraduationCap className="mr-2 h-5 w-5" />
                    Academic Details
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-6">
                  <dl className="space-y-4">
                    <div>
                      <dt className="text-sm font-medium text-gray-500">CGPA</dt>
                      <dd className="mt-1">
                        <span className="inline-flex items-center rounded-full bg-blue-50 px-2.5 py-0.5 text-sm font-medium text-blue-700">
                          {selectedStudent.cgpa}
                        </span>
                      </dd>
                    </div>
                    <div>
                      <dt className="text-sm font-medium text-gray-500">Skills</dt>
                      <dd className="mt-2">
                        <div className="flex flex-wrap gap-2">
                          {selectedStudent.skills.map((skill, index) => (
                            <Badge key={index} variant="secondary">
                              {skill}
                            </Badge>
                          ))}
                        </div>
                      </dd>
                    </div>
                  </dl>
                </CardContent>
              </Card>

              <Card className="overflow-hidden">
                <CardHeader className="border-b bg-gray-50/50">
                  <CardTitle className="flex items-center text-lg">
                    <Briefcase className="mr-2 h-5 w-5" />
                    Placement Status
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <Badge
                      variant={
                        selectedStudent.placementStatus === 'placed'
                          ? 'success'
                          : 'warning'
                      }
                      className="text-sm"
                    >
                      {selectedStudent.placementStatus.toUpperCase()}
                    </Badge>
                    {isEditing && (
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleStatusUpdate('placed')}
                        >
                          <CheckCircle className="mr-2 h-4 w-4" />
                          Mark Placed
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleStatusUpdate('unplaced')}
                        >
                          <XCircle className="mr-2 h-4 w-4" />
                          Mark Unplaced
                        </Button>
                      </div>
                    )}
                  </div>

                  {selectedStudent.placementDetails && (
                    <dl className="mt-6 space-y-4">
                      {[
                        { label: 'Company', value: selectedStudent.placementDetails.companyName },
                        { label: 'Role', value: selectedStudent.placementDetails.role },
                        { label: 'Package', value: `₹${selectedStudent.placementDetails.package} LPA` },
                        { 
                          label: 'Offer Date', 
                          value: new Date(selectedStudent.placementDetails.offerDate).toLocaleDateString() 
                        },
                      ].map((item) => (
                        <div key={item.label}>
                          <dt className="text-sm font-medium text-gray-500">{item.label}</dt>
                          <dd className="mt-1">{item.value}</dd>
                        </div>
                      ))}
                    </dl>
                  )}
                </CardContent>
              </Card>

              <Card className="overflow-hidden">
                <CardHeader className="border-b bg-gray-50/50">
                  <CardTitle className="flex items-center text-lg">
                    <FileText className="mr-2 h-5 w-5" />
                    Interview History
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-6">
                  <div className="space-y-6">
                    {selectedStudent.interviews.map((interview, index) => (
                      <div
                        key={index}
                        className="relative border-l-2 border-blue-500 pl-4"
                      >
                        <div className="flex justify-between">
                          <div>
                            <h4 className="font-medium">{interview.companyName}</h4>
                            <p className="text-sm text-gray-500">
                              {interview.round} Round
                            </p>
                          </div>
                          <Badge
                            variant={
                              interview.status === 'completed'
                                ? 'success'
                                : 'warning'
                            }
                          >
                            {interview.status}
                          </Badge>
                        </div>
                        <div className="mt-2 text-sm text-gray-600">
                          <time>{new Date(interview.date).toLocaleDateString()}</time>
                          {interview.feedback && (
                            <p className="mt-1 italic">"{interview.feedback}"</p>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          )
        )}
      </div>
    </Layout>
  );
};

export default ViewStudent;