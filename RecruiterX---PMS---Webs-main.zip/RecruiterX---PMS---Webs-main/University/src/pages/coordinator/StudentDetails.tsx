import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import Layout from '@/Layout/Layout';
import { useStudent } from '@/hooks/useStudent';
import { Student } from '@/types/placement';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  FaUser,
  FaGraduationCap,
  FaClipboardList,
  FaCalendarAlt,
  FaFileAlt,
  FaBriefcase,
} from 'react-icons/fa';

const StudentDetails = () => {
  const { id } = useParams<{ id: string }>();
  const { fetchStudentById, loading } = useStudent();
  const [student, setStudent] = useState<Student | null>(null);

  useEffect(() => {
    if (id) {
      loadStudentDetails();
    }
  }, [id]);

  const loadStudentDetails = async () => {
    const data = await fetchStudentById(id!);
    setStudent(data);
  };

  if (loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-screen">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
        </div>
      </Layout>
    );
  }

  if (!student) {
    return (
      <Layout>
        <div className="text-center py-12">
          <h2 className="text-2xl font-semibold text-gray-700">Student not found</h2>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">{student.name}</h1>
            <p className="text-gray-600">{student.rollNumber}</p>
          </div>
          <Badge
            className={
              student.placementStatus === 'placed'
                ? 'bg-green-100 text-green-800'
                : student.placementStatus === 'debarred'
                ? 'bg-red-100 text-red-800'
                : 'bg-yellow-100 text-yellow-800'
            }
          >
            {student.placementStatus.toUpperCase()}
          </Badge>
        </div>

        <Tabs defaultValue="personal" className="w-full">
          <TabsList>
            <TabsTrigger value="personal">
              <FaUser className="mr-2" /> Personal Info
            </TabsTrigger>
            <TabsTrigger value="academic">
              <FaGraduationCap className="mr-2" /> Academic Details
            </TabsTrigger>
            <TabsTrigger value="assessments">
              <FaClipboardList className="mr-2" /> Assessments
            </TabsTrigger>
            <TabsTrigger value="interviews">
              <FaCalendarAlt className="mr-2" /> Interviews
            </TabsTrigger>
            <TabsTrigger value="documents">
              <FaFileAlt className="mr-2" /> Documents
            </TabsTrigger>
            {student.placementStatus === 'placed' && (
              <TabsTrigger value="placement">
                <FaBriefcase className="mr-2" /> Placement Details
              </TabsTrigger>
            )}
          </TabsList>

          <TabsContent value="personal">
            <Card>
              <CardHeader>
                <CardTitle>Personal Information</CardTitle>
              </CardHeader>
              <CardContent className="grid grid-cols-2 gap-4">
                <div>
                  <h3 className="font-medium text-gray-500">Email</h3>
                  <p>{student.email}</p>
                </div>
                <div>
                  <h3 className="font-medium text-gray-500">Phone</h3>
                  <p>{student.phone}</p>
                </div>
                <div>
                  <h3 className="font-medium text-gray-500">Date of Birth</h3>
                  <p>{new Date(student.personalDetails.dateOfBirth).toLocaleDateString()}</p>
                </div>
                <div>
                  <h3 className="font-medium text-gray-500">Gender</h3>
                  <p>{student.personalDetails.gender}</p>
                </div>
                <div>
                  <h3 className="font-medium text-gray-500">Category</h3>
                  <p>{student.personalDetails.category}</p>
                </div>
                <div>
                  <h3 className="font-medium text-gray-500">Address</h3>
                  <p>
                    {student.personalDetails.address}, {student.personalDetails.city},{' '}
                    {student.personalDetails.state} - {student.personalDetails.pincode}
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="academic">
            <Card>
              <CardHeader>
                <CardTitle>Academic Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h3 className="font-medium text-gray-500">Branch</h3>
                    <p>{student.branch}</p>
                  </div>
                  <div>
                    <h3 className="font-medium text-gray-500">Current CGPA</h3>
                    <p>{student.cgpa}</p>
                  </div>
                  <div>
                    <h3 className="font-medium text-gray-500">Batch Year</h3>
                    <p>{student.batchYear}</p>
                  </div>
                  <div>
                    <h3 className="font-medium text-gray-500">Semester</h3>
                    <p>{student.semester}</p>
                  </div>
                </div>

                <div className="border-t pt-4">
                  <h3 className="font-medium text-gray-500 mb-2">Previous Education</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <h4 className="text-sm font-medium">Class XII</h4>
                      <p>Board: {student.academicDetails.twelfthBoard}</p>
                      <p>Percentage: {student.academicDetails.twelfthPercentage}%</p>
                      <p>Year: {student.academicDetails.twelfthYear}</p>
                    </div>
                    <div>
                      <h4 className="text-sm font-medium">Class X</h4>
                      <p>Board: {student.academicDetails.tenthBoard}</p>
                      <p>Percentage: {student.academicDetails.tenthPercentage}%</p>
                      <p>Year: {student.academicDetails.tenthYear}</p>
                    </div>
                  </div>
                </div>

                <div className="border-t pt-4">
                  <h3 className="font-medium text-gray-500 mb-2">Backlogs</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <h4 className="text-sm font-medium">Total Backlogs</h4>
                      <p>{student.academicDetails.backlogs}</p>
                    </div>
                    <div>
                      <h4 className="text-sm font-medium">Active Backlogs</h4>
                      <p>{student.academicDetails.activeBacklogs}</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="assessments">
            <Card>
              <CardHeader>
                <CardTitle>Assessment History</CardTitle>
              </CardHeader>
              <CardContent>
                {student.assessments.length === 0 ? (
                  <p className="text-gray-500">No assessments taken yet</p>
                ) : (
                  <div className="space-y-4">
                    {student.assessments.map((assessment) => (
                      <div key={assessment.id} className="border rounded-lg p-4">
                        <div className="flex justify-between items-start">
                          <div>
                            <h3 className="font-medium">{assessment.title}</h3>
                            <p className="text-sm text-gray-500">
                              Date: {new Date(assessment.date).toLocaleDateString()}
                            </p>
                          </div>
                          <Badge
                            className={
                              assessment.status === 'completed'
                                ? 'bg-green-100 text-green-800'
                                : assessment.status === 'missed'
                                ? 'bg-red-100 text-red-800'
                                : 'bg-yellow-100 text-yellow-800'
                            }
                          >
                            {assessment.status.toUpperCase()}
                          </Badge>
                        </div>
                        {assessment.status === 'completed' && (
                          <div className="mt-2">
                            <p className="text-sm">
                              Score: {assessment.score}/{assessment.maxScore} (
                              {((assessment.score / assessment.maxScore) * 100).toFixed(1)}%)
                            </p>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="interviews">
            <Card>
              <CardHeader>
                <CardTitle>Interview History</CardTitle>
              </CardHeader>
              <CardContent>
                {student.interviews.length === 0 ? (
                  <p className="text-gray-500">No interviews scheduled yet</p>
                ) : (
                  <div className="space-y-4">
                    {student.interviews.map((interview) => (
                      <div key={interview.id} className="border rounded-lg p-4">
                        <div className="flex justify-between items-start">
                          <div>
                            <h3 className="font-medium">{interview.companyName}</h3>
                            <p className="text-sm text-gray-500">
                              Round: {interview.round}
                            </p>
                            <p className="text-sm text-gray-500">
                              Date: {new Date(interview.date).toLocaleDateString()}
                            </p>
                          </div>
                          <Badge
                            className={
                              interview.status === 'completed'
                                ? 'bg-green-100 text-green-800'
                                : interview.status === 'cancelled'
                                ? 'bg-red-100 text-red-800'
                                : 'bg-yellow-100 text-yellow-800'
                            }
                          >
                            {interview.status.toUpperCase()}
                          </Badge>
                        </div>
                        {interview.feedback && (
                          <div className="mt-2">
                            <h4 className="text-sm font-medium">Feedback</h4>
                            <p className="text-sm text-gray-600">{interview.feedback}</p>
                          </div>
                        )}
                        {interview.result && (
                          <div className="mt-2">
                            <Badge
                              className={
                                interview.result === 'selected'
                                  ? 'bg-green-100 text-green-800'
                                  : interview.result === 'rejected'
                                  ? 'bg-red-100 text-red-800'
                                  : 'bg-yellow-100 text-yellow-800'
                              }
                            >
                              {interview.result.toUpperCase()}
                            </Badge>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="documents">
            <Card>
              <CardHeader>
                <CardTitle>Documents</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {student.documents.map((doc, index) => (
                    <div key={index} className="border rounded-lg p-4">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="font-medium capitalize">{doc.type.replace('_', ' ')}</h3>
                          <p className="text-sm text-gray-500">
                            Uploaded: {new Date(doc.uploadedAt).toLocaleDateString()}
                          </p>
                        </div>
                        <div className="space-x-2">
                          <Badge
                            className={
                              doc.verified
                                ? 'bg-green-100 text-green-800'
                                : 'bg-yellow-100 text-yellow-800'
                            }
                          >
                            {doc.verified ? 'VERIFIED' : 'PENDING'}
                          </Badge>
                          <a
                            href={doc.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center text-indigo-600 hover:text-indigo-800"
                          >
                            <FaFileAlt className="mr-1" /> View
                          </a>
                        </div>
                      </div>
                      {doc.verifiedBy && (
                        <div className="mt-2 text-sm text-gray-500">
                          Verified by: {doc.verifiedBy} on{' '}
                          {new Date(doc.verifiedAt!).toLocaleDateString()}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {student.placementStatus === 'placed' && (
            <TabsContent value="placement">
              <Card>
                <CardHeader>
                  <CardTitle>Placement Details</CardTitle>
                </CardHeader>
                <CardContent className="grid grid-cols-2 gap-4">
                  <div>
                    <h3 className="font-medium text-gray-500">Company</h3>
                    <p>{student.placementDetails?.companyName}</p>
                  </div>
                  <div>
                    <h3 className="font-medium text-gray-500">Role</h3>
                    <p>{student.placementDetails?.role}</p>
                  </div>
                  <div>
                    <h3 className="font-medium text-gray-500">Package (LPA)</h3>
                    <p>{student.placementDetails?.package}</p>
                  </div>
                  <div>
                    <h3 className="font-medium text-gray-500">Offer Date</h3>
                    <p>
                      {new Date(student.placementDetails?.offerDate!).toLocaleDateString()}
                    </p>
                  </div>
                  {student.placementDetails?.joiningDate && (
                    <div>
                      <h3 className="font-medium text-gray-500">Joining Date</h3>
                      <p>
                        {new Date(student.placementDetails.joiningDate).toLocaleDateString()}
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          )}
        </Tabs>
      </div>
    </Layout>
  );
};

export default StudentDetails; 