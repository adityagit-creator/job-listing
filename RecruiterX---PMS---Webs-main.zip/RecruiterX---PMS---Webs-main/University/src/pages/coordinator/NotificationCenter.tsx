import React, { useState } from 'react';
import Layout from '@/Layout/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { toast } from 'react-hot-toast';
import { sendNotification } from '@/services/notificationService';
import {
  FaBell,
  FaWhatsapp,
  FaEnvelope,
  FaMobile,
  FaFilter,
  FaHistory,
} from 'react-icons/fa';

const NotificationCenter = () => {
  const [notificationData, setNotificationData] = useState({
    title: '',
    message: '',
    type: 'general',
    priority: 'medium',
    recipients: {
      branches: [] as string[],
      batchYear: '',
      placementStatus: '',
      cgpaCriteria: 0,
    },
    sentVia: [] as ('app' | 'whatsapp' | 'email')[],
  });

  const [showHistory, setShowHistory] = useState(false);

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setNotificationData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleRecipientsChange = (field: string, value: string | string[]) => {
    setNotificationData((prev) => ({
      ...prev,
      recipients: {
        ...prev.recipients,
        [field]: value,
      },
    }));
  };

  const handleChannelToggle = (channel: 'app' | 'whatsapp' | 'email') => {
    setNotificationData((prev) => ({
      ...prev,
      sentVia: prev.sentVia.includes(channel)
        ? prev.sentVia.filter((ch) => ch !== channel)
        : [...prev.sentVia, channel],
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (!notificationData.sentVia.length) {
        toast.error('Please select at least one notification channel');
        return;
      }

      await sendNotification(notificationData);
      toast.success('Notification sent successfully');
      
      // Reset form
      setNotificationData({
        title: '',
        message: '',
        type: 'general',
        priority: 'medium',
        recipients: {
          branches: [],
          batchYear: '',
          placementStatus: '',
          cgpaCriteria: 0,
        },
        sentVia: [],
      });
    } catch (error) {
      console.error('Error sending notification:', error);
      toast.error('Failed to send notification');
    }
  };

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold">Notification Center</h1>
            <p className="text-gray-600">Send notifications to students</p>
          </div>
          <Button
            variant="outline"
            onClick={() => setShowHistory(!showHistory)}
          >
            <FaHistory className="mr-2" />
            {showHistory ? 'New Notification' : 'View History'}
          </Button>
        </div>

        {!showHistory ? (
          <form onSubmit={handleSubmit} className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Compose Notification</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Title</label>
                  <Input
                    name="title"
                    value={notificationData.title}
                    onChange={handleInputChange}
                    placeholder="Enter notification title"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Message</label>
                  <Textarea
                    name="message"
                    value={notificationData.message}
                    onChange={handleInputChange}
                    placeholder="Enter notification message"
                    required
                    rows={4}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
  <div>
    <label className="block text-sm font-medium mb-1">Type</label>
    <select
      value={notificationData.type}
      onChange={(e) =>
        setNotificationData((prev) => ({ ...prev, type: e.target.value }))
      }
      className="w-full p-2 border rounded"
    >
      <option value="">Select type</option>
      <option value="general">General</option>
      <option value="placement">Placement</option>
      <option value="assessment">Assessment</option>
      <option value="interview">Interview</option>
      <option value="document">Document</option>
    </select>
  </div>

  <div>
    <label className="block text-sm font-medium mb-1">Priority</label>
    <select
      value={notificationData.priority}
      onChange={(e) =>
        setNotificationData((prev) => ({ ...prev, priority: e.target.value }))
      }
      className="w-full p-2 border rounded"
    >
      <option value="">Select priority</option>
      <option value="high">High</option>
      <option value="medium">Medium</option>
      <option value="low">Low</option>
    </select>
  </div>
</div>

              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <FaFilter className="mr-2" />
                  Recipients Filter
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
  <div>
    <label className="block text-sm font-medium mb-1">Branch</label>
    <select
      value={notificationData.recipients.branches[0] || ''}
      onChange={(e) =>
        handleRecipientsChange('branches', [e.target.value])
      }
      className="w-full p-2 border rounded"
    >
      <option value="">All Branches</option>
      <option value="CSE">Computer Science</option>
      <option value="ECE">Electronics</option>
      <option value="ME">Mechanical</option>
      <option value="CE">Civil</option>
    </select>
  </div>

  <div>
    <label className="block text-sm font-medium mb-1">Batch Year</label>
    <select
      value={notificationData.recipients.batchYear}
      onChange={(e) =>
        handleRecipientsChange('batchYear', e.target.value)
      }
      className="w-full p-2 border rounded"
    >
      <option value="">All Batches</option>
      <option value="2024">2024</option>
      <option value="2025">2025</option>
      <option value="2026">2026</option>
    </select>
  </div>

  <div>
    <label className="block text-sm font-medium mb-1">Placement Status</label>
    <select
      value={notificationData.recipients.placementStatus}
      onChange={(e) =>
        handleRecipientsChange('placementStatus', e.target.value)
      }
      className="w-full p-2 border rounded"
    >
      <option value="">All Students</option>
      <option value="placed">Placed</option>
      <option value="unplaced">Unplaced</option>
    </select>
  </div>

  <div>
    <label className="block text-sm font-medium mb-1">Minimum CGPA</label>
    <input
      type="number"
      step="0.01"
      min="0"
      max="10"
      value={notificationData.recipients.cgpaCriteria || ''}
      onChange={(e) =>
        handleRecipientsChange('cgpaCriteria', parseFloat(e.target.value))
      }
      placeholder="Enter minimum CGPA"
      className="w-full p-2 border rounded"
    />
  </div>
</div>

              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Notification Channels</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex space-x-4">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      checked={notificationData.sentVia.includes('app')}
                      onCheckedChange={() => handleChannelToggle('app')}
                    />
                    <label className="flex items-center space-x-1">
                      <FaMobile />
                      <span>App</span>
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      checked={notificationData.sentVia.includes('whatsapp')}
                      onCheckedChange={() => handleChannelToggle('whatsapp')}
                    />
                    <label className="flex items-center space-x-1">
                      <FaWhatsapp className="text-green-500" />
                      <span>WhatsApp</span>
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      checked={notificationData.sentVia.includes('email')}
                      onCheckedChange={() => handleChannelToggle('email')}
                    />
                    <label className="flex items-center space-x-1">
                      <FaEnvelope />
                      <span>Email</span>
                    </label>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Button type="submit" className="w-full">
              <FaBell className="mr-2" />
              Send Notification
            </Button>
          </form>
        ) : (
          <Card>
            <CardHeader>
              <CardTitle>Notification History</CardTitle>
            </CardHeader>
            <CardContent>
              {/* Add notification history component here */}
              <div className="text-center text-gray-500 py-8">
                Notification history will be implemented in the next phase
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </Layout>
  );
};

export default NotificationCenter; 