import React, { useEffect, useState } from 'react';
import Layout from '@/Layout/Layout';
import usePlacement from '@/hooks/usePlacement';
import { Document } from '@/types/placement';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'react-hot-toast';
import { FaCheck, FaTimes, FaDownload } from 'react-icons/fa';

const DocumentVerification = () => {
  const {
    students,
    documents,
    loading,
    error,
    fetchStudents,
    fetchDocuments,
  } = usePlacement();

  const [selectedStudent, setSelectedStudent] = useState<string>('');
  const [verificationComment, setVerificationComment] = useState<string>('');

  useEffect(() => {
    fetchStudents();
  }, []);

  useEffect(() => {
    if (selectedStudent) {
      fetchDocuments(selectedStudent);
    }
  }, [selectedStudent]);

  const handleVerification = async (documentId: string, status: Document['status']) => {
    try {
      // Implement document verification logic here
      toast.success(`Document ${status === 'verified' ? 'verified' : 'rejected'} successfully`);
      if (selectedStudent) {
        fetchDocuments(selectedStudent);
      }
    } catch (err) {
      toast.error('Failed to verify document');
    }
  };

  const getStatusBadge = (status: Document['status']) => {
    switch (status) {
      case 'verified':
        return <Badge className="bg-green-500">Verified</Badge>;
      case 'rejected':
        return <Badge className="bg-red-500">Rejected</Badge>;
      default:
        return <Badge className="bg-yellow-500">Pending</Badge>;
    }
  };

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;

  return (
    <Layout>
      <div className="space-y-6">
        <h1 className="text-2xl font-bold">Document Verification</h1>

        {/* Student Selection */}
        <div className="bg-white rounded-lg shadow p-4">
          <label className="block mb-2">Select Student</label>
          <select
            className="w-full p-2 border rounded"
            value={selectedStudent}
            onChange={(e) => setSelectedStudent(e.target.value)}
          >
            <option value="">Select a student</option>
            {students.map((student) => (
              <option key={student.id} value={student.id}>
                {student.name} - {student.rollNumber}
              </option>
            ))}
          </select>
        </div>

        {/* Document List */}
        {selectedStudent && (
          <div className="space-y-4">
            <h2 className="text-xl font-semibold">Documents</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {documents.map((doc) => (
                <Card key={doc.id} className="p-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-semibold text-lg capitalize">{doc.type}</h3>
                      <p className="text-gray-600">
                        Uploaded on: {new Date(doc.verifiedAt || '').toLocaleDateString()}
                      </p>
                    </div>
                    {getStatusBadge(doc.status)}
                  </div>

                  <div className="mt-4 space-y-2">
                    {doc.comments && (
                      <p className="text-sm text-gray-600">
                        <strong>Comments:</strong> {doc.comments}
                      </p>
                    )}
                    {doc.verifiedBy && (
                      <p className="text-sm text-gray-600">
                        <strong>Verified By:</strong> {doc.verifiedBy}
                      </p>
                    )}
                  </div>

                  <div className="mt-4">
                    <Textarea
                      placeholder="Add verification comments..."
                      value={verificationComment}
                      onChange={(e) => setVerificationComment(e.target.value)}
                      className="mb-4"
                    />
                    <div className="flex space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => window.open(doc.url, '_blank')}
                      >
                        <FaDownload className="mr-2" />
                        View Document
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="text-green-600"
                        onClick={() => handleVerification(doc.id, 'verified')}
                      >
                        <FaCheck className="mr-2" />
                        Verify
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="text-red-600"
                        onClick={() => handleVerification(doc.id, 'rejected')}
                      >
                        <FaTimes className="mr-2" />
                        Reject
                      </Button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default DocumentVerification; 