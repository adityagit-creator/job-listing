import React, { useState, useEffect } from 'react';
import { toast } from 'react-hot-toast';
import {
  Building,
  Search,
  Users,
  Eye,
  FileText,
  CheckCircle,
  Clock,
  Calendar,
  BarChart3,
  BriefcaseIcon,
  Mail,
  Phone,
  Globe,
  MoreHorizontal,
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import Layout from '@/Layout/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import CardLoading from '@/components/Helpers/card-loading';
import AddJobPosting from '@/components/Jobs/AddJobPosting';
import { db } from '@/config/firebase';
import {
  collection,
  getDocs,
  query,
  where,
  orderBy,
  deleteDoc,
  doc,
  updateDoc
} from 'firebase/firestore';

interface JobPosting {
  id: string;
  companyName: string;
  industry: string;
  jobTitle: string;
  description: string;
  location: string[];
  package: {
    ctc: number;
    breakup: any;
  };
  eligibility: {
    minimumCGPA: number;
    allowedBranches: string[];
  };
  status: 'active' | 'inactive' | 'draft';
  applicationStats: {
    views: number;
    applications: number;
    shortlisted: number;
  };
  contactInfo: {
    email: string;
    phone: string;
    website: string;
  };
  createdAt: Date;
}

const JobManagement = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [jobs, setJobs] = useState<JobPosting[]>([]);
  const [filters, setFilters] = useState({
    search: '',
    industry: '',
    status: '',
  });

  const [stats, setStats] = useState({
    totalCompanies: 0,
    activeJobs: 0,
    totalApplications: 0,
    placementRate: '0%',
    topCompanies: [],
  });

  // Fetch jobs and stats from Firestore
  const fetchJobs = async () => {
    try {
      setLoading(true);
      const jobsRef = collection(db, 'jobPostings');
      let q = query(jobsRef, orderBy('createdAt', 'desc'));

      // Apply filters
      if (filters.industry) {
        q = query(q, where('industry', '==', filters.industry));
      }
      if (filters.status) {
        q = query(q, where('status', '==', filters.status));
      }

      const querySnapshot = await getDocs(q);
      const jobsData = querySnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
        createdAt: doc.data().createdAt?.toDate(),
      })) as JobPosting[];

      // Apply search filter client-side
      const filteredJobs = filters.search
        ? jobsData.filter(job =>
            job.companyName.toLowerCase().includes(filters.search.toLowerCase()) ||
            job.jobTitle.toLowerCase().includes(filters.search.toLowerCase())
          )
        : jobsData;

      setJobs(filteredJobs);

      // Calculate stats
      const stats = {
        totalCompanies: new Set(jobsData.map(job => job.companyName)).size,
        activeJobs: jobsData.filter(job => job.status === 'active').length,
        totalApplications: jobsData.reduce((acc, job) => acc + (job.applicationStats?.applications || 0), 0),
        placementRate: calculatePlacementRate(jobsData),
        topCompanies: calculateTopCompanies(jobsData),
      };

      setStats(stats);
    } catch (error) {
      console.error('Error fetching jobs:', error);
      toast.error('Failed to fetch jobs');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchJobs();
  }, [filters]);

  const calculatePlacementRate = (jobs: JobPosting[]) => {
    const totalApplications = jobs.reduce((acc, job) => acc + (job.applicationStats?.applications || 0), 0);
    const totalPlacements = jobs.reduce((acc, job) => acc + (job.applicationStats?.shortlisted || 0), 0);
    return totalApplications > 0 ? `${Math.round((totalPlacements / totalApplications) * 100)}%` : '0%';
  };

  const calculateTopCompanies = (jobs: JobPosting[]) => {
    const companyStats = jobs.reduce((acc, job) => {
      if (!acc[job.companyName]) {
        acc[job.companyName] = {
          hires: job.applicationStats?.shortlisted || 0,
          package: job.package?.ctc || 0,
        };
      } else {
        acc[job.companyName].hires += job.applicationStats?.shortlisted || 0;
      }
      return acc;
    }, {} as Record<string, { hires: number; package: number }>);

    return Object.entries(companyStats)
      .sort(([, a], [, b]) => b.hires - a.hires)
      .slice(0, 3)
      .map(([name, stats]) => ({
        name,
        hires: stats.hires,
        package: `${stats.package} LPA`,
      }));
  };

  const handleDeleteJob = async (jobId: string) => {
    try {
      await deleteDoc(doc(db, 'jobPostings', jobId));
      toast.success('Job deleted successfully');
      fetchJobs();
    } catch (error) {
      console.error('Error deleting job:', error);
      toast.error('Failed to delete job');
    }
  };

  const handleUpdateJobStatus = async (jobId: string, status: 'active' | 'inactive') => {
    try {
      await updateDoc(doc(db, 'jobPostings', jobId), { status });
      toast.success('Job status updated successfully');
      fetchJobs();
    } catch (error) {
      console.error('Error updating job status:', error);
      toast.error('Failed to update job status');
    }
  };

  if (loading) {
    return (
      <Layout>
        <div className="container mx-auto max-w-7xl p-6">
          <div className="grid gap-6">
            {[1, 2, 3].map((i) => (
              <CardLoading key={i} />
            ))}
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto max-w-7xl p-6">
        {/* Header */}
        <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Job Management</h1>
            <p className="mt-1 text-gray-500">
              Track and manage company partnerships and recruitment activities
            </p>
          </div>
          <AddJobPosting onSuccess={fetchJobs} />
        </div>

        {/* Analytics Overview */}
        <div className="mb-6 grid gap-6 md:grid-cols-4">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500">Total Companies</p>
                  <h3 className="text-2xl font-bold">{stats.totalCompanies}</h3>
                </div>
                <Building className="h-8 w-8 text-primary/20" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500">Active Jobs</p>
                  <h3 className="text-2xl font-bold">{stats.activeJobs}</h3>
                </div>
                <BriefcaseIcon className="h-8 w-8 text-primary/20" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500">Total Applications</p>
                  <h3 className="text-2xl font-bold">{stats.totalApplications}</h3>
                </div>
                <FileText className="h-8 w-8 text-primary/20" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500">Placement Rate</p>
                  <h3 className="text-2xl font-bold">{stats.placementRate}</h3>
                </div>
                <BarChart3 className="h-8 w-8 text-primary/20" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Tabs */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="jobs">Jobs & Applications</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            {/* Filters */}
            <Card className="mb-6">
              <CardContent className="p-4">
                <div className="grid gap-4 md:grid-cols-3">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                    <Input
                      placeholder="Search jobs..."
                      value={filters.search}
                      onChange={(e) => setFilters({ ...filters, search: e.target.value })}
                      className="pl-9"
                    />
                  </div>
                  <select
                    className="rounded-md border border-gray-300 p-2"
                    value={filters.industry}
                    onChange={(e) => setFilters({ ...filters, industry: e.target.value })}
                  >
                    <option value="">All Industries</option>
                    <option value="Technology">Technology</option>
                    <option value="Finance">Finance</option>
                    <option value="Healthcare">Healthcare</option>
                    <option value="Manufacturing">Manufacturing</option>
                  </select>
                  <select
                    className="rounded-md border border-gray-300 p-2"
                    value={filters.status}
                    onChange={(e) => setFilters({ ...filters, status: e.target.value })}
                  >
                    <option value="">All Status</option>
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                  </select>
                </div>
              </CardContent>
            </Card>

            {/* Job Cards Grid */}
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {jobs.map((job) => (
                <Card key={job.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                  <CardHeader className="border-b bg-gray-50/50 p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                          <Building className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                        <CardTitle className="text-lg font-semibold">{job.companyName}</CardTitle>
                        <p className="text-sm text-gray-500">{job.jobTitle}</p>
                        </div>
                      </div>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => navigate(`/jobs/${job.id}/edit`)}>
                            Edit Details
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleUpdateJobStatus(job.id, job.status === 'active' ? 'inactive' : 'active')}>
                            {job.status === 'active' ? 'Deactivate' : 'Activate'}
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleDeleteJob(job.id)} className="text-red-600">
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </CardHeader>
                  <CardContent className="p-4 space-y-3">
      <p className="text-sm text-gray-600">{job.description}</p>
      
      <div className="grid grid-cols-2 gap-4 border-t pt-4">
        <div>
          <p className="text-sm text-gray-500">CTC</p>
          <p className="text-lg font-semibold">{job.package?.ctc} LPA</p>
        </div>
        <div>
          <p className="text-sm text-gray-500">Location</p>
          <p className="text-lg font-semibold">{job.location?.join(', ')}</p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <p className="text-sm text-gray-500">Mode</p>
          <p className="text-lg font-semibold capitalize">{job.mode}</p>
        </div>
        <div>
          <p className="text-sm text-gray-500">Deadline</p>
          <p className="text-lg font-semibold">{new Date(job.deadline).toLocaleDateString()}</p>
        </div>
      </div>

      <div className="border-t pt-4 flex justify-between items-center">
        <p className="text-sm text-gray-500">Applications</p>
        <p className="text-lg font-semibold">{job.stats?.numberOfStudentsApplied}</p>
      </div>
    </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="jobs">
            <div className="space-y-6">
              {/* Application Status Cards */}
              <div className="grid gap-6 md:grid-cols-4">
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-2">
                      <Eye className="h-4 w-4 text-gray-400" />
                      <div>
                        <p className="text-sm text-gray-500">Profile Views</p>
                        <p className="text-lg font-semibold">1,234</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-2">
                      <FileText className="h-4 w-4 text-gray-400" />
                      <div>
                        <p className="text-sm text-gray-500">Applications</p>
                        <p className="text-lg font-semibold">856</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-2">
                      <CheckCircle className="h-4 w-4 text-gray-400" />
                      <div>
                        <p className="text-sm text-gray-500">Shortlisted</p>
                        <p className="text-lg font-semibold">245</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-2">
                      <Clock className="h-4 w-4 text-gray-400" />
                      <div>
                        <p className="text-sm text-gray-500">Pending Review</p>
                        <p className="text-lg font-semibold">123</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Recent Applications */}
              <Card>
                <CardHeader>
                  <CardTitle>Recent Applications</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {/* Application items would go here */}
                    <div className="flex items-center justify-between border-b pb-4">
                      <div className="flex items-center space-x-4">
                        <div className="h-10 w-10 rounded-full bg-gray-100 flex items-center justify-center">
                          <Users className="h-5 w-5 text-gray-600" />
                        </div>
                        <div>
                          <p className="font-medium">John Doe</p>
                          <p className="text-sm text-gray-500">Software Engineer Position</p>
                        </div>
                      </div>
                      <Badge variant="outline">Under Review</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="analytics">
            <div className="grid gap-6 md:grid-cols-2">
              {/* Top Companies */}
              <Card>
                <CardHeader>
                  <CardTitle>Top Hiring Companies</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {stats.topCompanies.map((company, index) => (
                      <div key={index} className="flex items-center justify-between border-b pb-4">
                        <div>
                          <p className="font-medium">{company.name}</p>
                          <p className="text-sm text-gray-500">{company.hires} Students Hired</p>
                        </div>
                        <Badge variant="outline">{company.package}</Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Placement Timeline */}
              <Card>
                <CardHeader>
                  <CardTitle>Placement Timeline</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center space-x-4">
                      <Calendar className="h-5 w-5 text-gray-400" />
                      <div>
                        <p className="font-medium">Campus Drive - Tech Corp</p>
                        <p className="text-sm text-gray-500">Next Week</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <Calendar className="h-5 w-5 text-gray-400" />
                      <div>
                        <p className="font-medium">Technical Assessment - Finance Inc</p>
                        <p className="text-sm text-gray-500">In 2 Weeks</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
};

export default JobManagement;
