import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-hot-toast';
import { FaUserPlus, FaFileUpload, FaSearch, FaDownload, FaEye, FaEdit, FaTrash } from 'react-icons/fa';
import Layout from '@/Layout/Layout';
import { useStudent } from '@/hooks/useStudent';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import * as XLSX from 'xlsx';

interface ExcelRow {
  name: string;
  email: string;
  phone: string;
  rollNumber: string;
  branch: string;
  semester: string;
  batchYear: string;
  cgpa: string;
  skills: string;
  linkedIn?: string;
  github?: string;
}

const StudentTable = ({ students, onView, onEdit, onDelete }) => {
  return (
    <div className="bg-white rounded-lg shadow overflow-hidden">
      <table className="min-w-full">
        <thead className="bg-gray-50">
          <tr>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Student
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Roll Number
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Branch
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Batch
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              CGPA
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Status
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Actions
            </th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {students.map((student) => (
            <tr key={student.id}>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="flex items-center">
                  <div>
                    <div className="text-sm font-medium text-gray-900">{student.name}</div>
                    <div className="text-sm text-gray-500">{student.email}</div>
                  </div>
                </div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm text-gray-900">{student.rollNumber}</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm text-gray-900">{student.branch}</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm text-gray-900">{student.batchYear}</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm text-gray-900">{student.cgpa}</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full
                  ${student.placementStatus === 'placed' ? 'bg-green-100 text-green-800' :
                  student.placementStatus === 'debarred' ? 'bg-red-100 text-red-800' :
                  'bg-yellow-100 text-yellow-800'}`}>
                  {student.placementStatus}
                </span>
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                <div className="flex space-x-2">
                  <Button variant="ghost" size="sm" onClick={() => onView(student.id)}>
                    <FaEye className="text-blue-600" />
                  </Button>
                  <Button variant="ghost" size="sm" onClick={() => onEdit(student.id)}>
                    <FaEdit className="text-green-600" />
                  </Button>
                  <Button variant="ghost" size="sm" onClick={() => onDelete(student.id)}>
                    <FaTrash className="text-red-600" />
                  </Button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

const StudentFilters = ({ filters, setFilters }) => {
  return (
    <Card className="p-4">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="relative">
          <FaSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          <Input
            placeholder="Search students..."
            value={filters.search}
            onChange={(e) => setFilters({ ...filters, search: e.target.value })}
            className="pl-10"
          />
        </div>
        <select
          className="p-2 border rounded"
          value={filters.branch}
          onChange={(e) => setFilters({ ...filters, branch: e.target.value })}
        >
          <option value="">All Branches</option>
          <option value="CSE">Computer Science</option>
          <option value="ECE">Electronics</option>
          <option value="ME">Mechanical</option>
          <option value="CE">Civil</option>
        </select>
        <select
          className="p-2 border rounded"
          value={filters.batch}
          onChange={(e) => setFilters({ ...filters, batch: e.target.value })}
        >
          <option value="">All Batches</option>
          <option value="2024">2024</option>
          <option value="2025">2025</option>
          <option value="2026">2026</option>
        </select>
        <select
          className="p-2 border rounded"
          value={filters.status}
          onChange={(e) => setFilters({ ...filters, status: e.target.value })}
        >
          <option value="">All Status</option>
          <option value="placed">Placed</option>
          <option value="unplaced">Unplaced</option>
          <option value="debarred">Debarred</option>
        </select>
      </div>
    </Card>
  );
};

const BulkUploadModal = ({ isOpen, onClose, onUpload }) => {
  const [file, setFile] = useState(null);

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  const handleUpload = () => {
    if (file) {
      onUpload(file);
      onClose();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Bulk Upload Students</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <Input type="file" accept=".xlsx,.xls" onChange={handleFileChange} />
          <Button onClick={handleUpload}>Upload</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

const StudentManagement = () => {
  const navigate = useNavigate();
  const {
    students,
    loading,
    error,
    fetchStudents,
    createStudent,
    updateStudentDetails,
    removeStudent,
    uploadBulkStudents,
  } = useStudent();

  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showBulkUploadModal, setShowBulkUploadModal] = useState(false);
  const [filters, setFilters] = useState({
    search: '',
    branch: '',
    batch: '',
    status: '',
  });

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    rollNumber: '',
    branch: '',
    semester: '',
    batchYear: '',
    cgpa: '',
    skills: '',
    linkedIn: '',
    github: '',
    resume: null as File | null,
  });

  useEffect(() => {
    fetchStudents();
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleFileChange = (e) => {
    const file = e.target.files?.[0];
    if (file) {
      setFormData(prev => ({
        ...prev,
        resume: file
      }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const studentData = {
        name: formData.name,
        email: formData.email,
        phone: formData.phone,
        rollNumber: formData.rollNumber,
        branch: formData.branch,
        semester: parseInt(formData.semester),
        batchYear: formData.batchYear,
        cgpa: parseFloat(formData.cgpa),
        skills: formData.skills.split(',').map(skill => skill.trim()),
        linkedIn: formData.linkedIn,
        github: formData.github,
        placementStatus: 'unplaced' as const,
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      await createStudent(studentData, formData.resume || undefined);
      setShowAddDialog(false);
      resetForm();
    } catch (error) {
      console.error('Error adding student:', error);
      toast.error('Failed to add student');
    }
  };

  const handleViewStudent = (id) => {
    navigate(`/coordinator/student/${id}`);
  };

  const handleBulkUpload = async (file) => {
    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const data = new Uint8Array(event.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const jsonData = XLSX.utils.sheet_to_json(worksheet) as ExcelRow[];

        const formattedData = jsonData.map(row => ({
          name: row.name,
          email: row.email,
          phone: row.phone,
          rollNumber: row.rollNumber,
          branch: row.branch,
          semester: parseInt(row.semester),
          batchYear: row.batchYear,
          cgpa: parseFloat(row.cgpa),
          skills: row.skills.split(',').map(skill => skill.trim()),
          linkedIn: row.linkedIn,
          github: row.github,
          placementStatus: 'unplaced' as const,
          createdAt: new Date(),
          updatedAt: new Date(),
        }));

        await uploadBulkStudents(formattedData);
        toast.success('Students uploaded successfully');
      } catch (error) {
        console.error('Error processing file:', error);
        toast.error('Failed to process file. Please check the file format.');
      }
    };
    reader.readAsArrayBuffer(file);
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this student?')) {
      await removeStudent(id);
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      email: '',
      phone: '',
      rollNumber: '',
      branch: '',
      semester: '',
      batchYear: '',
      cgpa: '',
      skills: '',
      linkedIn: '',
      github: '',
      resume: null,
    });
  };

  const downloadTemplate = () => {
    const template = [
      {
        name: 'Example Name',
        email: 'example@email.com',
        phone: '1234567890',
        rollNumber: 'CSE2024001',
        branch: 'CSE',
        semester: '8',
        batchYear: '2024',
        cgpa: '8.5',
        skills: 'JavaScript, React, Node.js',
        linkedIn: 'https://linkedin.com/in/example',
        github: 'https://github.com/example'
      }
    ];

    const ws = XLSX.utils.json_to_sheet(template);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Template');
    XLSX.writeFile(wb, 'student_upload_template.xlsx');
  };

  if (loading) return <div className="flex items-center justify-center h-screen">Loading...</div>;
  if (error) return <div className="text-red-500">Error: {error}</div>;

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold">Student Management</h1>
          <div className="flex space-x-2">
            <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
              <DialogTrigger asChild>
                <Button>
                  <FaUserPlus className="mr-2" />
                  Add Student
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Add New Student</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-1">Name</label>
                      <Input
                        name="name"
                        value={formData.name}
                        onChange={handleInputChange}
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">Email</label>
                      <Input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">Phone</label>
                      <Input
                        name="phone"
                        value={formData.phone}
                        onChange={handleInputChange}
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">Roll Number</label>
                      <Input
                        name="rollNumber"
                        value={formData.rollNumber}
                        onChange={handleInputChange}
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">Branch</label>
                      <select
                        name="branch"
                        value={formData.branch}
                        onChange={handleInputChange}
                        className="w-full p-2 border rounded"
                        required
                      >
                        <option value="">Select Branch</option>
                        <option value="CSE">Computer Science</option>
                        <option value="ECE">Electronics</option>
                        <option value="ME">Mechanical</option>
                        <option value="CE">Civil</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">Semester</label>
                      <Input
                        type="number"
                        name="semester"
                        value={formData.semester}
                        onChange={handleInputChange}
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">Batch Year</label>
                      <Input
                        type="number"
                        name="batchYear"
                        value={formData.batchYear}
                        onChange={handleInputChange}
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">CGPA</label>
                      <Input
                        type="number"
                        step="0.01"
                        name="cgpa"
                        value={formData.cgpa}
                        onChange={handleInputChange}
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">Skills</label>
                      <Input
                        name="skills"
                        value={formData.skills}
                        onChange={handleInputChange}
                        placeholder="Comma separated skills"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">LinkedIn</label>
                      <Input
                        type="url"
                        name="linkedIn"
                        value={formData.linkedIn}
                        onChange={handleInputChange}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">GitHub</label>
                      <Input
                        type="url"
                        name="github"
                        value={formData.github}
                        onChange={handleInputChange}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">Resume</label>
                      <Input
                        type="file"
                        accept=".pdf,.doc,.docx"
                        onChange={handleFileChange}
                      />
                    </div>
                  </div>
                  <Button type="submit" className="w-full">
                    Add Student
                  </Button>
                </form>
              </DialogContent>
            </Dialog>

            <div className="flex items-center space-x-2">
              <Button variant="outline" onClick={downloadTemplate}>
                <FaDownload className="mr-2" />
                Download Template
              </Button>
              <Button variant="outline" onClick={() => setShowBulkUploadModal(true)}>
                <FaFileUpload className="mr-2" />
                Bulk Upload
              </Button>
            </div>
          </div>
        </div>

        <StudentFilters filters={filters} setFilters={setFilters} />

        <StudentTable
          students={students}
          onView={handleViewStudent}
          onEdit={handleViewStudent}
          onDelete={handleDelete}
        />

        {students.length === 0 && (
          <div className="text-center py-12 bg-white rounded-lg shadow">
            <FaUserPlus className="mx-auto text-4xl text-gray-400 mb-4" />
            <h2 className="text-xl font-semibold text-gray-700">No students found</h2>
            <p className="text-gray-500 mt-2">Try adjusting your filters or add a new student</p>
          </div>
        )}

        <BulkUploadModal
          isOpen={showBulkUploadModal}
          onClose={() => setShowBulkUploadModal(false)}
          onUpload={handleBulkUpload}
        />
      </div>
    </Layout>
  );
};

export default StudentManagement;
