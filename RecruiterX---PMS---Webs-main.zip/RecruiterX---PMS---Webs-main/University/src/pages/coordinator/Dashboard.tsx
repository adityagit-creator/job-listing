import Layout from '@/Layout/Layout';
import React from 'react';

const CoordinatorDashboard = () => {
  return (
    <Layout>
    <div>
      
    </div>
    </Layout>
  );
};

export default CoordinatorDashboard; 