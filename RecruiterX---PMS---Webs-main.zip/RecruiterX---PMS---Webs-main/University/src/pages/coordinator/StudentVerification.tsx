import React, { useState, useEffect } from 'react';
import { toast } from 'react-hot-toast';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { FaCheck, FaTimes, FaSearch, FaDownload } from 'react-icons/fa';
import { Student } from '@/types/placement';

const StudentVerification = () => {
  const [students, setStudents] = useState<Student[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [showDetailsDialog, setShowDetailsDialog] = useState(false);
  const [filter, setFilter] = useState('pending');
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    fetchStudents();
  }, [filter]);

  const fetchStudents = async () => {
    try {
      setLoading(true);
      // Fetch students based on verification status
      const querySnapshot = await getDocs(
        query(
          collection(db, 'students'),
          where('verificationStatus', '==', filter),
          orderBy('createdAt', 'desc')
        )
      );
      
      const studentsData = querySnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Student[];
      
      setStudents(studentsData);
    } catch (error) {
      console.error('Error fetching students:', error);
      toast.error('Failed to load students');
    } finally {
      setLoading(false);
    }
  };

  const handleVerify = async (studentId: string, status: 'approved' | 'rejected', comments?: string) => {
    try {
      await updateDoc(doc(db, 'students', studentId), {
        verificationStatus: status,
        verifiedAt: Timestamp.now(),
        verificationComments: comments || '',
      });

      // Send notification to student
      await createNotification(studentId, {
        type: 'verification',
        title: `Registration ${status}`,
        message: status === 'approved' 
          ? 'Your registration has been approved. You can now access the portal.'
          : `Your registration has been rejected. Reason: ${comments}`,
      });

      toast.success(`Student ${status} successfully`);
      setShowDetailsDialog(false);
      fetchStudents();
    } catch (error) {
      console.error('Error updating student status:', error);
      toast.error('Failed to update student status');
    }
  };

  const filteredStudents = students.filter(student => 
    student.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    student.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
    student.rollNumber.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="container mx-auto py-6 space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Student Verification</CardTitle>
          <CardDescription>
            Verify and manage student registrations
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex justify-between items-center mb-6">
            <Tabs defaultValue="pending" onValueChange={setFilter}>
              <TabsList>
                <TabsTrigger value="pending">Pending</TabsTrigger>
                <TabsTrigger value="approved">Approved</TabsTrigger>
                <TabsTrigger value="rejected">Rejected</TabsTrigger>
              </TabsList>
            </Tabs>

            <div className="relative">
              <FaSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <Input
                placeholder="Search students..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 w-64"
              />
            </div>
          </div>

          <div className="border rounded-lg">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Roll Number</TableHead>
                  <TableHead>Branch</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredStudents.map((student) => (
                  <TableRow key={student.id}>
                    <TableCell>{student.name}</TableCell>
                    <TableCell>{student.rollNumber}</TableCell>
                    <TableCell>{student.branch}</TableCell>
                    <TableCell>{student.email}</TableCell>
                    <TableCell>
                      <Badge
                        variant={
                          student.verificationStatus === 'approved'
                            ? 'success'
                            : student.verificationStatus === 'rejected'
                            ? 'destructive'
                            : 'default'
                        }
                      >
                        {student.verificationStatus}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Button
                        variant="ghost"
                        onClick={() => {
                          setSelectedStudent(student);
                          setShowDetailsDialog(true);
                        }}
                      >
                        View Details
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Student Details Dialog */}
      <Dialog open={showDetailsDialog} onOpenChange={setShowDetailsDialog}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Student Details</DialogTitle>
            <DialogDescription>
              Review student information and documents
            </DialogDescription>
          </DialogHeader>

          {selectedStudent && (
            <div className="space-y-6">
              {/* Personal Information */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Full Name</Label>
                  <p className="text-sm">{selectedStudent.name}</p>
                </div>
                <div>
                  <Label>Email</Label>
                  <p className="text-sm">{selectedStudent.email}</p>
                </div>
                <div>
                  <Label>Phone</Label>
                  <p className="text-sm">{selectedStudent.phone}</p>
                </div>
                <div>
                  <Label>Roll Number</Label>
                  <p className="text-sm">{selectedStudent.rollNumber}</p>
                </div>
                <div>
                  <Label>Branch</Label>
                  <p className="text-sm">{selectedStudent.branch}</p>
                </div>
                <div>
                  <Label>Semester</Label>
                  <p className="text-sm">{selectedStudent.semester}</p>
                </div>
              </div>

              {/* Documents */}
              <div className="space-y-2">
                <Label>Documents</Label>
                <div className="grid grid-cols-2 gap-4">
                  {selectedStudent.documents?.resume && (
                    <Button
                      variant="outline"
                      onClick={() => window.open(selectedStudent.documents.resume, '_blank')}
                    >
                      <FaDownload className="mr-2" />
                      View Resume
                    </Button>
                  )}
                  {selectedStudent.documents?.transcript && (
                    <Button
                      variant="outline"
                      onClick={() => window.open(selectedStudent.documents.transcript, '_blank')}
                    >
                      <FaDownload className="mr-2" />
                      View Transcript
                    </Button>
                  )}
                </div>
              </div>

              {/* Verification Actions */}
              {selectedStudent.verificationStatus === 'pending' && (
                <div className="flex justify-end space-x-4 mt-6">
                  <Button
                    variant="destructive"
                    onClick={() => {
                      const comments = prompt('Enter rejection reason:');
                      if (comments) {
                        handleVerify(selectedStudent.id, 'rejected', comments);
                      }
                    }}
                  >
                    <FaTimes className="mr-2" />
                    Reject
                  </Button>
                  <Button
                    variant="default"
                    onClick={() => handleVerify(selectedStudent.id, 'approved')}
                  >
                    <FaCheck className="mr-2" />
                    Approve
                  </Button>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default StudentVerification; 