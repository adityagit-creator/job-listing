import Layout from '@/Layout/Layout';
import React from 'react';

const AssessmentScheduling = () => {
  return (
    <Layout className="p-6">
      <h1 className="text-2xl font-bold mb-6">Assessment & Interview Scheduling</h1>

      {/* Schedule New Assessment/Interview */}
      <div className="bg-white rounded-lg shadow p-6 mb-6">
        <h2 className="text-xl font-semibold mb-4">Schedule New Event</h2>
        <form className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block mb-1">Event Type</label>
              <select className="w-full p-2 border rounded">
                <option value="assessment">Online Assessment</option>
                <option value="technical">Technical Interview</option>
                <option value="hr">HR Interview</option>
              </select>
            </div>
            <div>
              <label className="block mb-1">Company</label>
              <select className="w-full p-2 border rounded">
                <option value="">Select Company</option>
              </select>
            </div>
            <div>
              <label className="block mb-1">Date</label>
              <input type="date" className="w-full p-2 border rounded" />
            </div>
            <div>
              <label className="block mb-1">Time</label>
              <input type="time" className="w-full p-2 border rounded" />
            </div>
          </div>
          <div>
            <label className="block mb-1">Description</label>
            <textarea className="w-full p-2 border rounded" rows={3}></textarea>
          </div>
          <button className="bg-blue-600 text-white px-4 py-2 rounded">
            Schedule Event
          </button>
        </form>
      </div>

      {/* Upcoming Events */}
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-xl font-semibold mb-4">Upcoming Events</h2>
        <div className="space-y-4">
          {/* Event cards would be mapped here */}
          <div className="border rounded p-4">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="font-semibold">Technical Interview - Company XYZ</h3>
                <p className="text-gray-600">Date: 15th March 2024</p>
                <p className="text-gray-600">Time: 10:00 AM</p>
              </div>
              <div className="space-x-2">
                <button className="text-blue-600">Edit</button>
                <button className="text-red-600">Cancel</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default AssessmentScheduling; 