import { Timestamp } from 'firebase/firestore';

export interface Student {
  id: string;
  name: string;
  email: string;
  phone: string;
  rollNumber: string;
  branch: string;
  semester: number;
  batchYear: string;
  cgpa: number;
  skills: string[];
  linkedIn?: string;
  github?: string;
  resume?: {
    url: string;
    uploadedAt: Date;
  };
  placementStatus: 'placed' | 'unplaced' | 'debarred';
  placementDetails?: {
    companyId: string;
    companyName: string;
    role: string;
    package: number;
    offerDate: Date;
    joiningDate?: Date;
  };
  assessments: {
    id: string;
    title: string;
    score: number;
    maxScore: number;
    date: Date;
    status: 'completed' | 'pending' | 'missed';
  }[];
  interviews: {
    id: string;
    companyId: string;
    companyName: string;
    round: string;
    date: Date;
    status: 'scheduled' | 'completed' | 'cancelled';
    feedback?: string;
    result?: 'selected' | 'rejected' | 'on-hold';
  }[];
  documents: {
    type: 'resume' | 'transcript' | 'id_proof' | 'other';
    url: string;
    uploadedAt: Date;
    verified: boolean;
    verifiedBy?: string;
    verifiedAt?: Date;
  }[];
  academicDetails: {
    tenthPercentage: number;
    tenthBoard: string;
    tenthYear: number;
    twelfthPercentage: number;
    twelfthBoard: string;
    twelfthYear: number;
    backlogs: number;
    activeBacklogs: number;
  };
  personalDetails: {
    dateOfBirth: Date;
    gender: 'male' | 'female' | 'other';
    category: string;
    address: string;
    city: string;
    state: string;
    pincode: string;
    nationality: string;
  };
  createdAt: Date;
  updatedAt: Date;
}

export interface Company {
  id: string;
  companyName: string;
  industry: string;
  description: string;
  website: string;
  contactName: string;
  contactEmail: string;
  contactPhone: string;
  status: 'active' | 'inactive';
  createdAt: Date;
  updatedAt: Date;
}

export interface JobPosting {
  id: string;
  companyId: string;
  jobTitle: string;
  description: string;
  responsibilities: string[];
  requirements: {
    essential: string[];
    preferred: string[];
  };
  eligibility: {
    minimumCGPA: number;
    allowedBranches: string[];
    allowedBatchYears: string[];
    maxBacklogs: number;
    otherCriteria?: string[];
  };
  package: {
    ctc: number;
    breakup: {
      basic: number;
      hra: number;
      bonus?: number;
      stockOptions?: number;
      otherBenefits?: string[];
    };
  };
  location: string[];
  type: 'full-time' | 'part-time' | 'internship';
  mode: 'remote' | 'onsite' | 'hybrid';
  status: 'draft' | 'open' | 'closed' | 'cancelled';
  rounds: {
    type: 'online_test' | 'technical' | 'hr' | 'group_discussion';
    description: string;
    duration?: number;
  }[];
  deadline: Date;
  positions: number;
  applicationStats: {
    views: number;
    applications: number;
    shortlisted: number;
    selected: number;
  };
  documents: {
    required: ('resume' | 'transcript' | 'cover_letter' | 'certificates')[];
    optional: string[];
  };
  createdAt: Date;
  updatedAt: Date;
  publishedAt?: Date;
}

export interface JobApplication {
  id: string;
  jobId: string;
  studentId: string;
  status: 'pending' | 'shortlisted' | 'rejected' | 'accepted';
  appliedAt: Date;
  updatedAt: Date;
}

export interface Document {
  id: string;
  studentId: string;
  type: 'resume' | 'transcript' | 'id_proof' | 'offer_letter';
  url: string;
  status: 'pending' | 'verified' | 'rejected';
  verifiedBy?: string;
  verifiedAt?: Timestamp;
  comments?: string;
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export interface Assessment {
  id: string;
  jobId: string;
  companyId: string;
  title: string;
  description: string;
  type: 'technical' | 'aptitude' | 'coding';
  platform: 'hackerrank' | 'codility' | 'mettl';
  duration: number; // in minutes
  participants: string[]; // student IDs
  scheduledDate: Date;
  status: 'scheduled' | 'ongoing' | 'completed';
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export interface Interview {
  id: string;
  jobId: string;
  companyId: string;
  type: 'technical' | 'hr' | 'final';
  round: number;
  mode: 'online' | 'offline';
  location?: string;
  meetLink?: string;
  participants: string[]; // student IDs
  scheduledDate: Date;
  duration: number; // in minutes
  status: 'scheduled' | 'completed' | 'cancelled';
  feedback?: string;
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export interface AssessmentStatus {
  assessmentId: string;
  status: 'scheduled' | 'completed' | 'absent';
  score?: number;
  feedback?: string;
}

export interface InterviewStatus {
  interviewId: string;
  status: 'scheduled' | 'completed' | 'absent';
  feedback?: string;
  result?: 'selected' | 'rejected' | 'onhold';
}

export interface BulkMessage {
  id: string;
  type: 'announcement' | 'reminder' | 'notification';
  subject?: string;
  content: string;
  recipients: string[]; // student IDs
  status: 'draft' | 'sent' | 'failed';
  sentAt?: Timestamp;
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export interface PlacementStats {
  batchYear: number;
  totalStudents: number;
  placedStudents: number;
  placementRate: number;
  branchWiseStats: {
    [key: string]: {
      total: number;
      placed: number;
      averagePackage: number;
    };
  };
}

export interface CompanyStats {
  totalApplications: number;
  shortlisted: number;
  pending: number;
  conversionRate: number;
  activeJobs: number;
  totalJobs: number;
}

export interface JobStats {
  totalJobs: number;
  activeJobs: number;
  totalApplications: number;
  shortlistedCandidates: number;
  selectedCandidates: number;
  averageApplicationsPerJob: number;
  conversionRate: number;
  branchWiseStats: {
    [branch: string]: {
      applications: number;
      shortlisted: number;
      selected: number;
    };
  };
  timelineStats: {
    [month: string]: {
      jobsPosted: number;
      applications: number;
      selections: number;
    };
  };
  packageStats: {
    minimum: number;
    maximum: number;
    average: number;
    distribution: {
      [range: string]: number;
    };
  };
} 