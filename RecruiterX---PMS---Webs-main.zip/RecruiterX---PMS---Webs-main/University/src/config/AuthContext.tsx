/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { createContext, ReactNode, useContext, useEffect, useMemo, useState } from "react";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, onAuthStateChanged } from "firebase/auth";
import { auth, db } from './FirebaseConfig';  // Adjust import according to your project structure
import toast from "react-hot-toast";
import { doc, getDoc, setDoc, updateDoc } from "firebase/firestore";

interface User {
  uid: string;
  email: string;
  [key: string]: any; // to accommodate additional properties
}
interface AuthProviderProps {
  children: ReactNode; // Accepts children as a ReactNode
}
interface AuthContextType {
  currentUser: User | null;
  signUp: (email: string, password: string) => Promise<void>;
  logIn: (email: string, password: string) => Promise<void>;
  logOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);
export function useAuth(): AuthContextType {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [loading, setLoading] = useState<boolean>(true);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isFetchingUserData, setIsFetchingUserData] = useState<boolean>(true);

  useEffect(() => {
    const auth = getAuth();

    const fetchUserData = async (uid: string) => {
      const userDoc = await getDoc(doc(db, 'admins', uid));  // Get user data from 'admins' collection
      if (userDoc.exists()) {
        return userDoc.data();
      } else {
        throw new Error('User data not found in Firestore');
      }
    };

    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        try {
          setIsFetchingUserData(true);
          const userData = await fetchUserData(user.uid);
          setCurrentUser({
            uid: user.uid,
            email: user.email!,
            ...userData
          });
        } catch (error) {
          console.error('Error fetching user data:', error);
          setCurrentUser(null);
        }
      } else {
        setCurrentUser(null);
      }
      setLoading(false);
      setIsFetchingUserData(false);
    });

    return unsubscribe;
  }, []);

  async function signUp(email: string, password: string) {
    try {
      // Step 1: Create user with Firebase authentication
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;
  
      if (user) {
        console.log('User created:', user.uid);
  
        // Step 2: Create a document in Firestore
        const userRef = doc(db, 'admins', user.uid);
        await setDoc(userRef, {
          email: email,
          role:"admin",
          password:password,
          token: await user.getIdToken(), // Firebase auth token
          lastLogin: new Date(),
        });
  
        console.log('User data stored in Firestore:', { email, uid: user.uid });
  
        // Step 3: Set the current user state
        setCurrentUser({
          uid: user.uid,
          email: user.email!,
        });
  
        // Success message
        toast.success('Sign Up successful!');
      }
    } catch (error: any) {
      console.error('Error during sign up:', error);
      toast.error(error.message || 'An error occurred while signing up');
    }
  }
  
 
  async function logIn(email: string, password: string) {
    try {
      // Sign in with email and password
      await signInWithEmailAndPassword(auth, email, password);
      const user = auth.currentUser;
  
      if (!user) {
        throw new Error('User not found after authentication.');
      }
  
      // Reference to the user's document in the "admins" collection
      const userRef = doc(db, 'admins', user.uid);
      const userDoc = await getDoc(userRef);
  
      // Check if user exists in the "admins" collection and has role "admin"
      if (userDoc.exists()) {
        const userData = userDoc.data();
        if (userData.role === 'admin') {
          // Update user data with lastLogin and token refresh
          await updateDoc(userRef, {
            lastLogin: new Date(),
            token: await user.getIdToken(true), // Refresh token
          });
  
          // Set the current user in your application context/state (if applicable)
          setCurrentUser({
            uid: user.uid,
            email: user.email!,
            ...userData,
          });
  
          toast.success('Login successful!');
        } else {
          throw new Error('User is not an admin.');
        }
      } else {
        throw new Error('User not found in admins collection.');
      }
    } catch (error: any) {
      toast.error(error.message || 'An error occurred during login.');
    }
  }
  

  async function logOut() {
       await signOut(auth);
    setCurrentUser(null);  // Clear the current user

    toast.success('Logged out successfully.');
  }

  const memoValue = useMemo(
    () => ({
      currentUser,
      signUp,
      logIn,
      logOut,
    }),
    [currentUser]
  );

  return (
    <AuthContext.Provider value={memoValue}>
      {!loading && !isFetchingUserData ? children : <div className="flex justify-center items-center min-h-screen">
  <div className="text-center">
    <div className="flex justify-center items-center space-x-2">
      <div className="w-8 h-8 border-4 border-t-4 border-gray-300 border-solid rounded-full animate-spin"></div>
      <span className="text-lg font-semibold">Loading...</span>
    </div>
  </div>
</div>
}
    </AuthContext.Provider>
  );
};