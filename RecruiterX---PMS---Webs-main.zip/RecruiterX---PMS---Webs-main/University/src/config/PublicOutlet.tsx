import React from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from './AuthContext';

const PublicOutlet: React.FC = () => {
  const { currentUser } = useAuth();

  // If the user is logged in, redirect them to the home page
  if (currentUser) {
    return <Navigate to="/home" />;
  }

  // Otherwise, render the child components
  return <Outlet />;
};

export default PublicOutlet;
