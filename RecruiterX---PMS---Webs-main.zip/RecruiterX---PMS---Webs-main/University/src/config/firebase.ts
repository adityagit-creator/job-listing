import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

const firebaseConfig = {
  apiKey: "AIzaSyA770pUbA8LSr34TY5Z4-5fAaHW2ZP0YOU",
  authDomain: "schoolx-d502d.firebaseapp.com",
  projectId: "schoolx-d502d",
  storageBucket: "schoolx-d502d.firebasestorage.app",
  messagingSenderId: "728175208264",
  appId: "1:728175208264:web:f13d6a10626943a6c0b57d",
  measurementId: "G-GEERB53MXV"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);

export default app; 