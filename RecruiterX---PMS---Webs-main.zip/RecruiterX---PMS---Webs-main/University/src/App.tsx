import { Route, Routes } from "react-router-dom";

import Home from "./pages/Home";
import UserDetails from "./components/Users/ViewUsers";
import PushNotification from "./components/Notification/PushNotification";
import Signup from "./pages/SignUpUser";
import Auth from "./pages/LoginUser";
import PrivateOutlet from "./config/PrivateOutlet";
import PublicOutlet from "./config/PublicOutlet";
import SettingsPage from "./pages/Settings";
import Teachers from "./pages/Teachers";
import ManageGrades from "./pages/ManageGrades";
import Attendance from "./pages/Attendance";
import Assignments from "./pages/Assignments";
import Homework from "./pages/Homework";
import Students from "./pages/Students";

// Training & Placement Coordinator Pages
import CoordinatorDashboard from "./pages/coordinator/Dashboard";
import JobManagement from "./pages/coordinator/JobManagement";
import StudentManagement from "./pages/coordinator/StudentManagement";
import AssessmentScheduling from "./pages/coordinator/AssessmentScheduling";
import ViewStudent from "./pages/coordinator/ViewStudent";
import NotificationCenter from "./pages/coordinator/NotificationCenter";

// Training & Placement Officer Pages
import AdminDashboard from "./pages/officer/AdminDashboard";
import RecruiterManagement from "./pages/officer/RecruiterManagement";
import ReportsInsights from "./pages/officer/ReportsInsights";
import AddJobPosting from "./components/Jobs/AddJobPosting";

const publicRoutes = [
  { path: "/", element: <Auth /> },
];

const privateRoutes = [
  { path: "/ManageGrades", element: <ManageGrades /> },
  { path: "/Attendance", element: <Attendance /> },
  { path: "/Assignments", element: <Assignments /> },
  { path: "/Homework", element: <Homework /> },
  { path: "/signup", element: <Signup /> },
  { path: "/Home", element: <Home /> },
  { path: "/teachers", element: <Teachers /> },
  { path: "/Settings", element: <SettingsPage /> },
  { path: "/Students", element: <Students /> },
  { path: "/viewStudent/:userId", element: <UserDetails /> },
  { path: "/Notification", element: <PushNotification /> },
];

const coordinatorRoutes = [
  { path: "dashboard", element: <CoordinatorDashboard /> },
  { path: "job-management", element: <JobManagement /> },
  { path: "student-management", element: <StudentManagement /> },
  { path: "Add-jobs", element: <AddJobPosting /> },
  { path: "student/:id", element: <ViewStudent /> },
  { path: "assessment-scheduling", element: <AssessmentScheduling /> },
  { path: "notification-center", element: <NotificationCenter /> }
];

const officerRoutes = [
  { path: "dashboard", element: <AdminDashboard /> },
  { path: "recruiter-management", element: <RecruiterManagement /> },
  { path: "reports-insights", element: <ReportsInsights /> },
];

function App() {
  return (
    <Routes>
      <Route path="/" element={<PublicOutlet />}>
        {publicRoutes.map((route, index) => (
          <Route key={index} path={route.path} element={route.element} />
        ))}
      </Route>
      <Route element={<PrivateOutlet />}>
        {privateRoutes.map((route, index) => (
          <Route key={index} path={route.path} element={route.element} />
        ))}
        
        {/* Training & Placement Coordinator Routes */}
        <Route path="/coordinator">
          {coordinatorRoutes.map((route, index) => (
            <Route key={index} path={route.path} element={route.element} />
          ))}
        </Route>

        {/* Training & Placement Officer Routes */}
        <Route path="/officer">
          {officerRoutes.map((route, index) => (
            <Route key={index} path={route.path} element={route.element} />
          ))}
        </Route>
      </Route>
    </Routes>
  );
}

export default App;