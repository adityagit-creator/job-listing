import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}


export const formatDateNew = (timestamp: string | null | undefined): string => {
  if (!timestamp) {
    return "N/A"; // Return fallback value if timestamp is null or undefined
  }

  const date = new Date(timestamp); // Create a new Date object from the timestamp string
  const options: Intl.DateTimeFormatOptions = { year: "numeric", month: "long", day: "numeric" }; // Date formatting options
  return date.toLocaleDateString("en-US", options); // Return the formatted date string
};

export function formatDate(date: Date | string): string {
  if (!date) {
    return "N/A";
  }

  const parsedDate = new Date(date);

  if (isNaN(parsedDate.getTime())) {
    return "Invalid Date";
  }

  const day = parsedDate.getDate();
  const monthIndex = parsedDate.getMonth();
  const year = parsedDate.getFullYear();

  const months = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];

  return `${day} ${months[monthIndex]} ${year}`;
}
