import * as z from "zod";

export const loginSchema = z.object({
  email: z.string().email("Invalid email address"),
  password: z.string().min(8, "Password must be at least 8 characters"),
});

export const jobPostingSchema = z.object({
  companyId: z.string().min(1, "Please select a company"),
  title: z.string().min(1, "Job title is required"),
  description: z.string().min(50, "Description must be at least 50 characters"),
  eligibilityCriteria: z.object({
    minimumCGPA: z.number().min(0).max(10, "CGPA must be between 0 and 10"),
    allowedBranches: z.array(z.string()).min(1, "Select at least one branch"),
    otherRequirements: z.string(),
  }),
  package: z.object({
    ctc: z.number().min(0, "CTC must be a positive number"),
    breakup: z.string(),
  }),
  deadline: z.date().min(new Date(), "Deadline must be in the future"),
});

export const studentProfileSchema = z.object({
  name: z.string().min(1, "Name is required"),
  rollNumber: z.string().min(1, "Roll number is required"),
  email: z.string().email("Invalid email address"),
  branch: z.string().min(1, "Branch is required"),
  cgpa: z.number().min(0).max(10, "CGPA must be between 0 and 10"),
  skills: z.array(z.string()).min(1, "Add at least one skill"),
  linkedIn: z.string().url("Invalid LinkedIn URL").optional(),
  github: z.string().url("Invalid GitHub URL").optional(),
});

export const assessmentSchema = z.object({
  jobId: z.string().min(1, "Please select a job posting"),
  type: z.enum(["online", "written", "technical"]),
  scheduledDate: z.date().min(new Date(), "Date must be in the future"),
  duration: z.number().min(15, "Duration must be at least 15 minutes"),
  venue: z.string().min(1, "Venue is required"),
  instructions: z.string().min(1, "Instructions are required"),
  platform: z.string().optional(),
  proctoring: z.boolean().default(false),
});

export const interviewSchema = z.object({
  jobId: z.string().min(1, "Please select a job posting"),
  type: z.enum(["technical", "hr", "final"]),
  scheduledDate: z.date().min(new Date(), "Date must be in the future"),
  duration: z.number().min(15, "Duration must be at least 15 minutes"),
  venue: z.string().min(1, "Venue is required"),
  panelMembers: z.array(z.string()).min(1, "Add at least one panel member"),
  mode: z.enum(["online", "offline"]),
  meetingLink: z.string().url().optional(),
});

export const bulkMessageSchema = z.object({
  type: z.enum(["email", "sms", "whatsapp"]),
  subject: z.string().optional(),
  content: z.string().min(1, "Message content is required"),
  recipients: z.array(z.string()).min(1, "Select at least one recipient"),
  scheduledFor: z.date().optional(),
});

export const documentVerificationSchema = z.object({
  studentId: z.string().min(1, "Please select a student"),
  documentType: z.enum(["resume", "transcript", "certificate", "other"]),
  status: z.enum(["pending", "verified", "rejected"]),
  comments: z.string().optional(),
});

export const companyRegistrationSchema = z.object({
  name: z.string().min(1, "Company name is required"),
  industry: z.string().min(1, "Industry is required"),
  description: z.string().min(50, "Description must be at least 50 characters"),
  website: z.string().url("Invalid website URL"),
  hrContactName: z.string().min(1, "HR contact name is required"),
  hrEmail: z.string().email("Invalid HR email address"),
  hrPhone: z.string().regex(/^\+?[1-9]\d{9,14}$/, "Invalid phone number"),
  registrationNumber: z.string().min(1, "Registration number is required"),
  documents: z.array(z.object({
    type: z.enum(["registration", "tax", "other"]),
    url: z.string().url(),
  })),
}); 