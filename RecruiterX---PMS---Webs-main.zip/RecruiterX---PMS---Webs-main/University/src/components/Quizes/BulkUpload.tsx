import React, { useState } from "react";
import * as XLSX from "xlsx";
import { db } from "../../config/FirebaseConfig"; // Adjust path as needed
import { collection, writeBatch, doc } from "firebase/firestore";
import toast from "react-hot-toast";
import { useParams } from "react-router-dom";
import { UploadCloud } from "lucide-react";

// Interface to represent the data coming from the Excel sheet
interface QuizData {
  Quiz_ID: string;
  Question: string;
  Option_1: string;
  Option_2: string;
  Option_3: string;
  Option_4: string;
  correctAnswer: string;
  explanation: string;
}

const QuizUploader: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const { examId, yearId, subjectId } = useParams<{
    examId: string;
    yearId: string;
    subjectId: string;
  }>();

  const generateQuizId = () => {
    const timestamp = Date.now();
    const randomNum = Math.floor(100 + Math.random() * 900); // Generates a 3-digit random number
    return `Quiz_${timestamp}${randomNum}`;
  };

  const handleFileUpload = async (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    if (!examId || !yearId || !subjectId) {
      toast.error("Invalid exam, year, or subject ID. Please check the URL.");
      return;
    }

    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (e) => {
      const data = e.target?.result;
      if (!data) return;

      try {
        setLoading(true);
        const workbook = XLSX.read(data, { type: "binary" });
        const worksheet = workbook.Sheets[workbook.SheetNames[0]];
        const quizData: QuizData[] = XLSX.utils.sheet_to_json(worksheet, {
          defval: "", // Set default empty string for missing values
        });
        const quizCollectionRef = collection(
          db,
          "exams",
          examId,
          "years",
          yearId,
          "subjects",
          subjectId,
          "quizzes"
        );

        // Default Question_image array with null values
        const defaultQuestionImage = [""];

        const defaultExplanationImage = [""];
        const batch = writeBatch(db); // Create a Firestore batch
        quizData.forEach((quiz) => {
          const quizId = generateQuizId();
          const quizDocRef = doc(quizCollectionRef, quizId);

          const options = [
            { Option_ID: "A", Option_Text: quiz.Option_1 || "" },
            { Option_ID: "B", Option_Text: quiz.Option_2 || "" },
            { Option_ID: "C", Option_Text: quiz.Option_3 || "" },
            { Option_ID: "D", Option_Text: quiz.Option_4 || "" },
          ];

          const quizDoc = {
            quizz_id: quizId,
            Question: quiz.Question || "", // Default if undefined
            options: options,
            correctAnswer: quiz.correctAnswer || "", // Default if undefined
            explanation: quiz.explanation || "", // Default if undefined
            Question_image: defaultQuestionImage, // Already handled
            Explanation_image: defaultExplanationImage, // Already handled
          };

          batch.set(quizDocRef, quizDoc);
        });

        await batch.commit();
        toast.success("Quiz data uploaded successfully!");

     
      } catch (error) {
        console.error("Error uploading quiz data:", error);
        toast.error("Failed to upload quiz data.");
      } finally {
        setLoading(false);
      }
    };

    reader.readAsBinaryString(file);
  };

  return (
    <div className="bg-white md rounded-lg p-6 space-y-4 border-dashed border-2 border-gray-300 w-full">
      <div className="flex flex-col items-center justify-center">
        <UploadCloud className="w-16 h-16 text-accent_color mb-2" />
        <h2 className="text-lg font-semibold text-gray-700">
          Upload Quiz Excel File
        </h2>

        {loading ? (
          <p className="text-center text-sm text-gray-500 mt-2">Uploading...</p>
        ) : (
          <p className="text-center text-sm text-gray-500 mt-2">
            Drag & drop your file here Upload Quiz
          </p>
        )}
      </div>
      <input
        type="file"
        accept=".xlsx, .xls"
        onChange={handleFileUpload}
        disabled={loading}
        className=" cursor-pointer"
      />
    </div>
  );
};

export default QuizUploader;
