import React, { useState } from "react";
import { db, storage } from "../../config/FirebaseConfig"; // Ensure storage is initialized in FirebaseConfig
import { collection, doc, setDoc } from "firebase/firestore";
import { Button } from "../ui/button";
import toast from "react-hot-toast";
import { useParams } from "react-router-dom";
import { ref, uploadBytesResumable, getDownloadURL } from "firebase/storage"; // Import storage methods

// Interface for the quiz data
interface QuizFormData {
  Quiz_ID: string;
  Question: string;
  Option_1: string;
  Option_2: string;
  Option_3: string;
  Option_4: string;
  correctAnswer: string;
  explanation: string;
  Question_image: (string)[]; // Array to handle multiple images or null values
}

const ManualQuizzAdd: React.FC = () => {
  const { examId, yearId,subjectId } = useParams<{ examId: string; yearId: string,subjectId:string }>();
  const [formData, setFormData] = useState<QuizFormData>({
    Quiz_ID: "",
    Question: "",
    Option_1: "",
    Option_2: "",
    Option_3: "",
    Option_4: "",
    correctAnswer: "",
    explanation: "",
    Question_image: [""], // Default to a single null value
  });

  const [loading, setLoading] = useState(false);
  const [imageUploadProgress, setImageUploadProgress] = useState(0); // To track upload progress

  const generateQuizId = () => {
    const timestamp = Date.now();
    const randomNum = Math.floor(100 + Math.random() * 900); // Generates a 3-digit random number
    return `Quiz_${timestamp}${randomNum}`;
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      const imageFiles = Array.from(files);
      const uploadPromises = imageFiles.map((file) => {
        const storageRef = ref(storage, `quiz_images/${file.name}`);
        const uploadTask = uploadBytesResumable(storageRef, file);
  
        return new Promise<string>((resolve, reject) => {
          uploadTask.on(
            "state_changed",
            (snapshot) => {
                const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
                setImageUploadProgress(progress);
            },
            (error) => {
              reject(error); // Reject the promise if there's an error
            },
            () => {
              getDownloadURL(uploadTask.snapshot.ref)
                .then((downloadURL) => {
                  resolve(downloadURL); // Resolve the promise with the download URL
                })
                .catch((error) => {
                  reject(error); // Reject if URL retrieval fails
                });
            }
          );
        });
      });
  
      // Wait for all images to upload and get the URLs
      Promise.all(uploadPromises)
        .then((urls) => {
          // Store the URLs in the state
          setFormData((prev) => ({
            ...prev,
            Question_image: urls, // Update with actual URLs
          }));
        })
        .catch((error) => {
          toast.error("Failed to upload images.");
          console.error(error);
        });
    }
  };
  

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      setLoading(true);

      if (!examId || !yearId ||!subjectId) {
        toast.error("Exam ID or Year ID is missing.");
        return;
      }

      const quizId = generateQuizId();
      const quizCollectionRef = collection(
        db,
        "exams",
        examId,
        "years",
        yearId,
        "subjects",
        subjectId,
        "quizzes"
      );
      const quizDocRef = doc(quizCollectionRef, quizId); // Use generated quizId as document ID

      const options = [
        { Option_ID: "A", Option_Text: formData.Option_1 },
        { Option_ID: "B", Option_Text: formData.Option_2 },
        { Option_ID: "C", Option_Text: formData.Option_3 },
        { Option_ID: "D", Option_Text: formData.Option_4 },
      ];

      const quizDoc = {
        quizz_id: quizId,
        Question: formData.Question,
        options: options,
        correctAnswer: formData.correctAnswer,
        explanation: formData.explanation,
        Question_image: formData.Question_image,
      };

      await setDoc(quizDocRef, quizDoc);

      toast.success("Quiz added successfully!");
      setFormData({
        Quiz_ID: "",
        Question: "",
        Option_1: "",
        Option_2: "",
        Option_3: "",
        Option_4: "",
        correctAnswer: "",
        explanation: "",
        Question_image: [""], // Reset to default
      });
    } catch (error) {
      console.error("Error adding quiz:", error);
      toast.error("Failed to add quiz.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full">
      <form onSubmit={handleSubmit} className="space-y-4 w-full">
        <textarea
          name="Question"
          placeholder="Question"
          value={formData.Question}
          onChange={handleChange}
          required
          className="w-full p-2 border rounded"
        />
        <div className="grid grid-cols-2 gap-3">
          <input
            type="text"
            name="Option_1"
            placeholder="Option 1"
            value={formData.Option_1}
            onChange={handleChange}
            required
            className="w-full p-2 border rounded"
          />
          <input
            type="text"
            name="Option_2"
            placeholder="Option 2"
            value={formData.Option_2}
            onChange={handleChange}
            required
            className="w-full p-2 border rounded"
          />
          <input
            type="text"
            name="Option_3"
            placeholder="Option 3"
            value={formData.Option_3}
            onChange={handleChange}
            required
            className="w-full p-2 border rounded"
          />
          <input
            type="text"
            name="Option_4"
            placeholder="Option 4"
            value={formData.Option_4}
            onChange={handleChange}
            required
            className="w-full p-2 border rounded"
          />
        </div>

        <input
          type="text"
          name="correctAnswer"
          placeholder="Correct Answer (e.g., A, B, C, D)"
          value={formData.correctAnswer}
          onChange={handleChange}
          required
          className="w-full p-2 border rounded"
        />
        <textarea
          name="explanation"
          placeholder="Explanation"
          value={formData.explanation}
          onChange={handleChange}
          required
          className="w-full p-2 border rounded"
        />
        <div className="relative w-full">
          <label
            htmlFor="file-upload"
            className="block w-full p-2 text-center bg-white border border-gray-300 rounded cursor-pointer hover:border-gray-400 hover:shadow"
          >
            Upload Image
          </label>
          <input
            id="file-upload"
            type="file"
            accept="image/*"
            onChange={handleImageUpload}
            className="hidden"
          />
        </div>

        {imageUploadProgress > 0 && imageUploadProgress < 100 && (
          <div className="w-full text-center mt-2">
            <p>Uploading: {Math.round(imageUploadProgress)}%</p>
          </div>
        )}

        {loading ? (
          <p>Adding quiz...</p>
        ) : (
          <Button
            variant="outline"
            className="bg-accent_color py-3 w-full  text-white"
            type="submit"
          >
            Add Quiz
          </Button>
        )}
      </form>
    </div>
  );
};

export default ManualQuizzAdd;
