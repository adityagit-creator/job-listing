import React, { useState, ChangeEvent, FormEvent } from "react";
import { db, storage } from "../../config/FirebaseConfig";
import { collection, doc, setDoc, deleteDoc } from "firebase/firestore";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { Link } from "react-router-dom";
import toast from "react-hot-toast";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Input } from "../ui/input";
import { Button } from "../ui/button";
import { Trash2 } from "lucide-react";
import { useCollection } from "react-firebase-hooks/firestore"; // Importing useCollection hook

const ExamListPage: React.FC = () => {
  const [newExamName, setNewExamName] = useState<string>("");
  const [subtitle, setSubtitle] = useState<string>("");
  const [examImage, setExamImage] = useState<File | null>(null);

  // Firestore collection reference
  const examCollectionRef = collection(db, "exams");

  const [exams, loading, error] = useCollection(examCollectionRef);

  if (error) return <p>Error loading exams: {error.message}</p>;

  const handleNewExamChange = (e: ChangeEvent<HTMLInputElement>) => {
    setNewExamName(e.target.value);
  };
  const handleSubtitleChange = (e: ChangeEvent<HTMLInputElement>) => {
    setSubtitle(e.target.value); // Handle subtitle change
  };
  const handleImageChange = (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setExamImage(e.target.files[0]);
    }
  };

  const handleAddExam = async (e: FormEvent) => {
    e.preventDefault();
    if (newExamName.trim() === "") {
      toast.error("Exam name cannot be empty.");
      return;
    }

    if (!examImage) {
      toast.error("Please upload an image.");
      return;
    }

    try {
      const examDocRef = doc(db, "exams", newExamName);
      const imageRef = ref(storage, `exams/${newExamName}-${Date.now()}`);
      await uploadBytes(imageRef, examImage);
      const imageUrl = await getDownloadURL(imageRef);
      await setDoc(examDocRef, { examName: newExamName, subtitle, imageUrl });
      setNewExamName("");
      setSubtitle(""); // Reset subtitle
      setExamImage(null);
      toast.success("Exam added successfully!");
    } catch (error) {
      toast.error("Error adding exam.", );
    }
  };

  const handleDeleteExam = async (examId: string) => {
    const confirmDelete = window.confirm(
      "Are you sure you want to delete this exam?"
    );
    if (!confirmDelete) return;

    try {
      const examDocRef = doc(db, "exams", examId);
      await deleteDoc(examDocRef);
      toast.success("Exam deleted successfully!");
    } catch (error) {
      toast.error("Error deleting exam.");
    }
  };

  return (
    <div className="space-y-6">
      <Card className="none">
        <CardHeader>
          <CardTitle className="text-2xl font-semibold">Add New Exam</CardTitle>
        </CardHeader>
        <CardContent>
          <form
            onSubmit={handleAddExam}
            className="items-center flex sm:flex-row flex-col gap-4"
          >
            <Input
              type="text"
              value={newExamName}
              onChange={handleNewExamChange}
              placeholder="Enter exam name"
              required
              className="w-full"
            />
             <Input
              type="text"
              value={subtitle}
              onChange={handleSubtitleChange} // Handling subtitle change
              placeholder="Enter subtitle (optional)"
              className="w-full"
            />
            <Input
              type="file"
              onChange={handleImageChange}
              accept="image/*"
              required
              className="w-full"
            />
            <Button
              type="submit"
              variant="outline"
              className="w-full bg-accent_color text-white"
            >
              Add Exam
            </Button>
          </form>
        </CardContent>
      </Card>

      <Card className="none">
        <CardHeader>
          <CardTitle className="text-2xl font-semibold">
            Available Exams
          </CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <p className="text-center text-sm text-gray-500 mt-2">
              Loading....
            </p>
          ) : (
            <div>
              {exams && exams.docs.length > 0 ? (
                <ul className="grid sm:grid-cols-2 grid-cols-1">
                  {exams.docs.map((examDoc) => {
                    const exam = examDoc.data();
                    return (
                      <li
                        key={examDoc.id}
                        className="flex-row justify-between hover:bg-blue-100 cursor-pointer flex items-center space-x-4 border-2  border-blue-500 p-2 m-2 rounded-lg"
                      >
                        <div className="flex flex-row gap-3 items-center">
                          <img
                            src={exam.imageUrl}
                            alt={exam.examName}
                            className="w-16 h-16 object-cover rounded"
                          />
                          <Link
                            to={`/exam/${examDoc.id}`}
                            className="text-lg font-medium text-blue-600 hover:text-blue-800"
                          >
                            {exam.examName}
                          </Link>
                        </div>
                        <Button
                          onClick={() => handleDeleteExam(examDoc.id)}
                          variant="outline"
                          className="text-red-100 bg-red-700 p-2"
                        >
                          <Trash2 />
                        </Button>
                      </li>
                    );
                  })}
                </ul>
              ) : (
                <p className="text-gray-500">No exams available.</p>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default ExamListPage;
