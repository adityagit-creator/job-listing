import React, { useEffect, useState } from "react";
import { db, storage } from "../../config/FirebaseConfig";
import {
  collection,
  doc,
  getDocs,
  updateDoc,
  deleteDoc,
} from "firebase/firestore";
import { Button } from "../ui/button";
import toast from "react-hot-toast";
import Layout from "@/Layout/Layout";
import { GoBackButton } from "../Users/utlis";
import { Card } from "../ui/card";
import { useParams } from "react-router-dom";
import { getDownloadURL, ref, uploadBytesResumable } from "firebase/storage";
import { Edit3, Trash2, UploadCloud } from "lucide-react";
import QuizUploader from "./BulkUpload";
import ManualQuizzAdd from "./ManualQuizzAdd";
import Modal from "../Helpers/Modal";
import BulkDownloadExcel from "@/helpers/BulkDownload";
import DeleteAllQuizzes from "@/helpers/DeleteAllQuizz";
import { toPng } from "html-to-image";

interface QuizFormData {
  quizz_id: string;
  Question: string;
  options: {
    Option_ID: string;
    Option_Text: string;
  }[];
  correctAnswer: string;
  explanation: string;
  Explanation_image: string[];
  Question_image: string[];
}

const ManualQuizUploader: React.FC = () => {
  const { examId, yearId, subjectId } = useParams<{
    examId: string;
    yearId: string;
    subjectId: string;
  }>();

  const [quizzes, setQuizzes] = useState<QuizFormData[]>([]);
  const [filteredQuizzes, setFilteredQuizzes] = useState<QuizFormData[]>([]);
  const [searchQuery, setSearchQuery] = useState<string>("");
  // const [loading, setLoading] = useState(false);
  const [selectedQuizId, setSelectedQuizId] = useState<string | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const [editingQuiz, setEditingQuiz] = useState<QuizFormData | null>(null);
  const [newQuestion, setNewQuestion] = useState<string>("");
  const [newExplanation, setNewExplanation] = useState<string>("");
  const [newOptions, setNewOptions] = useState<
    { Option_ID: string; Option_Text: string }[]
  >([]);
  const [newCorrectAnswer, setNewCorrectAnswer] = useState<string>("");
  const fetchQuizzes = async () => {
    try {
      // setLoading(true);
      if (!examId || !yearId || !subjectId) {
        toast.error("Exam ID or Year ID is missing.");
        return;
      }

      const quizCollectionRef = collection(
        db,
        "exams",
        examId,
        "years",
        yearId,
        "subjects",
        subjectId,
        "quizzes"
      );

      const querySnapshot = await getDocs(quizCollectionRef);

      const quizData: QuizFormData[] = [];
      querySnapshot.forEach((doc) => {
        quizData.push({ ...doc.data(), quizz_id: doc.id } as QuizFormData);
      });

      setQuizzes(quizData);
      setFilteredQuizzes(quizData); // Initialize filtered quizzes
    } catch (error) {
      console.error(error);
    } finally {
      // setLoading(false);
    }
  };
  useEffect(() => {
    fetchQuizzes();
  }, [examId, yearId]);

  // Handle search filtration
  useEffect(() => {
    if (searchQuery.trim() === "") {
      setFilteredQuizzes(quizzes);
    } else {
      const filtered = quizzes.filter((quiz) =>
        quiz.Question.toLowerCase().includes(searchQuery.toLowerCase())
      );
      setFilteredQuizzes(filtered);
    }
  }, [searchQuery, quizzes]);
  const handleImageUpload = async (quizId: string, files: FileList | null) => {
    if (!files) return;
    if (!examId || !yearId || !quizId) {
      toast.error("Invalid IDs provided for image upload.");
      return;
    }
    const file = files[0];
    const storageRef = ref(storage, `quiz_images/${quizId}/${file.name}`);
    const uploadTask = uploadBytesResumable(storageRef, file);

    uploadTask.on(
      "state_changed",
      (snapshot) => {
        (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
      },
      (error) => {
        console.error(error);
        toast.error("Image upload failed.");
      },
      async () => {
        const downloadURL = await getDownloadURL(uploadTask.snapshot.ref);
        const updatedImages = [
          ...(quizzes.find((quiz) => quiz.quizz_id === quizId)
            ?.Question_image || []),
          downloadURL,
        ];

        try {
          await updateDoc(
            doc(db, "exams", examId, "years", yearId, "quizzes", quizId),
            { Question_image: updatedImages }
          );
          toast.success("Image uploaded successfully!");

          fetchQuizzes();
        } catch (err) {
          console.error(err);
          toast.error("Failed to update Firestore.");
        }
      }
    );
  };

  const deleteImage = async (quizId: string, imageUrl: string) => {
    if (!examId || !yearId || !subjectId) {
      toast.error("Exam ID or Year ID is missing.");
      return;
    }

    try {
      const quiz = quizzes.find((quiz) => quiz.quizz_id === quizId);
      if (!quiz) return;

      const updatedImages = quiz.Question_image.filter(
        (url) => url !== imageUrl
      );

      await updateDoc(
        doc(
          db,
          "exams",
          examId,
          "years",
          yearId,
          "subjects",
          subjectId,
          "quizzes",
          quizId
        ),
        { Question_image: updatedImages }
      );
      toast.success("Image deleted successfully!");
    } catch (error) {
      console.error(error);
      toast.error("Failed to delete image.");
    }
  };
  const handleEditQuiz = (quizId: string) => {
    const quizToEdit = quizzes.find((quiz) => quiz.quizz_id === quizId);
    if (quizToEdit) {
      setEditingQuiz(quizToEdit);
      setNewQuestion(quizToEdit.Question);
      setNewExplanation(quizToEdit.explanation);
      setNewOptions(quizToEdit.options);
      setNewCorrectAnswer(quizToEdit.correctAnswer);
    }
    setIsModalOpen(true);
  };
  const handleUpdateQuiz = async () => {
    if (!examId || !yearId || !editingQuiz || !subjectId) return;

    try {
      await updateDoc(
        doc(
          db,
          "exams",
          examId,
          "years",
          yearId,
          "subjects",
          subjectId,
          "quizzes",
          editingQuiz.quizz_id
        ),
        {
          Question: newQuestion,
          explanation: newExplanation,
          options: newOptions,
          correctAnswer: newCorrectAnswer,
        }
      );
      toast.success("Quiz updated successfully!");
      setEditingQuiz(null); // Reset editing state
      setIsModalOpen(false); // Close modal
      fetchQuizzes();
    } catch (error) {
      console.error(error);
      toast.error("Failed to update quiz.");
    }
  };

  const deleteQuiz = async (quizId: string) => {
    try {
      if (!examId || !yearId || !subjectId) {
        toast.error("Exam ID or Year ID is missing.");
        return;
      }

      await deleteDoc(
        doc(
          db,
          "exams",
          examId,
          "years",
          yearId,
          "subjects",
          subjectId,
          "quizzes",
          quizId
        )
      );
      setQuizzes((prev) => prev.filter((quiz) => quiz.quizz_id !== quizId));
      toast.success("Quiz deleted successfully.");
    } catch (error) {
      console.error(error);
      toast.error("Failed to delete quiz.");
    }
  };
  // const handleExplanationImageUpload = async (
  //   quizId: string,
  //   files: FileList | null
  // ) => {
  //   if (!files) return;
  //   if (!examId || !yearId || !quizId) {
  //     toast.error("Invalid IDs provided for image upload.");
  //     return;
  //   }

  //   const file = files[0];
  //   const storageRef = ref(
  //     storage,
  //     `explanation_images/${quizId}/${file.name}`
  //   );
  //   const uploadTask = uploadBytesResumable(storageRef, file);

  //   uploadTask.on(
  //     "state_changed",
  //     (snapshot) => {
  //       (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
  //     },
  //     (error) => {
  //       console.error(error);
  //       toast.error("Explanation image upload failed.");
  //     },
  //     async () => {
  //       const downloadURL = await getDownloadURL(uploadTask.snapshot.ref);

  //       const updatedExplanationImages = [
  //         ...(quizzes.find((quiz) => quiz.quizz_id === quizId)
  //           ?.Explanation_image || []),
  //         downloadURL,
  //       ];

  //       try {
  //         await updateDoc(
  //           doc(db, "exams", examId, "years", yearId, "quizzes", quizId),
  //           { Explanation_image: updatedExplanationImages }
  //         );
  //         toast.success("Explanation image uploaded successfully!");

  //         fetchQuizzes();
  //       } catch (err) {
  //         console.error(err);
  //         toast.error("Failed to update Firestore with explanation image.");
  //       }
  //     }
  //   );
  // };

  // const deleteExplanationImage = async (quizId: string, imageUrl: string) => {
  //   if (!examId || !yearId || !quizId) {
  //     toast.error("Invalid IDs provided for image deletion.");
  //     return;
  //   }

  //   try {
  //     const quiz = quizzes.find((quiz) => quiz.quizz_id === quizId);
  //     if (!quiz) return;

  //     const updatedExplanationImages = quiz.Explanation_image.filter(
  //       (url) => url !== imageUrl
  //     );

  //     await updateDoc(
  //       doc(db, "exams", examId, "years", yearId, "quizzes", quizId),
  //       { Explanation_image: updatedExplanationImages }
  //     );
  //     toast.success("Explanation image deleted successfully!");
  //     fetchQuizzes();
  //   } catch (error) {
  //     console.error(error);
  //     toast.error("Failed to delete explanation image.");
  //   }
  // };

  const handleOpenModal = (quizId: string) => {
    setSelectedQuizId(quizId);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setSelectedQuizId(null);
    setIsModalOpen(false);
  };
  const [blockColor, setBlockColor] = useState("hidden");
  const handleDownloadClick = (quizId: string) => {
    // Change the block color to purple
    setBlockColor("block");

    // Simulate download (replace with actual logic)
    downloadQuizAsImage(quizId);
  };
  const downloadQuizAsImage = async (quizId: string) => {
    const quizCardElement = document.getElementById(`quiz-card-${quizId}`);

    if (!quizCardElement) {
      console.error(`Quiz card with ID ${quizId} not found.`);
      return;
    }

    try {
      const dataUrl = await toPng(quizCardElement, {
        backgroundColor: "#fff", // Optional: Set background color to white
      });
      const images = quizCardElement.getElementsByTagName("img");
      Array.from(images).forEach((img) => {
        img.onload = () => console.log("Image loaded successfully", img.src);
        img.onerror = () => console.log("Error loading image", img.src);
      });

      // Create a temporary download link
      const link = document.createElement("a");
      link.href = dataUrl;
      link.download = `quiz-${quizId}.png`;

      // Trigger the download
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      console.error("Error converting quiz to image:", error);
    } finally {
      toast.success("Quiz downloaded as image!");
    }
  };

  return (
    <Layout>
      <div className="flex items-center flex-col justify-between w-full sm:flex-row  gap-4">
        <div className="flex-row flex w-full gap-4 ">
          <GoBackButton />
          <Card className="py-3 w-full text-center">
            {examId} - {yearId}
          </Card>
        </div>
        <div className="flex-row flex w-full gap-4 ">
          <BulkDownloadExcel
            quizzes={quizzes}
            yearId={yearId}
            examId={examId}
          />
          <DeleteAllQuizzes
            collectionName="exams"
            examId={examId}
            yearId={yearId}
            onComplete={() => toast.success("Sucess")}
          />
        </div>
      </div>
      <div className="grid sm:grid-cols-3 grid-cols-1 gap-4">
        <div>
          <QuizUploader />
        </div>
        <Card className="mx-auto p-6 space-y-4 col-span-2">
          <h2 className="text-2xl font-semibold">Add Quiz Manually</h2>
          <ManualQuizzAdd />
        </Card>
      </div>
      <form className="">
        <label htmlFor="chat-input" className="sr-only">
          Search Quizzzz....
        </label>
        <div className="relative">
          <input
            id="chat-input"
            className="block w-full resize-none rounded-xl border-2 border-blue-500 border-dashed bg-white p-4 pr-16 text-sm text-slate-900 md   sm:text-base"
            placeholder="Search Quizzzz...."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          ></input>
          <button
            type="submit"
            className="absolute bottom-2 right-2.5 rounded-lg bg-indigo-700 p-2 text-sm font-medium text-slate-200 hover:bg-indigo-800 focus:outline-none focus:ring-4 focus:ring-blue-300 dark:bg-indigo-600 dark:hover:bg-indigo-700 dark:focus:ring-blue-800 sm:text-base"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-6 w-6"
              aria-hidden="true"
              viewBox="0 0 24 24"
              strokeWidth="2"
              stroke="currentColor"
              fill="none"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
              <path d="M10 14l11 -11"></path>
              <path d="M21 3l-6.5 18a.55 .55 0 0 1 -1 0l-3.5 -7l-7 -3.5a.55 .55 0 0 1 0 -1l18 -6.5"></path>
            </svg>
            <span className="sr-only">Send message</span>
          </button>
        </div>
      </form>

      <div className="gap-4 mx-auto p-4 grid sm:grid-cols-2 grid-cols-1">
        {filteredQuizzes.map((quiz) => (
          <Card
            key={quiz.quizz_id}
            className="border-2 border-gray-300 p-4 rounded-lg md flex flex-col justify-between"
          >
            <h3 className="text-xl font-semibold mb-4">{quiz.Question}</h3>
            <div className="space-y-2 mb-4">
              {quiz.options.map((option) => (
                <div
                  key={option.Option_ID}
                  className={`flex items-center p-2 rounded-lg ${
                    option.Option_ID === quiz.correctAnswer
                      ? "border-2 font-bold border-green-500 text-green-600 border-dashed"
                      : "border border-gray-300"
                  }`}
                >
                  <input
                    type="radio"
                    id={`${quiz.quizz_id}-${option.Option_ID}`}
                    name={quiz.quizz_id}
                    disabled
                    checked={option.Option_ID === quiz.correctAnswer}
                    className="mr-2"
                  />
                  <label
                    htmlFor={`${quiz.quizz_id}-${option.Option_ID}`}
                    className="text-lg"
                  >
                    {option.Option_Text}
                  </label>
                </div>
              ))}
            </div>
            {quiz.Question_image?.[0] &&
              quiz.Question_image[0] !== "" &&
              quiz.Question_image[1] !== "" && (
                <img
                  src={quiz.Question_image[0]}
                  alt="Question illustration"
                  className="mt-4 w-full max-w-sm mx-auto rounded-md shadow"
                />
              )}
            {quiz.Question_image?.[1] && quiz.Question_image[1] !== "" && (
              <img
                src={quiz.Question_image[1]}
                alt="Question illustration"
                className="mt-4 w-full max-w-sm mx-auto rounded-md shadow"
              />
            )}
            {quiz.explanation && (
              <p className="text-sm text-gray-600 mb-4">{quiz.explanation}</p>
            )}
            <div className="flex flex-row gap-2">
              <Button
                variant="secondary"
                className="w-full mt-4 border bg-gray-200"
                onClick={() => handleOpenModal(quiz.quizz_id)}
              >
                View Images
              </Button>
              <Button
                variant="secondary"
                className="mt-4  border border-gray-500"
                onClick={() => handleEditQuiz(quiz.quizz_id)}
              >
                <Edit3 />
              </Button>
              <Button
                variant="destructive"
                className="w-[20%] mt-4"
                onClick={() => deleteQuiz(quiz.quizz_id)}
              >
                <Trash2 />
              </Button>
              <Button
                variant="destructive"
                className="w-full mt-4 bg-blue-500 text-white"
                onClick={() => handleDownloadClick(quiz.quizz_id)}
              >
                Download
              </Button>
            </div>

            <div id={`quiz-card-${quiz.quizz_id}`} className="w-[80%]">
              <div
                className={`${blockColor} bg-[#302ea7]  p-4 rounded-lg lg `}
              >
                <div className={` bg-white p-4 rounded-lg lg  `}>
                  <div className="text-center ">
                    {/* Logo Image */}
                    <div className="text-black text-center mb-6">
                      <h1 className="  text-3xl font-extrabold">
                        SchoolX
                        <span className="text-[#302ea7] mx-1">Exams</span>
                      </h1>

                      <p className="mt-2 text-2xl font-medium">
                        Free Quizzes, Flashcards & PYQ for TNPSC
                      </p>
                    </div>
                    {/* Question Number */}
                    <h1 className="text-xl font-bold">Q.{quiz.Question}</h1>

                    {/* Question and Options */}
                    <p className="mt-2 text-lg"></p>

                    <div className="grid grid-cols-2 gap-4 mb-6">
                      {quiz.options.map((option, index) => {
                        // Define the ABCD labels
                        const label = ["A", "B", "C", "D"][index];

                        return (
                          <div
                            key={option.Option_ID}
                            className={`flex items-center p-2 rounded-lg bg-white border  ${
                              option.Option_ID === quiz.correctAnswer
                                ? "border font-bold border-[#302ea7] text-[#302ea7] bg-indigo-200"
                                : "border border-gray-300"
                            }`}
                          >
                            {/* Hide the radio button */}
                            <input
                              type="radio"
                              id={`${quiz.quizz_id}-${option.Option_ID}`}
                              name={quiz.quizz_id}
                              disabled
                              checked={option.Option_ID === quiz.correctAnswer}
                              className="mr-2 hidden" // Use 'hidden' class to hide the radio button
                            />
                            <label
                              htmlFor={`${quiz.quizz_id}-${option.Option_ID}`}
                              className="text-lg"
                            >
                              {/* Add ABCD before the option */}
                              {label}. {option.Option_Text}
                            </label>
                          </div>
                        );
                      })}
                    </div>

                    <div className="text-center text-black">
                      <p className="text-lg">
                        Use promo code <strong>CRACK25</strong> to get 50% OFF
                        on premium content.
                      </p>
                    </div>

                    <div className="mt-6 text-xl font-extrabold text-center text-black">
                      <p>
                        Your Success,{" "}
                        <span className="text-[#302ea7]">Our Mission</span> !
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* Modal for viewing images and uploading */}

      <Modal isOpen={isModalOpen} onClose={handleCloseModal}>
        <div className="p-4 flex flex-row w-full">
          <div className="w-full">
            {editingQuiz && (
              <div className="space-y-4">
                <h2 className="text-2xl mb-4">Edit Quiz</h2>

                <div>
                  <label className="block text-sm text-gray-600">
                    Question
                  </label>
                  <input
                    type="text"
                    value={newQuestion}
                    onChange={(e) => setNewQuestion(e.target.value)}
                    className="w-full p-2 border border-gray-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-sm text-gray-600">
                    Explanation
                  </label>
                  <textarea
                    value={newExplanation}
                    onChange={(e) => setNewExplanation(e.target.value)}
                    className="w-full p-2 border border-gray-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-sm text-gray-600">Options</label>
                  <div className="flex flex-col gap-4">
                    {newOptions.map((option, index) => (
                      <div
                        key={index}
                        className="flex items-center gap-3 w-full"
                      >
                        <input
                          type="radio"
                          id={`option-${option.Option_ID}`}
                          name="correctAnswer"
                          checked={option.Option_ID === newCorrectAnswer}
                          onChange={() => setNewCorrectAnswer(option.Option_ID)}
                          className="hidden"
                        />
                        <label
                          htmlFor={`option-${option.Option_ID}`}
                          className={`w-full flex items-center cursor-pointer text-lg px-4 py-2 rounded-lg transition-all ${
                            option.Option_ID === newCorrectAnswer
                              ? "bg-red-500 text-white ring-2 ring-red-500"
                              : "bg-gray-200 hover:bg-gray-300"
                          }`}
                        >
                          <span className="w-5 h-5 mr-3 flex items-center justify-center rounded-full border-2 border-gray-400 transition-all">
                            {option.Option_ID === newCorrectAnswer && (
                              <span className="w-3 h-3 bg-white rounded-full"></span>
                            )}
                          </span>
                          {option.Option_Text}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="secondary"
                    className="w-full hover:bg-indigo-800 bg-indigo-600 text-white"
                    onClick={handleUpdateQuiz}
                  >
                    Update Quiz
                  </Button>
                  <Button variant="destructive" onClick={handleCloseModal}>
                    Cancel
                  </Button>
                </div>
              </div>
            )}
          </div>
          <div className="p-4 w-full">
            <h2 className="text-2xl mb-4">Existing Images</h2>
            <div className="grid grid-cols-3 gap-4">
              {quizzes
                .find((quiz) => quiz.quizz_id === selectedQuizId)
                ?.Question_image?.slice(1)
                .map((imageUrl, index) => (
                  <div key={index} className="relative">
                    <img
                      src={imageUrl}
                      alt={`Existing Image ${index}`}
                      className="w-full h-auto rounded-md lg"
                    />
                    <button
                      onClick={() => deleteImage(selectedQuizId!, imageUrl)}
                      className="absolute top-2 right-2 bg-red-500 text-white rounded-full p-1"
                    >
                      <Trash2 />
                    </button>
                  </div>
                ))}
            </div>

            <div className="mt-4">
              <div className="relative">
                {/* File Input Container */}
                <input
                  type="file"
                  accept="image/*"
                  id="image-upload-modal"
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                  onChange={(e) =>
                    handleImageUpload(selectedQuizId!, e.target.files)
                  }
                />
                <div className="flex justify-center items-center w-full h-32 border-2 border-gray-300 border-dashed rounded-lg bg-gray-50">
                  <div className="flex flex-col justify-center items-center">
                    <UploadCloud className="w-12 h-12 text-accent_color mb-2" />
                    <span className="text-sm text-gray-600">
                      Click or Drag to Upload
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Modal>
    </Layout>
  );
};

export default ManualQuizUploader;
