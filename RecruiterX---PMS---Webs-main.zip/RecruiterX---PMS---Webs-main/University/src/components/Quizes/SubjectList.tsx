import React, { useState, useEffect, ChangeEvent, FormEvent } from "react";
import { db } from "../../config/FirebaseConfig";
import {
  collection,
  getDocs,
  doc,
  setDoc,
  deleteDoc,
  Timestamp,
} from "firebase/firestore";
import { useParams, Link } from "react-router-dom";
import toast from "react-hot-toast";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import Layout from "@/Layout/Layout";
import { GoBackButton } from "../Users/utlis";
import { Trash2 } from "lucide-react";

const SubjectList: React.FC = () => {
  const { examId, yearId } = useParams<{ examId: string; yearId: string }>();
  const [subjects, setSubjects] = useState<any[]>([]);
  const [newSubject, setNewSubject] = useState<string>("");
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [subjectToDelete, setSubjectToDelete] = useState<string | null>(null);
  const fetchSubjects = async () => {
    if (!examId || !yearId) {
      toast.error("Exam ID or Year ID is missing.");
      return;
    }
    try {
      const subjectCollectionRef = collection(
        db,
        "exams",
        examId,
        "years",
        yearId,
        "subjects"
      );
      const subjectSnapshot = await getDocs(subjectCollectionRef);
      const subjectList = subjectSnapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setSubjects(subjectList);
    } catch (error) {
      toast.error("Error fetching subjects.");
    }
  };
  // Fetch all subjects under the selected exam and year
  useEffect(() => {
    fetchSubjects();
  }, [examId, yearId]);

  // Handle input change for the new subject
  const handleNewSubjectChange = (e: ChangeEvent<HTMLInputElement>) => {
    setNewSubject(e.target.value);
  };

  // Handle submit to add new subject with custom document ID
  const handleAddSubject = async (e: FormEvent) => {
    e.preventDefault();
    if (newSubject.trim() === "") {
      toast.error("Subject name cannot be empty.");
      return;
    }

    if (!examId || !yearId) {
      toast.error("Exam ID or Year ID is missing.");
      return;
    }

    try {
      const subjectDocRef = doc(
        db,
        "exams",
        examId,
        "years",
        yearId,
        "subjects",
        newSubject
      );
      await setDoc(subjectDocRef, {
        subject: newSubject,
        createdAt: Timestamp.fromDate(new Date()),
      });
      setNewSubject("");
      toast.success("Subject added successfully!");
      fetchSubjects();
    } catch (error) {
      toast.error("Error adding subject.");
    }
  };

  // Handle delete subject
  const handleDeleteSubject = async () => {
    if (!subjectToDelete || !examId || !yearId) {
      toast.error("Required data is missing.");
      return;
    }

    try {
      const subjectDocRef = doc(
        db,
        "exams",
        examId,
        "years",
        yearId,
        "subjects",
        subjectToDelete
      );
      await deleteDoc(subjectDocRef);
      toast.success("Subject deleted successfully!");
      fetchSubjects();
      setSubjectToDelete(null);
      setIsModalOpen(false);
    } catch (error) {
      toast.error("Error deleting subject.");
    }
  };

  // Open confirmation modal
  const confirmDelete = (subjectId: string) => {
    setSubjectToDelete(subjectId);
    setIsModalOpen(true);
  };

  return (
    <Layout>
      <GoBackButton />
      <Card className="none">
        <CardHeader>
          <CardTitle className="text-2xl font-semibold">
            Add New Subject
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleAddSubject} className="flex gap-4">
            <Input
              type="text"
              value={newSubject}
              onChange={handleNewSubjectChange}
              placeholder="Enter Subject Name"
              required
              className="flex-grow"
            />
            <Button
              type="submit"
              variant="outline"
              className="bg-accent_color text-white"
            >
              Add Subject
            </Button>
          </form>
        </CardContent>
      </Card>

      <Card className="none">
        <CardHeader>
          <CardTitle className="text-2xl font-semibold">
            Available Subjects
          </CardTitle>
        </CardHeader>
        <CardContent>
          {subjects.length > 0 ? (
            <ul className="grid sm:grid-cols-3 grid-cols-1 gap-4">
              {subjects.map((subject) => (
                <div
                  key={subject.id}
                  className="border-dashed border-blue-700 items-center justify-between border-2 flex flex-row p-2 rounded-lg 0 hover:bg-indigo-200 cursor-pointer"
                >
                  <Link
                    to={`/exam/${examId}/year/${yearId}/subject/${subject.id}`}
                    className="text-lg font-medium text-blue-600 hover:text-blue-800"
                  >
                    {subject.subject}
                  </Link>
                  <Button
                    onClick={() => confirmDelete(subject.id)}
                    variant="outline"
                    className="bg-red-500 text-white p-2"
                  >
                    <Trash2 />
                  </Button>
                </div>
              ))}
            </ul>
          ) : (
            <p className="text-gray-500">No subjects available.</p>
          )}
        </CardContent>
      </Card>

      {/* Confirmation Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
          <div className="bg-white p-6 rounded-lg lg max-w-sm w-full">
            <h2 className="text-xl font-semibold mb-4">Confirm Deletion</h2>
            <p className="text-gray-600 mb-6">
              Are you sure you want to delete this subject? This action cannot
              be undone.
            </p>
            <div className="flex justify-end gap-4">
              <Button
                onClick={() => setIsModalOpen(false)}
                variant="outline"
                className="bg-gray-200 text-gray-800"
              >
                Cancel
              </Button>
              <Button
                onClick={handleDeleteSubject}
                variant="outline"
                className="bg-red-500 text-white"
              >
                Delete
              </Button>
            </div>
          </div>
        </div>
      )}
    </Layout>
  );
};

export default SubjectList;
