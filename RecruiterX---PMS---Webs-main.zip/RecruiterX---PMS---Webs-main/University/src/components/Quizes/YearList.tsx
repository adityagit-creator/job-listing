import React, { useState, useEffect, ChangeEvent, FormEvent } from "react";
import { db } from "../../config/FirebaseConfig";
import {
  collection,
  getDocs,
  doc,
  setDoc,
  deleteDoc,
  getDoc,
} from "firebase/firestore";
import { useParams, Link } from "react-router-dom";
import toast from "react-hot-toast";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import Layout from "@/Layout/Layout";
import { GoBackButton } from "../Users/utlis";
import { Trash2 } from "lucide-react";

const YearListPage: React.FC = () => {
  const { examId } = useParams();
  const [years, setYears] = useState<any[]>([]);
  const [newYear, setNewYear] = useState<string>("");
  const [syllabus, setSyllabus] = useState<string>(""); // For storing syllabus content
  const [isEditable, setIsEditable] = useState<boolean>(false); // Track if the syllabus is editable
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [yearToDelete, setYearToDelete] = useState<string | null>(null);

  // Fetch all years under the selected exam
  useEffect(() => {
    const fetchYears = async () => {
      if (!examId) return;
      try {
        const yearCollectionRef = collection(db, "exams", examId, "years");
        const yearSnapshot = await getDocs(yearCollectionRef);
        const yearList = yearSnapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));
        setYears(yearList);
      } catch (error) {
        toast.error("Error fetching years.");
      }
    };

    const fetchSyllabus = async () => {
      if (!examId) return;
      try {
        const examDocRef = doc(db, "exams", examId);
        const examDoc = await getDoc(examDocRef);
        if (examDoc.exists()) {
          setSyllabus(examDoc.data().syllabus || ""); // Fetch syllabus from the database
        }
      } catch (error) {
        toast.error("Error fetching syllabus.");
      }
    };

    fetchYears();
    fetchSyllabus();
  }, [examId]);

  // Handle input change for the new year
  const handleNewYearChange = (e: ChangeEvent<HTMLInputElement>) => {
    setNewYear(e.target.value);
  };

  // Handle Quill editor change for syllabus
  // const handleSyllabusChange = (value: string) => {
  //   setSyllabus(value);
  // };

  // Handle submit to add new year and syllabus
  const handleAddYear = async (e: FormEvent) => {
    e.preventDefault();

    if (newYear.trim() === "") {
      toast.error("Year cannot be empty.");
      return;
    }

    if (!examId) {
      toast.error("Exam ID is missing.");
      return;
    }

    try {
      const yearDocRef = doc(db, "exams", examId, "years", newYear);
      await setDoc(yearDocRef, {
        year: newYear,
      });

      setNewYear("");
      setSyllabus(""); // Clear the syllabus editor after saving
      toast.success("Year and syllabus added successfully!");
      fetchYears(); // Refresh the years list
    } catch (error) {
      toast.error("Error adding year.");
    }
  };

  // Handle delete year
  const handleDeleteYear = async () => {
    if (!yearToDelete || !examId) return;

    try {
      const yearDocRef = doc(db, "exams", examId, "years", yearToDelete);
      await deleteDoc(yearDocRef);
      toast.success("Year deleted successfully!");
      setYearToDelete(null);
      setIsModalOpen(false);
      fetchYears(); // Refresh the years list
    } catch (error) {
      toast.error("Error deleting year.");
    }
  };

  // Open confirmation modal
  const confirmDelete = (yearId: string) => {
    setYearToDelete(yearId);
    setIsModalOpen(true);
  };

  // Fetch years again
  const fetchYears = async () => {
    if (!examId) return;
    const yearCollectionRef = collection(db, "exams", examId, "years");
    const yearSnapshot = await getDocs(yearCollectionRef);
    const yearList = yearSnapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    }));
    setYears(yearList);
  };

  // Toggle syllabus edit mode
  const toggleEditSyllabus = () => {
    setIsEditable(!isEditable);
  };

  // Handle save syllabus
  const handleSaveSyllabus = async () => {
    if (!examId) {
      toast.error("Exam ID is missing.");
      return;
    }

    try {
      const examDocRef = doc(db, "exams", examId);
      const examDoc = await getDoc(examDocRef);

      // Check if the exam document exists
      if (!examDoc.exists()) {
        toast.error("Exam not found.");
        return;
      }

      const existingSyllabus = examDoc.data()?.syllabus;

      // If syllabus already exists and it's the same as the new one, don't update
      if (existingSyllabus === syllabus) {
        toast.success("Syllabus is already up to date. No changes made.");
        return;
      }

      // If syllabus exists but is different, update it
      await setDoc(examDocRef, { syllabus: syllabus }, { merge: true });

      setIsEditable(false);
      toast.success("Syllabus updated successfully!");
    } catch (error) {
      toast.error("Error saving syllabus.");
    }
  };

  return (
    <Layout>
      <GoBackButton />
      <Card className="none">
        <CardHeader>
          <CardTitle className="text-2xl font-semibold">Add Syllabus</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-row gap-5">
          <Input
            type="text"
            value={newYear}
            onChange={handleNewYearChange}
            placeholder="Enter year"
            required
            className="flex-grow"
          />
          <Button
            type="submit"
            variant="outline"
            onClick={handleAddYear}
            className="bg-accent_color  text-white"
          >
            Add Year & Syllabus
          </Button>
        </CardContent>
      </Card>

      <Card className="none">
        <CardHeader>
          <CardTitle className="text-2xl font-semibold">
            Available Syllabus
          </CardTitle>
        </CardHeader>
        <CardContent>
          {years.length > 0 ? (
            <ul className="grid sm:grid-cols-3 grid-cols-1 gap-4">
              {years.map((year) => (
                <div
                  key={year.id}
                  className="border-dashed border-blue-700 items-center justify-between border-2 flex flex-row p-2 rounded-lg 0 hover:bg-indigo-200 cursor-pointer"
                >
                  <Link
                    to={`/exam/${examId}/year/${year.id}`}
                    className="text-lg font-medium text-blue-600 hover:text-blue-800"
                  >
                    {year.year}
                  </Link>
                  <Button
                    onClick={() => confirmDelete(year.id)}
                    variant="outline"
                    className="bg-red-500 text-white p-2"
                  >
                    <Trash2 />
                  </Button>
                </div>
              ))}
            </ul>
          ) : (
            <p className="text-gray-500">No years available.</p>
          )}
        </CardContent>
      </Card>

      {/* Confirmation Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
          <div className="bg-white p-6 rounded-lg lg max-w-sm w-full">
            <h2 className="text-xl font-semibold mb-4">Confirm Deletion</h2>
            <p className="text-gray-600 mb-6">
              Are you sure you want to delete this year? This action cannot be
              undone.
            </p>
            <div className="flex justify-end gap-4">
              <Button
                onClick={() => setIsModalOpen(false)}
                variant="outline"
                className="bg-gray-200 text-gray-800"
              >
                Cancel
              </Button>
              <Button
                onClick={handleDeleteYear}
                variant="outline"
                className="bg-red-500 text-white"
              >
                Delete
              </Button>
            </div>
          </div>
        </div>
      )}

      <div>
       <div className="flex gap-4">
          <div className="w-full mt-4">
            <label className="block text-lg font-medium text-gray-700 mb-2">
              Syllabus
            </label>
            {isEditable ? (
              <div className="w-full mt-4">
                <label className="block text-lg font-medium text-gray-700 mb-2">
                  Syllabus
                </label>
                <textarea
                  value={syllabus}
                  onChange={(e) => setSyllabus(e.target.value)}
                  className="w-full h-56 border border-gray-300 rounded-md p-2"
                />
              </div>
            ) : (
              <div className="w-full">
              <div 
                className="w-full max-w-4xl mx-auto p-4"
                dangerouslySetInnerHTML={{ 
                  __html: syllabus
                }} 
              />
        
             
            </div>
            )}
          </div>
        </div>

        <div className="flex gap-4 mt-4">
          <Button
            onClick={toggleEditSyllabus}
            variant="outline"
            className="bg-blue-500 text-white"
          >
            {isEditable ? "Cancel Edit" : "Edit Syllabus"}
          </Button>
          {isEditable && (
            <Button
              onClick={handleSaveSyllabus}
              variant="outline"
              className="bg-green-500 text-white"
            >
              Save Syllabus
            </Button>
          )}
        </div>
      </div>
    </Layout>
  );
};

export default YearListPage;
 