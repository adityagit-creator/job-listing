import React, { useState } from 'react';
import { toast } from 'react-hot-toast';
import { useCompany } from '@/hooks/useCompany';
import { JobPosting } from '@/types/placement';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Plus } from 'lucide-react';

const AddJobPosting = () => {
  const { addNewJob } = useCompany();
  const [open, setOpen] = useState(false);
  const [formData, setFormData] = useState({
    jobTitle: '',
    description: '',
    companyName: '', // Added company name field
    eligibility: {
      minimumCGPA: 0,
      allowedBranches: [''],
      allowedBatchYears: [''],
      maxBacklogs: 0,
      otherCriteria: [''],
    },
    package: {
      ctc: 0,
      breakup: {
        basic: 0,
        hra: 0,
        bonus: 0,
        stockOptions: 0,
        otherBenefits: [''],
      },
    },
    location: [''],
    type: 'full-time' as const,
    mode: 'onsite' as const,
    rounds: [{
      type: 'online_test' as const,
      description: '',
      duration: 0,
    }],
    deadline: '', // Change to string to handle date input
    positions: 0,
    documents: {
      required: ['resume'],
      optional: [''],
    },
    stats: {
      numberOfStudentsApplied: 0,
      studentIds: [''], // Added student IDs field
    },
  });

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>,
    section?: string,
    subsection?: string
  ) => {
    const { name, value } = e.target;
    if (section) {
      if (subsection) {
        setFormData(prev => ({
          ...prev,
          [section]: {
            ...prev[section],
            [subsection]: {
              ...prev[section][subsection],
              [name]: value,
            },
          },
        }));
      } else {
        setFormData(prev => ({
          ...prev,
          [section]: {
            ...prev[section],
            [name]: value,
          },
        }));
      }
    } else {
      setFormData(prev => ({
        ...prev,
        [name]: value,
      }));
    }
  };

  const handleArrayChange = (
    index: number,
    value: string,
    section: string,
    field: string
  ) => {
    setFormData(prev => {
      const newArray = [...prev[section][field]];
      newArray[index] = value;
      return {
        ...prev,
        [section]: {
          ...prev[section],
          [field]: newArray,
        },
      };
    });
  };

  const handleAddArrayItem = (section: string, field: string) => {
    setFormData(prev => ({
      ...prev,
      [section]: {
        ...prev[section],
        [field]: [...prev[section][field], ''],
      },
    }));
  };

  const handleRemoveArrayItem = (section: string, field: string, index: number) => {
    setFormData(prev => ({
      ...prev,
      [section]: {
        ...prev[section],
        [field]: prev[section][field].filter((_, i) => i !== index),
      },
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await addNewJob({
        ...formData,
        companyId: '', // This should be set based on the current company context
        status: 'draft',
        deadline: new Date(formData.deadline), // Convert deadline to Date object
      });
      setOpen(false);
      setFormData({
        jobTitle: '',
        description: '',
        companyName: '', // Reset company name field
        eligibility: {
          minimumCGPA: 0,
          allowedBranches: [''],
          allowedBatchYears: [''],
          maxBacklogs: 0,
          otherCriteria: [''],
        },
        package: {
          ctc: 0,
          breakup: {
            basic: 0,
            hra: 0,
            bonus: 0,
            stockOptions: 0,
            otherBenefits: [''],
          },
        },
        location: [''],
        type: 'full-time',
        mode: 'onsite',
        rounds: [{
          type: 'online_test',
          description: '',
          duration: 0,
        }],
        deadline: '', // Reset to empty string
        positions: 0,
        documents: {
          required: ['resume'],
          optional: [''],
        },
        stats: {
          numberOfStudentsApplied: 0,
          studentIds: [''], // Reset student IDs field
        },
      });
    } catch (error) {
      console.error('Error adding job posting:', error);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>
          <Plus className="mr-2 h-4 w-4" />
          Add Job Posting
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Add New Job Posting</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Basic Information */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Basic Information</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium">Job Title</label>
                <Input
                  name="jobTitle"
                  value={formData.jobTitle}
                  onChange={handleInputChange}
                  required
                />
              </div>
              <div>
                <label className="text-sm font-medium">Company Name</label>
                <Input
                  name="companyName"
                  value={formData.companyName}
                  onChange={handleInputChange}
                  required
                />
              </div>
              <div>
                <label className="text-sm font-medium">Positions</label>
                <Input
                  type="number"
                  name="positions"
                  value={formData.positions}
                  onChange={handleInputChange}
                  required
                />
              </div>
            </div>
            <div>
              <label className="text-sm font-medium">Description</label>
              <Textarea
                name="description"
                value={formData.description}
                onChange={handleInputChange}
                required
                rows={4}
              />
            </div>
          </div>

          {/* Eligibility */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Eligibility</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium">Minimum CGPA</label>
                <Input
                  type="number"
                  step="0.01"
                  name="minimumCGPA"
                  value={formData.eligibility.minimumCGPA}
                  onChange={(e) => handleInputChange(e, 'eligibility')}
                  required
                />
              </div>
              <div>
                <label className="text-sm font-medium">Maximum Backlogs</label>
                <Input
                  type="number"
                  name="maxBacklogs"
                  value={formData.eligibility.maxBacklogs}
                  onChange={(e) => handleInputChange(e, 'eligibility')}
                  required
                />
              </div>
            </div>
            <div>
              <h4 className="text-md font-medium mb-2">Allowed Branches</h4>
              {formData.eligibility.allowedBranches.map((branch, index) => (
                <div key={index} className="flex gap-2 mb-2">
                  <Input
                    value={branch}
                    onChange={(e) => handleArrayChange(index, e.target.value, 'eligibility', 'allowedBranches')}
                    placeholder={`Branch ${index + 1}`}
                  />
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => handleRemoveArrayItem('eligibility', 'allowedBranches', index)}
                  >
                    Remove
                  </Button>
                </div>
              ))}
              <Button
                type="button"
                variant="outline"
                onClick={() => handleAddArrayItem('eligibility', 'allowedBranches')}
              >
                Add Branch
              </Button>
            </div>
          </div>

          {/* Package Details */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Package Details</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium">CTC (Annual)</label>
                <Input
                  type="number"
                  name="ctc"
                  value={formData.package.ctc}
                  onChange={(e) => handleInputChange(e, 'package')}
                  required
                />
              </div>
              <div>
                <label className="text-sm font-medium">Basic</label>
                <Input
                  type="number"
                  name="basic"
                  value={formData.package.breakup.basic}
                  onChange={(e) => handleInputChange(e, 'package', 'breakup')}
                  required
                />
              </div>
              <div>
                <label className="text-sm font-medium">HRA</label>
                <Input
                  type="number"
                  name="hra"
                  value={formData.package.breakup.hra}
                  onChange={(e) => handleInputChange(e, 'package', 'breakup')}
                  required
                />
              </div>
              <div>
                <label className="text-sm font-medium">Bonus</label>
                <Input
                  type="number"
                  name="bonus"
                  value={formData.package.breakup.bonus}
                  onChange={(e) => handleInputChange(e, 'package', 'breakup')}
                />
              </div>
            </div>
          </div>

          {/* Job Details */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Job Details</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium">Type</label>
                <select
                  name="type"
                  value={formData.type}
                  onChange={handleInputChange}
                  className="w-full border rounded-md p-2"
                  required
                >
                  <option value="full-time">Full Time</option>
                  <option value="part-time">Part Time</option>
                  <option value="internship">Internship</option>
                </select>
              </div>
              <div>
                <label className="text-sm font-medium">Mode</label>
                <select
                  name="mode"
                  value={formData.mode}
                  onChange={handleInputChange}
                  className="w-full border rounded-md p-2"
                  required
                >
                  <option value="onsite">On-site</option>
                  <option value="remote">Remote</option>
                  <option value="hybrid">Hybrid</option>
                </select>
              </div>
              <div>
                <label className="text-sm font-medium">Deadline</label>
                <Input
                  type="date"
                  name="deadline"
                  value={formData.deadline}
                  onChange={handleInputChange}
                  required
                />
              </div>
             
            </div>
          </div>

     

          {/* Required Documents */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Required Documents</h3>
            <div>
              <h4 className="text-md font-medium mb-2">Required Documents</h4>
              {formData.documents.required.map((doc, index) => (
                <div key={index} className="flex gap-2 mb-2">
                  <Input
                    value={doc}
                    onChange={(e) => handleArrayChange(index, e.target.value, 'documents', 'required')}
                    placeholder={`Required Document ${index + 1}`}
                  />
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => handleRemoveArrayItem('documents', 'required', index)}
                  >
                    Remove
                  </Button>
                </div>
              ))}
              <Button
                type="button"
                variant="outline"
                onClick={() => handleAddArrayItem('documents', 'required')}
              >
                Add Required Document
              </Button>
            </div>
          </div>

          <div className="flex justify-end space-x-2">
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button type="submit">Create Job Posting</Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default AddJobPosting;
