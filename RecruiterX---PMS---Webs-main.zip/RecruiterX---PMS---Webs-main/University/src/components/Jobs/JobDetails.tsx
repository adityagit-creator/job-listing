import React from 'react';
import { JobPosting } from '@/types/placement';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Building,
  Calendar,
  MapPin,
  Users,
  Briefcase,
  Clock,
  CheckCircle,
  FileText,
  GraduationCap,
  DollarSign,
} from 'lucide-react';

interface JobDetailsProps {
  job: JobPosting;
}

const JobDetails: React.FC<JobDetailsProps> = ({ job }) => {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-start">
            <div>
              <CardTitle className="text-2xl font-bold">{job.jobTitle}</CardTitle>
              <div className="flex items-center gap-2 mt-2 text-gray-600">
                <Building className="h-4 w-4" />
                <span>Company Name</span>
              </div>
            </div>
            <Badge variant={job.status === 'open' ? 'success' : 'secondary'}>
              {job.status}
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="flex items-center gap-2">
              <MapPin className="h-4 w-4 text-gray-400" />
              <span>{job.location.join(', ')}</span>
            </div>
            <div className="flex items-center gap-2">
              <Briefcase className="h-4 w-4 text-gray-400" />
              <span>{job.type}</span>
            </div>
            <div className="flex items-center gap-2">
              <Users className="h-4 w-4 text-gray-400" />
              <span>{job.positions} Positions</span>
            </div>
            <div className="flex items-center gap-2">
              <Calendar className="h-4 w-4 text-gray-400" />
              <span>Deadline: {new Date(job.deadline).toLocaleDateString()}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Description */}
      <Card>
        <CardHeader>
          <CardTitle>Job Description</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-600 whitespace-pre-wrap">{job.description}</p>
        </CardContent>
      </Card>

      {/* Responsibilities */}
      <Card>
        <CardHeader>
          <CardTitle>Responsibilities</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="list-disc list-inside space-y-2">
            {job.responsibilities.map((responsibility, index) => (
              <li key={index} className="text-gray-600">{responsibility}</li>
            ))}
          </ul>
        </CardContent>
      </Card>

      {/* Requirements */}
      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Essential Requirements</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="list-disc list-inside space-y-2">
              {job.requirements.essential.map((requirement, index) => (
                <li key={index} className="text-gray-600">{requirement}</li>
              ))}
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Preferred Requirements</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="list-disc list-inside space-y-2">
              {job.requirements.preferred.map((requirement, index) => (
                <li key={index} className="text-gray-600">{requirement}</li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>

      {/* Eligibility */}
      <Card>
        <CardHeader>
          <CardTitle>Eligibility Criteria</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold mb-2">Academic Requirements</h4>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <GraduationCap className="h-4 w-4 text-gray-400" />
                  <span>Minimum CGPA: {job.eligibility.minimumCGPA}</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-gray-400" />
                  <span>Maximum Backlogs: {job.eligibility.maxBacklogs}</span>
                </div>
              </div>
            </div>
            <div>
              <h4 className="font-semibold mb-2">Eligible Branches</h4>
              <div className="flex flex-wrap gap-2">
                {job.eligibility.allowedBranches.map((branch, index) => (
                  <Badge key={index} variant="outline">{branch}</Badge>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Package Details */}
      <Card>
        <CardHeader>
          <CardTitle>Package Details</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold mb-4">CTC Breakup</h4>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Total CTC</span>
                  <span className="font-semibold">{formatCurrency(job.package.ctc)}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Basic</span>
                  <span>{formatCurrency(job.package.breakup.basic)}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">HRA</span>
                  <span>{formatCurrency(job.package.breakup.hra)}</span>
                </div>
                {job.package.breakup.bonus > 0 && (
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Bonus</span>
                    <span>{formatCurrency(job.package.breakup.bonus)}</span>
                  </div>
                )}
              </div>
            </div>
            {job.package.breakup.otherBenefits && job.package.breakup.otherBenefits.length > 0 && (
              <div>
                <h4 className="font-semibold mb-4">Additional Benefits</h4>
                <ul className="list-disc list-inside space-y-2">
                  {job.package.breakup.otherBenefits.map((benefit, index) => (
                    <li key={index} className="text-gray-600">{benefit}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Selection Process */}
      <Card>
        <CardHeader>
          <CardTitle>Selection Process</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {job.rounds.map((round, index) => (
              <div key={index} className="flex items-start gap-4">
                <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                  <span className="font-semibold text-primary">{index + 1}</span>
                </div>
                <div>
                  <h4 className="font-semibold capitalize">{round.type.replace('_', ' ')}</h4>
                  <p className="text-gray-600 mt-1">{round.description}</p>
                  {round.duration && (
                    <div className="flex items-center gap-2 mt-2 text-sm text-gray-500">
                      <Clock className="h-4 w-4" />
                      <span>Duration: {round.duration} minutes</span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Required Documents */}
      <Card>
        <CardHeader>
          <CardTitle>Required Documents</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold mb-2">Required Documents</h4>
              <ul className="space-y-2">
                {job.documents.required.map((doc, index) => (
                  <li key={index} className="flex items-center gap-2">
                    <FileText className="h-4 w-4 text-gray-400" />
                    <span className="capitalize">{doc.replace('_', ' ')}</span>
                  </li>
                ))}
              </ul>
            </div>
            {job.documents.optional && job.documents.optional.length > 0 && (
              <div>
                <h4 className="font-semibold mb-2">Optional Documents</h4>
                <ul className="space-y-2">
                  {job.documents.optional.map((doc, index) => (
                    <li key={index} className="flex items-center gap-2">
                      <FileText className="h-4 w-4 text-gray-400" />
                      <span>{doc}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default JobDetails; 