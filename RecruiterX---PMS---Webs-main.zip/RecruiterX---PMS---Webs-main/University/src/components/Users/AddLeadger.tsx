import React, { useState, ChangeEvent, FormEvent } from "react";
import { useParams } from "react-router-dom";
import { db } from "@/config/FirebaseConfig";
import { doc, setDoc, serverTimestamp } from "firebase/firestore";
import { Button } from "@/components/ui/button";
import { formatDate, generateUniqueId } from "./utlis";
import toast from "react-hot-toast";

interface FormData {
  amount: string;
  date: string;
  dueDate: string;
  status: "Paid" | "Not Paid";
  type: "Credit" | "Debit";
  description: string;
}

const AddLedgerEntry: React.FC = () => {
  const { userId } = useParams<{ userId: string }>();
  // const navigate = useNavigate();
  const [formData, setFormData] = useState<FormData>({
    amount: "",
    date: formatDate(new Date()),
    dueDate: "",
    status: "Paid", // Default status
    type: "Credit", // Default type
    description: "",
  });

  const handleChange = (
    e: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
  ) => {
    const { name, value, type } = e.target as HTMLInputElement;
    setFormData((prev) => ({
      ...prev,
      [name]:
        type === "checkbox" ? (e.target as HTMLInputElement).checked : value,
    }));
  };

  const uniqueId = generateUniqueId();
  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    try {
      const ledgerRef = doc(db, `users/${userId}/ledger`, uniqueId);
      await setDoc(ledgerRef, {
        ...formData,
        dueDate: formData.dueDate,
        createdAt: serverTimestamp(),
      });
      toast.success("Ledger entry added successfully!");
    } catch (error) {
      console.error("Error writing document: ", error);
      toast.error("Failed to add ledger entry.");
    }
  };

  return (
    <form
      className="flex flex-col space-y-4 text-blue-600"
      onSubmit={handleSubmit}
    >
      <label htmlFor="amount">Amount</label>
      <input
        id="amount"
        type="number"
        name="amount"
        placeholder="Amount"
        value={formData.amount}
        onChange={handleChange}
        className="p-2 border border-gray-300 rounded"
        required
      />

      <label htmlFor="dueDate">Due Date</label>
      <input
        id="dueDate"
        type="date"
        name="dueDate"
        value={formData.dueDate}
        onChange={handleChange}
        className="p-2 border border-gray-300 rounded"
        required
      />

      <label htmlFor="status">Status</label>
      <select
        id="status"
        name="status"
        value={formData.status}
        onChange={handleChange}
        className="p-2 border border-gray-300 rounded"
      >
        <option value="Paid">Paid</option>
        <option value="Not Paid">Not Paid</option>
      </select>

      <label htmlFor="type">Type</label>
      <select
        id="type"
        name="type"
        value={formData.type}
        onChange={handleChange}
        className="p-2 border border-gray-300 rounded"
      >
        <option value="Credit">Credit</option>
        <option value="Debit">Debit</option>
      </select>

      <label htmlFor="description">Description</label>
      <textarea
        id="description"
        name="description"
        placeholder="Description"
        value={formData.description}
        onChange={handleChange}
        className="p-2 border border-gray-300 rounded"
        required
      />

      <Button type="submit" className="bg-indigo-600  text-white">
        Add Ledger Entry
      </Button>
    </form>
  );
};

export default AddLedgerEntry;
