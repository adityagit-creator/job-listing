import React from "react";
import { Card } from "../ui/card";
import { useNavigate } from "react-router-dom";
import { Button } from "../ui/button";
import { ChevronLeft } from "lucide-react";

interface FinanceSummaryProps {
  credit: number;
  debit: number;
  totalDue: number;
}

const FinanceSummaryCard: React.FC<FinanceSummaryProps> = ({
  credit,
  debit,
  totalDue,
}) => {
  // Ensure values are numbers before calling toFixed
  const formattedCredit =
    typeof credit === "number" ? credit.toFixed(2) : "0.00";
  const formattedDebit = typeof debit === "number" ? debit.toFixed(2) : "0.00";
  const formattedTotalDue =
    typeof totalDue === "number" ? totalDue.toFixed(2) : "0.00";

  return (
    <Card className="none">
      <div className="p-1">
        <div className="grid grid-cols-3 divide-x divide-gray-200">
          <div className="px-4 py-3 flex justify-between items-center">
            <span className="text-gray-500">Credit:</span>
            <span className="font-semibold text-blue-500">
              + ₹{formattedCredit}
            </span>
          </div>
          <div className="px-4 py-3 flex justify-between items-center">
            <span className="text-gray-500">Debit:</span>
            <span className="font-semibold text-red-500">
              - ₹{formattedDebit}
            </span>
          </div>
          <div className="px-4 py-3 flex justify-between items-center">
            <span className="text-gray-500">Balance:</span>
            <span
              className={`font-semibold ${
                totalDue >= 0 ? "text-blue-500" : "text-red-500"
              }`}
            >
              ₹{formattedTotalDue}
            </span>
          </div>
        </div>
      </div>
    </Card>
  );
};

const GoBackButton: React.FC = () => {
  const navigate = useNavigate();

  const goBack = () => {
    navigate(-1); // This will take the user back to the previous page
  };

  return (
    <Button
      onClick={goBack}
      variant="outline"
      size="icon"
      className="h-10 w-10 border-2 border-blue-700 border-dashed"
    >
      <ChevronLeft className="h-8 w-8 text-blue-800" />
      <span className="sr-only">Back</span>
    </Button>
  );
};
export const generateUniqueId = () => {
  return Math.random().toString(36).substring(2, 15);
};

export const formatDate = (date: Date) => {
  const options: Intl.DateTimeFormatOptions = {
    day: "2-digit",
    month: "long",
    year: "numeric",
  };
  return date.toLocaleDateString("en-US", options);
};

export { GoBackButton, FinanceSummaryCard };
