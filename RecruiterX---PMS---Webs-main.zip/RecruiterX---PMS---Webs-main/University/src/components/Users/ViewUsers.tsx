import React, { useEffect, useState } from "react";
import { db } from "@/config/FirebaseConfig";
import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  getDoc,
  updateDoc,
} from "firebase/firestore";
import Layout from "@/Layout/Layout";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../ui/select";
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { useNavigate, useParams } from "react-router-dom";
import { GoBackButton } from "./utlis";
import { Sheet } from "@/components/ui/sheet";

import { Button } from "../ui/button";
import { Trash2, UserCog } from "lucide-react";
import { Label } from "../ui/label";

import { Input } from "../ui/input";

import toast from "react-hot-toast";
import { formatTimestamp } from "../Helpers/formatDate";

interface User {
  collegeName: string; // Name of the college
  createdAt: string; // Timestamp when the account was created
  email: string; // Email address of the user
  isLoggedIn: boolean; // Indicates if the user is currently logged in
  isVerified: boolean; // Indicates if the account is verified
  lastLogin: string; // Timestamp of the last login
  name: string; // User's name
  phoneNumber: string; // User's phone number
  subscription: {
    currentDate: string; // Current subscription date
    expiryDate: string; // Subscription expiry date
    price: number; // Subscription price
    promoCode: string;
    razorpay_payment_id: string; // Razorpay payment ID for the subscription
  };
  token: string; // Authentication token
  yearOfStudy: string; // Curren
}

const ViewUser: React.FC = () => {
  const { userId } = useParams<{ userId: string }>();
  const [user, setUser] = useState<User | null>(null);

  const navigate = useNavigate();
  const [isLoggedIn, setIsLoggedIn] = useState<string>("false");
  const [isVerified, setIsVerified] = useState<string>("false");

  useEffect(() => {
    if (!userId) {
      console.error("No userId provided");
      return;
    }
    const fetchUser = async () => {
      try {
        const userRef = doc(db, "users", userId);
        const userSnap = await getDoc(userRef);
        if (userSnap.exists()) {
          const userData = userSnap.data() as User;
          setUser(userData);
          setIsLoggedIn(userData.isLoggedIn.toString());
          setIsVerified(userData.isVerified.toString());
        } else {
          console.error("User not found");
        }
      } catch (error) {
        console.error("Error fetching user data:", error);
      }
    };
    fetchUser();
  }, [userId]);

  const handleUpdateStatus = async () => {
    if (!userId || !user) return;

    try {
      const userRef = doc(db, "users", userId);
      await updateDoc(userRef, {
        isLoggedIn: isLoggedIn === "true",
        isVerified: isVerified === "true",
      });
      setUser(
        (prev) =>
          prev && {
            ...prev,
            isLoggedIn: isLoggedIn === "true",
            isVerified: isVerified === "true",
          }
      );
      toast.success("User status updated successfully!");
    } catch (error) {
      console.error("Error updating user status:", error);
      alert("Failed to update user status.");
    }
  };

  const handleDeleteUser = async () => {
    if (!userId) {
      console.error("User ID is not available.");
      toast.error("Unable to delete: User ID is not provided.");
      return;
    }

    const userRef = doc(db, "users", userId);
    try {
      await deleteDoc(userRef);
      toast.success("User deleted successfully.");
      navigate("/Students"); // Navigates after deletion
    } catch (error) {
      console.error("Error deleting user:", error);
      toast.error("Failed to delete user. Please try again.");
    }
  };

  const [specialMessage, setSpecialMessage] = useState<string>("");

  const handleSendSpecializedMessage = async () => {
    if (!userId || !specialMessage) {
      console.error("User ID or message is not provided.");
      toast.error("User ID and message are required.");
      return;
    }

    const userRef = doc(db, "users", userId);
    try {
      // Update user's collection with the specialized message
      await updateDoc(userRef, { specializedMessage: specialMessage });

      // Retrieve user's token from the user object
      const userDoc = await getDoc(userRef);
      const user = userDoc.data();
      const userToken = user?.token; // Assuming token is stored in user's collection

      // Store user token and message in Firebase collection for push notifications
      const pushNotificationRef = collection(db, "Notifications");
      await addDoc(pushNotificationRef, {
        userId: userId,
        token: userToken,
        message: specialMessage,
        phone: user?.phonenumber,
      });

      toast.success("Specialized message sent successfully!");
    } catch (error) {
      console.error("Error sending specialized message:", error);
      toast.error("Failed to send specialized message. Please try again.");
    }
  };

  return (
    <Layout>
      <div className="flex items-center gap-4">
        <GoBackButton />
        <h1 className="flex-1 shrink-0 whitespace-nowrap text-xl font-semibold tracking-tight sm:grow-0">
          User
        </h1>
        <div></div>
        {/* <div className="hidden items-center gap-2 md:ml-auto md:flex">
          <Button size="sm">Save User</Button>
        </div> */}
      </div>
      <Sheet>
        <Card className=" mx-auto bg-white none rounded-lg overflow-hidden w-full">
          <CardHeader className=" text-gray-700 p-4">
            <CardTitle className="text-xl font-semibold">
              User Details
            </CardTitle>
          </CardHeader>
          {user ? (
            <CardContent>
              <div className="grid gap-6 m-2 w-full">
                <div className="grid sm:grid-cols-4 grid-cols-1 gap-3">
                  <div className="flex flex-col gap-1">
                    <Label htmlFor="name">Name</Label>
                    <span className="py-2 rounded-lg px-2 border border-gray-300">
                      {user?.name}
                    </span>
                  </div>

                  <div className="flex flex-col gap-1">
                    <Label htmlFor="mobile">Mobile</Label>
                    <span className="py-2 rounded-lg px-2 border border-gray-300">
                      {user?.phoneNumber}
                    </span>
                  </div>
                  <div className="flex flex-col gap-1">
                    <Label htmlFor="district">E-Mail</Label>
                    <span className="py-2 rounded-lg px-2 border border-gray-300">
                      {user?.email}
                    </span>
                  </div>
                  <div className="flex flex-col gap-1">
                    <Label htmlFor="verified">Verified</Label>
                    <span className="py-2 rounded-lg px-2 border border-gray-300">
                      {user?.isVerified ? "Yes" : "No"}
                    </span>
                  </div>
                  <div className="flex flex-col gap-1">
                    <Label htmlFor="Address">User Status </Label>
                    <span className="py-2 rounded-lg px-2 border border-gray-300">
                      {user?.isLoggedIn ? "Active" : "Not Active"}
                    </span>
                  </div>
                  <div className="flex flex-col gap-1">
                    <Label htmlFor="Address">Registered On</Label>
                    <span className="py-2 rounded-lg px-2 border border-gray-300">
                      {user?.createdAt
                        ? formatTimestamp(user.createdAt)
                        : "N/A"}
                    </span>
                  </div>
                  <div className="flex flex-col gap-1">
                    <Label htmlFor="Address">Login In</Label>
                    <span className="py-2 rounded-lg px-2 border border-gray-300">
                      {user?.lastLogin
                        ? formatTimestamp(user.lastLogin)
                        : "N/A"}
                    </span>
                  </div>
                </div>
              </div>
            </CardContent>
          ) : (
            <p className="m-4">Loading user details...</p>
          )}
        </Card>

        <div className="grid sm:grid-cols-2 grid-cols-1 gap-3">
          {user?.subscription && (
            <Card className="none">
              <CardHeader>
                <CardTitle>Subscription Details</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex flex-col gap-1">
                    <Label htmlFor="verified">Subscribed On</Label>
                    <span className="py-2 rounded-lg px-2 border border-gray-300">
                      {user?.subscription?.currentDate
                        ? formatTimestamp(user.subscription.currentDate)
                        : "N/A"}{" "}
                    </span>
                  </div>
                  <div className="flex flex-col gap-1">
                    <Label htmlFor="verified">Price:</Label>
                    <span className="py-2 rounded-lg px-2 border border-gray-300">
                      ₹{user.subscription.price}
                    </span>
                  </div>
                  <div className="flex flex-col gap-1">
                    <Label htmlFor="verified">Expiry</Label>
                    <span className="py-2 rounded-lg px-2 border border-gray-300">
                      {user?.subscription?.expiryDate
                        ? formatTimestamp(user.subscription.expiryDate)
                        : "N/A"}
                    </span>
                  </div>
                  <div className="flex flex-col gap-1 w-full">
                    <Label htmlFor="verified">Coupoun Used:</Label>
                    <span className="py-2 rounded-lg px-2 border border-gray-300 w-full">
                      .{user.subscription.promoCode}
                    </span>
                  </div>

                  <div className="flex flex-col gap-1">
                    <Label htmlFor="verified">Payment Id</Label>
                    <span className="py-2 rounded-lg px-2 border border-gray-300">
                      {user.subscription.razorpay_payment_id}
                    </span>
                  </div>

                  {/* <div>
                  <Label>Expiry Date:</Label>
                  <p></p>
                </div> */}
                </div>
              </CardContent>
            </Card>
          )}
          <Card className="  mx-auto bg-white none rounded-lg overflow-hidden w-full">
            <CardHeader className=" text-gray-700 p-4">
              <CardTitle className="text-xl font-semibold">
                <div className="flex flex-row items-center justify-between gap-2">
                  <span className="text-xl font-semibold">
                    User Verification
                  </span>
                  <UserCog className="" />
                </div>
              </CardTitle>
            </CardHeader>
            <div></div>
            <CardContent className="p-4">
              {user ? (
                <div>
                  <div className="flex flex-col justify-center">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="flex flex-col gap-2">
                        <Label>Is Logged In</Label>
                        <Select
                          value={isLoggedIn}
                          onValueChange={setIsLoggedIn}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select Status" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="true">True</SelectItem>
                            <SelectItem value="false">False</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="flex flex-col gap-2">
                        <Label>Is Verified</Label>
                        <Select
                          value={isVerified}
                          onValueChange={setIsVerified}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select Status" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="true">True</SelectItem>
                            <SelectItem value="false">False</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <Button
                      onClick={handleUpdateStatus}
                      className="mt-5 w-full bg-indigo-500 hover:bg-indigo-600 text-white"
                    >
                      Update Status
                    </Button>
                    <Button
                      onClick={handleDeleteUser}
                      className="mt-5 bg-red-800 hover:bg-red-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 w-full"
                    >
                      <Trash2 className="w-5 h-5" />
                      Delete Account
                    </Button>
                  </div>
                </div>
              ) : (
                <div>Loading...</div>
              )}
            </CardContent>
          </Card>{" "}
          <Card className="none">
            <CardHeader>
              <CardTitle>Send Specialized Message</CardTitle>
            </CardHeader>
            <CardContent>
              <form>
                <div className="space-y-2">
                  <Label htmlFor="specialMessage">Special Message</Label>
                  <Input
                    id="specialMessage"
                    type="text"
                    value={specialMessage}
                    onChange={(e) => setSpecialMessage(e.target.value)}
                    placeholder="Enter the specialized message"
                  />
                </div>
              </form>
            </CardContent>
            <CardFooter>
              <Button onClick={handleSendSpecializedMessage}>
                Send Message
              </Button>
            </CardFooter>
          </Card>
        </div>
      </Sheet>
    </Layout>
  );
};

export default ViewUser;
