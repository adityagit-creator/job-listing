import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis } from "recharts";

interface DataPoint {
  name: string;
  total: number;
}

interface OverviewProps {
  data: DataPoint[];
}

export function Overview({ data }: OverviewProps) {
  return (
    <ResponsiveContainer width="100%" height={350}>
      <BarChart data={data}>
        <XAxis
          dataKey="month"
          stroke="#888888"
          fontSize={12}
          tickLine={false}
          axisLine={false}
        />
        <YAxis
          stroke="#888888"
          fontSize={12}
          tickLine={false}
          axisLine={false}
          tickFormatter={(value) => `₹${value}`}
        />
        <Bar
          dataKey="total"
          radius={[4, 4, 0, 0]}
          fill="black" // You can customize the color based on your requirement
        />
      </BarChart>
    </ResponsiveContainer>
  );
}
