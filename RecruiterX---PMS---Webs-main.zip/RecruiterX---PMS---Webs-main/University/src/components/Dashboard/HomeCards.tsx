import React from "react";
import {
  FaUserCheck,
  FaUsers,
  FaCalendarAlt,
  FaDollarSign,
  FaClipboardList,
  FaBook,

  FaCogs,
  FaBolt,
} from "react-icons/fa";
import { IconType } from "react-icons";
import { Card } from "../ui/card";

// Define the interface for the cards
interface CardProps {
  title: string;
  icon: IconType;
}

// Create the Card component to display each individual card
const Cards: React.FC<CardProps> = ({ title, icon: Icon }) => {
  return (
    <div className="p-4 bg-white rounded-lg border transition cursor-pointer hover:bg-slate-50 sm">
      <div className="flex items-center flex-col gap-4">
        <Icon className="w-10 h-10 text-primary" />
        <h3 className="text-lg font-semibold">{title}</h3>
      </div>
    </div>
  );
};

// Define the props for the HomeCards component to accept role
// interface HomeCardsProps {
//   role: "Teacher" | "Management"; // Define the two roles
// }

// Create the HomeCards component which will show cards based on the user's role
const HomeCards: React.FC = () => {
  // Data for Teacher cards
  const teacherCards: CardProps[] = [
    { title: "Manage Grades", icon: FaClipboardList },
    { title: "Attendance", icon: FaUserCheck },
    { title: "Settings", icon: FaCogs },

    { title: "Assignments", icon: FaBook },
    { title: "Exams", icon: FaBolt },

  ];

  // Data for Management cards
  const managementCards: CardProps[] = [
    { title: "Admissions", icon: FaUsers },
    { title: "Fee Management", icon: FaDollarSign },
    { title: "Events", icon: FaCalendarAlt },
    { title: "Users", icon: FaUsers },
    { title: "Settings", icon: FaCogs },
  ];

  // Determine which set of cards to display based on the role
  //   const cardsToDisplay = role === "Teacher" ? teacherCards : managementCards;

  return (
    <div className="flex flex-col gap-5">
    <Card className="p-6">
      <h1 className="text-2xl font-bold mb-4">Teachers</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6">
        {teacherCards.map((card, index) => (
        <Cards key={index} title={card.title} icon={card.icon} />
        ))}
      </div>
    </Card>
    <Card className="p-6">
      <h1 className="text-2xl font-bold mb-4">Management</h1>
        <div className=" grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6">
          {managementCards.map((card, index) => (
            <Cards key={index} title={card.title} icon={card.icon} />
          ))}
        </div>
      </Card>
    </div>
  );
};

export default HomeCards;
