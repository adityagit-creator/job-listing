import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { FaUsers, FaCheckCircle, FaClock, FaChartLine } from 'react-icons/fa';
import CardLoading from './Helpers/card-loading';


interface JobStats {
  totalApplications: number;
  shortlisted: number;
  pending: number;
  conversionRate: number;
  jobId: string;
  jobTitle: string;
  companyName: string;
  postedDate: Date;
  deadline: Date;
  views: number;
}

interface JobTrackingStatsProps {
  stats: JobStats;
  loading?: boolean;
}

const JobTrackingStats: React.FC<JobTrackingStatsProps> = ({ stats, loading = false }) => {
  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <CardLoading />
        <CardLoading />
        <CardLoading />
        <CardLoading />
      </div>
    );
  }

  return (
    <Card className="p-6">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold">{stats.jobTitle}</h2>
            <p className="text-sm text-gray-600">{stats.companyName}</p>
          </div>
          <div className="text-sm text-gray-600">
            Posted: {stats.postedDate.toLocaleDateString()}
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-blue-50 p-4 rounded-lg">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-blue-600">Total Applications</p>
                <h3 className="text-2xl font-bold text-blue-700">
                  {stats.totalApplications}
                </h3>
              </div>
              <FaUsers className="h-8 w-8 text-blue-500 opacity-20" />
            </div>
            <p className="text-xs text-blue-600 mt-2">
              {stats.views} profile views
            </p>
          </div>

          <div className="bg-green-50 p-4 rounded-lg">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-green-600">Shortlisted</p>
                <h3 className="text-2xl font-bold text-green-700">
                  {stats.shortlisted}
                </h3>
              </div>
              <FaCheckCircle className="h-8 w-8 text-green-500 opacity-20" />
            </div>
            <p className="text-xs text-green-600 mt-2">
              {((stats.shortlisted / stats.totalApplications) * 100).toFixed(1)}% success rate
            </p>
          </div>

          <div className="bg-yellow-50 p-4 rounded-lg">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-yellow-600">Pending Review</p>
                <h3 className="text-2xl font-bold text-yellow-700">
                  {stats.pending}
                </h3>
              </div>
              <FaClock className="h-8 w-8 text-yellow-500 opacity-20" />
            </div>
            <p className="text-xs text-yellow-600 mt-2">
              {((stats.pending / stats.totalApplications) * 100).toFixed(1)}% awaiting review
            </p>
          </div>

          <div className="bg-purple-50 p-4 rounded-lg">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-purple-600">Conversion Rate</p>
                <h3 className="text-2xl font-bold text-purple-700">
                  {stats.conversionRate}%
                </h3>
              </div>
              <FaChartLine className="h-8 w-8 text-purple-500 opacity-20" />
            </div>
            <p className="text-xs text-purple-600 mt-2">
              {stats.deadline > new Date() ? 'Active' : 'Closed'}
            </p>
          </div>
        </div>

        <div className="mt-6">
          <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
            <div
              className="h-full bg-blue-500"
              style={{
                width: `${(stats.shortlisted / stats.totalApplications) * 100}%`,
              }}
            />
          </div>
          <div className="flex justify-between mt-2 text-sm text-gray-600">
            <span>Application Progress</span>
            <span>
              {((stats.shortlisted / stats.totalApplications) * 100).toFixed(1)}%
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default JobTrackingStats; 