import React, { useState, useEffect } from "react";
import { db } from "../../config/FirebaseConfig";
import {
  collection,
  getDocs,
  updateDoc,
  doc,
  query,
  orderBy,
} from "firebase/firestore";
import toast from "react-hot-toast";
import { Card } from "../ui/card";
import { Button } from "../ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

interface Feedback {
  email: string;
  message: string;
  name: string;
  subject: string;
  status: string;
  id: string;
}

const FeedbackListPage: React.FC = () => {
  const [feedbacks, setFeedbacks] = useState<Feedback[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [selectedMessage, setSelectedMessage] = useState<string | null>(null);

  // Fetch feedback from Firestore
  useEffect(() => {
    const fetchFeedback = async () => {
      setLoading(true);
      try {
        const feedbackCollectionRef = collection(db, "feedbacks");

        // Query with orderBy to sort feedback by statusValue (ascending order)
        const feedbackQuery = query(
          feedbackCollectionRef,
          orderBy("status", "asc")
        );
        const feedbackSnapshot = await getDocs(feedbackQuery);

        const feedbackList = feedbackSnapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        })) as Feedback[];

        setFeedbacks(feedbackList);
      } catch (error) {
        toast.error("Error fetching feedbacks.");
      } finally {
        setLoading(false);
      }
    };

    fetchFeedback();
  }, []);

  // Update the status of feedback
  const updateStatus = async (feedbackId: string, newStatus: string) => {
    try {
      const feedbackDocRef = doc(db, "feedbacks", feedbackId);
      await updateDoc(feedbackDocRef, { status: newStatus });
      toast.success("Status updated successfully.");
      setFeedbacks((prevFeedbacks) =>
        prevFeedbacks.map((feedback) =>
          feedback.id === feedbackId
            ? { ...feedback, status: newStatus }
            : feedback
        )
      );
    } catch (error) {
      toast.error("Error updating status.");
    }
  };

  return (
    <div className="">
      <h1 className="text-2xl font-bold mb-6">Feedbacks</h1>

      {loading ? (
        <p>Loading...</p>
      ) : (
        <Card className="p-5">
          {selectedMessage && (
            <div className="mt-4 p-4 border rounded bg-gray-50">
              <h2 className="text-lg font-semibold">Message</h2>
              <p className="mt-2 text-gray-700">{selectedMessage}</p>
            </div>
          )}
          <Table>
            <TableHeader>
              <TableRow>
                <TableCell>Name</TableCell>
                <TableCell>Email</TableCell>
                <TableCell>Subject</TableCell>
                <TableCell>Status</TableCell>
                <TableCell>Actions</TableCell>
                <TableCell>Send Email</TableCell>{" "}
                {/* New column for sending emails */}
              </TableRow>
            </TableHeader>
            <TableBody>
              {feedbacks.map((feedback) => (
                <TableRow
                  key={feedback.id}
                  className="cursor-pointer hover:bg-gray-100"
                  onClick={() => setSelectedMessage(feedback.message)}
                >
                  <TableCell>{feedback.name}</TableCell>
                  <TableCell>
                    <a
                      href={`mailto:${feedback.email}`}
                      className="text-blue-500 hover:underline"
                    >
                      {feedback.email}
                    </a>
                  </TableCell>
                  <TableCell>{feedback.subject}</TableCell>
                  <TableCell>
                    <span
                      className={`px-3 py-1 rounded-full text-white ${
                        feedback.status === "Resolved"
                          ? "bg-green-500"
                          : "bg-red-500"
                      }`}
                    >
                      {feedback.status}
                    </span>
                  </TableCell>
                  <TableCell>
                    <Button
                      variant="outline"
                      onClick={(e) => {
                        e.stopPropagation(); // Prevent row click event
                        updateStatus(
                          feedback.id,
                          feedback.status === "Resolved"
                            ? "Pending"
                            : "Resolved"
                        );
                      }}
                    >
                      {feedback.status === "Resolved"
                        ? "Mark as Pending"
                        : "Mark as Resolved"}
                    </Button>
                  </TableCell>
                  <TableCell>
                    {/* New mailto link that specifically opens Gmail's compose interface */}
                    <a
                      href={`https://mail.google.com/mail/?view=cm&fs=1&to=${feedback.email}&su=Re:${feedback.subject}`}
                      className="text-blue-500 hover:underline"
                      target="_blank" // Opens Gmail in a new tab
                      rel="noopener noreferrer"
                    >
                      Send Email
                    </a>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>

          {/* Show the selected message */}
        </Card>
      )}
    </div>
  );
};

export default FeedbackListPage;
