import React, { useState, ChangeEvent, FormEvent } from "react";
import { db } from "@/config/FirebaseConfig";
import { collection, addDoc } from "firebase/firestore";
import { getStorage, ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { CornerDownLeft, Paperclip } from "lucide-react";
import Layout from "@/Layout/Layout";

interface FormData {
  role: string;
  title: string;
  message: string;
  imageUrl: string | null; // Store the image URL here
}

const PushNotification: React.FC = () => {
  const [formData, setFormData] = useState<FormData>({
    role: "",
    title: "",
    message: "",
    imageUrl: null, // Initialize with null
  });
  const [imageFile, setImageFile] = useState<File | null>(null); // Store the image file

  const handleChange = (
    e: ChangeEvent<HTMLSelectElement | HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleImageChange = (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setImageFile(e.target.files[0]);
    }
  };

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    try {
      let imageUrl: string | null = null;

      // Upload image to Firebase Storage
      if (imageFile) {
        const storage = getStorage();
        const storageRef = ref(storage, `notifications/${imageFile.name}`);

        // Upload the file
        await uploadBytes(storageRef, imageFile);
        // Get the download URL
        imageUrl = await getDownloadURL(storageRef);
      }

      // Add notification data to Firestore
      const docRef = await addDoc(collection(db, "notifications"), {
        ...formData,
        imageUrl, // Include the image URL in the notification data
      });
      console.log("Notification added with ID: ", docRef.id);

      // Reset the form
      setFormData({
        role: "",
        title: "",
        message: "",
        imageUrl: null,
      });
      setImageFile(null); // Reset the image file state
      alert("Notification sent successfully!");
    } catch (error) {
      console.error("Error adding notification: ", error);
      alert("Failed to send notification. Please try again.");
    }
  };

  return (
    <Layout>
    <div className="flex-1" />
    <fieldset className="grid gap-6 rounded-lg border p-4 my-3">
      <legend className="-ml-1 px-1 text-sm font-medium">Messages</legend>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <Label htmlFor="role">Role</Label>
          <select
            value={formData.role}
            onChange={handleChange}
            name="role"
            className="mt-1 block w-full bg-gray-200 rounded p-2"
          >
            <option value="" disabled>
              Select a role
            </option>
            <option value="users">Users</option>
            <option value="providers">Providers</option>
          </select>
        </div>
        <Label htmlFor="image" className="sr-only">
          Image
        </Label>
        <Input
          id="image"
          type="file"
          accept="image/*"
          onChange={handleImageChange}
          className="mt-1 block w-full"
        />

      </div>
      <div className="grid gap-3">
        <Label htmlFor="content">Title</Label>
        <Input
          id="title"
          type="text"
          name="title"
          value={formData.title}
          onChange={handleChange}
          required
          placeholder="Title"
        />
      </div>
    </fieldset>
    <form
      onSubmit={handleSubmit}
      className="relative overflow-hidden rounded-lg border bg-background focus-within:ring-1 focus-within:ring-ring"
      x-chunk="dashboard-03-chunk-1"
    >
      <Label htmlFor="message" className="sr-only">
        Message
      </Label>
      <Textarea
        id="message"
        placeholder="Type your message here..."
        className="min-h-12 resize-none border-0 p-3 none focus-visible:ring-0"
        name="message"
        value={formData.message}
        onChange={handleChange}
      />
      <div className="flex items-center p-3 pt-0">
        
        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              className="bg-gray-100 border border-gray-200 "
            >
              <Paperclip className="size-4" />
              <span className="sr-only">Attach file</span>
            </Button>
          </TooltipTrigger>
          <TooltipContent side="top">Attach File</TooltipContent>
        </Tooltip>

        <Button
          type="submit"
          size="sm"
          className="ml-auto gap-1.5 bg-accent_color"
        >
          Send Message
          <CornerDownLeft className="size-3.5" />
        </Button>
      </div>
    </form>
  </Layout>
  );
};

export default PushNotification;
