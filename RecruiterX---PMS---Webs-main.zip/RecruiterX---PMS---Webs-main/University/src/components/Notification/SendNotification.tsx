import React, { useState, ChangeEvent, FormEvent } from "react";

import { db } from "@/config/FirebaseConfig";
import { addDoc, collection } from "firebase/firestore";
import { Label } from "../ui/label";
import { Input } from "../ui/input";
import { Button } from "../ui/button";

import { Textarea } from "../ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import toast from "react-hot-toast";
import { Tooltip, TooltipContent, TooltipTrigger } from "../ui/tooltip";
import { CornerDownLeft, Paperclip } from "lucide-react";
import Layout from "@/Layout/Layout";
const PushNotificationForm: React.FC = () => {
  const [formData, setFormData] = useState({
    title: "",
    message: "",
  });

  const handleChange = (
    e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = async (e: FormEvent<HTMLButtonElement>) => {
    e.preventDefault();
    try {
      // Add the notification data to the Firestore collection
      await addDoc(collection(db, "notifications"), formData);
      toast.success("Notification added successfully!");
      // Clear the form fields after submission
      setFormData({
        title: "",
        message: "",
      });
    } catch (error) {
      console.error("Error adding notification:", error);
      alert("Failed to add notification. Please try again.");
    }
  };

  return (

    <Layout>
    <Card className="none">
      <CardHeader>
        <CardTitle>Push Notification</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="my-3">
          <Label htmlFor="title" className="sr-only">
            Title
          </Label>
          <Input
            id="title"
            type="text"
            name="title"
            value={formData.title}
            onChange={handleChange}
            required
            placeholder="Enter title"
          />
        </div>
        <Label htmlFor="message" className="sr-only">
          Message
        </Label>
        <Textarea
          id="message"
          name="message"
          value={formData.message}
          onChange={handleChange}
          required
          placeholder="Enter message"
        />
        <div className="flex items-center p-3 pt-0 mt-4">
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="bg-gray-100 border border-gray-200"
              >
                <Paperclip className="size-4" />
                <span className="sr-only">Attach file</span>
              </Button>
            </TooltipTrigger>
            <TooltipContent side="top">Attach File</TooltipContent>
          </Tooltip>

          <Button
            onClick={handleSubmit}
            size="sm"
            className="ml-auto gap-1.5 bg-accent_color"
          >
            Send Message
            <CornerDownLeft className="size-3.5" />
          </Button>
        </div>
      </CardContent>
    </Card>
    </Layout>
  );
};

export default PushNotificationForm;
