import { useState } from "react";
import { Button } from "./ui/button";
import Viewer from "react-viewer";
const ImageViewer = ({
  imageName,
  imageUrl,
  className = "",
}: {
  imageName: string;
  imageUrl: string;
  className: string;
}) => {
  const [visible, setVisible] = useState<boolean>(false);
  return (
    <>
      {!visible ? (
        <Button className={className} onClick={() => setVisible(true)}>
          {imageName}
        </Button>
      ) : (
        <Viewer
          visible={visible}
          onClose={() => {
            setVisible(false);
          }}
          images={[{ src: `${imageUrl}`, alt: `${imageName}` }]}
        />
      )}
    </>
  );
};

export default ImageViewer;
