import React from 'react';
import { Card, CardContent } from '../ui/card';


interface CardLoadingProps {
  className?: string;
  numberOfLines?: number;
}

const CardLoading: React.FC<CardLoadingProps> = ({ 
  className = '', 
  numberOfLines = 3 
}) => {
  return (
    <Card className={`${className} overflow-hidden`}>
      <CardContent className="p-6">
        <div className="animate-pulse space-y-4">
          {/* Header skeleton */}
          <div className="h-4 bg-gray-200 rounded-md w-3/4"></div>
          
          {/* Content skeleton */}
          {Array.from({ length: numberOfLines }).map((_, index) => (
            <div 
              key={index} 
              className="h-3 bg-gray-200 rounded-md" 
              style={{ width: `${Math.random() * 30 + 70}%` }}
            ></div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default CardLoading;