import { Timestamp } from "firebase/firestore";

// Function to format Firestore Timestamp
export const formatTimestamp = (timestamp: Timestamp | string) => {
  // If it's a Firestore Timestamp, convert it to a Date object
  const date = timestamp instanceof Timestamp ? timestamp.toDate() : new Date(timestamp);

  // Check if the date is valid
  if (isNaN(date.getTime())) return "Invalid date";

  // Format the date in "dd MMMM yyyy" format using toLocaleDateString
  const formattedDate = date.toLocaleDateString("en-GB", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });

  return formattedDate;
};
