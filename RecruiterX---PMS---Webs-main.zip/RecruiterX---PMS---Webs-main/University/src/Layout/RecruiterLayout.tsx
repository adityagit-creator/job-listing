import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { FaBriefcase, FaBuilding, FaUsers, FaCalendar, FaChartBar } from 'react-icons/fa';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Menu, CircleUser } from 'lucide-react';
import { Toaster } from 'react-hot-toast';

interface LayoutProps {
  children: React.ReactNode;
}

interface NavItem {
  path: string;
  label: string;
  icon: React.ReactNode;
}

const navigationItems: NavItem[] = [
  { path: '/', label: 'Dashboard', icon: <FaChartBar className="h-4 w-4" /> },
  { path: '/registration', label: 'Company Profile', icon: <FaBuilding className="h-4 w-4" /> },
  { path: '/job-posting', label: 'Post Jobs', icon: <FaBriefcase className="h-4 w-4" /> },
  { path: '/candidates', label: 'Candidates', icon: <FaUsers className="h-4 w-4" /> },
  { path: '/interviews', label: 'Interviews', icon: <FaCalendar className="h-4 w-4" /> },
];

const RecruiterLayout: React.FC<LayoutProps> = ({ children }) => {
  const { pathname } = useLocation();
  const navigate = useNavigate();

  const linkClass = (path: string) =>
    `flex items-center gap-3 rounded-lg px-3 py-2 transition-all ${
      pathname === path
        ? 'bg-indigo-600 text-white'
        : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
    }`;

  return (
    <div className="grid min-h-screen w-full md:grid-cols-[240px_1fr]">
      {/* Sidebar */}
      <div className="hidden border-r bg-gray-50/40 md:block">
        <div className="flex h-full max-h-screen flex-col gap-2">
          <div className="flex h-14 items-center border-b px-4 lg:h-[60px]">
            <Link to="/" className="flex items-center gap-2 font-semibold">
              <FaBuilding className="h-6 w-6 text-indigo-600" />
              <span>Recruiter Portal</span>
            </Link>
          </div>
          <div className="flex-1 overflow-auto py-2">
            <nav className="grid items-start px-4 text-sm font-medium">
              {navigationItems.map((item) => (
                <Link key={item.path} to={item.path} className={linkClass(item.path)}>
                  {item.icon}
                  {item.label}
                </Link>
              ))}
            </nav>
          </div>
          <div className="mt-auto p-4">
            <Card>
              <CardHeader className="p-2">
                <CardTitle className="text-sm">Need Help?</CardTitle>
              </CardHeader>
              <CardContent className="p-2">
                <Button
                  size="sm"
                  variant="outline"
                  className="w-full"
                  onClick={() => navigate('/support')}
                >
                  Contact Support
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex flex-col">
        <header className="flex h-14 items-center gap-4 border-b bg-gray-50/40 px-6 lg:h-[60px]">
          <Sheet>
            <SheetTrigger asChild>
              <Button
                variant="outline"
                size="icon"
                className="shrink-0 md:hidden"
              >
                <Menu className="h-5 w-5" />
                <span className="sr-only">Toggle navigation menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-[240px] sm:w-[240px]">
              <nav className="grid gap-2 text-lg font-medium">
                {navigationItems.map((item) => (
                  <Link key={item.path} to={item.path} className={linkClass(item.path)}>
                    {item.icon}
                    {item.label}
                  </Link>
                ))}
              </nav>
            </SheetContent>
          </Sheet>
          <div className="flex-1" />
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="rounded-full">
                <CircleUser className="h-6 w-6" />
                <span className="sr-only">Toggle user menu</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>My Account</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => navigate('/profile')}>
                Profile Settings
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => navigate('/company')}>
                Company Settings
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </header>
        <main className="flex-1 overflow-auto bg-gray-50/40">
          <div className="container mx-auto p-6">
            {children}
          </div>
        </main>
      </div>
      <Toaster position="top-right" />
    </div>
  );
};

export default RecruiterLayout; 