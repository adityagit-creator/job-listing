/* eslint-disable @typescript-eslint/no-unused-vars */
import {
  BoltIcon,
  BookAIcon,
  BookCheck,
  CircleUser,
  Home,
  Menu,
  Settings,
  Users,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  FaUserCheck,
  FaBook,
  FaCalendar,
  FaClipboardList,
  FaUsers,
  FaDollarSign,
  FaGraduationCap,
  FaBriefcase,
  FaChartBar,
  FaBell,
} from "react-icons/fa";

import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Link, useLocation, useNavigate } from "react-router-dom";
import imageSrc from "../assets/logo.png";

import { Toaster } from "react-hot-toast";
import { useAuth } from "@/config/AuthContext";

interface LayoutProps {
  children: React.ReactNode;
}

interface NavItem {
  path: string;
  label: string;
  icon: React.ReactNode;
}

interface NavSection {
  title?: string;
  items: NavItem[];
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const { logOut } = useAuth();

  const handleLogOut = async () => {
    await logOut();
    navigate("/");
  };

  const navigationSections: NavSection[] = [
    {
      items: [
        { path: "/Home", label: "Dashboard", icon: <Home className="h-4 w-4" /> },
        { path: "/Students", label: "Users", icon: <Users className="h-4 w-4" /> },
     
      ]
    },

    {
      title: "Training & Placement",
      items: [
       
        { path: "/coordinator/job-management", label: "Job Management", icon: <FaBriefcase className="h-4 w-4" /> },
        { path: "/coordinator/student-management", label: "Student Management", icon: <FaUsers className="h-4 w-4" /> },
        // { path: "/coordinator/assessment-sch eduling", label: "Assessments", icon: <FaClipboardList className="h-4 w-4" /> },
        {
          path: "/coordinator/notification-center",
          label: "Notifications",
          icon: <FaBell className="h-4 w-4" />
        }
      ]
    },
    {
      title: "T&P Officer",
      items: [
      
        { path: "/officer/recruiter-management", label: "Recruiters", icon: <FaBriefcase className="h-4 w-4" /> },
        { path: "/officer/reports-insights", label: "Reports", icon: <FaChartBar className="h-4 w-4" /> },
      ]
    },
    {
      title: "System",
      items: [
        { path: "/Settings", label: "Settings", icon: <Settings className="h-4 w-4" /> },
      ]
    }
  ];

  const linkClass = (path: string) =>
    `flex items-center gap-3 rounded-lg px-2 py-3 transition-all ${
      pathname === path
        ? "bg-indigo-600 text-white"
        : "text-black hover:text-gray-900"
    }`;

  const renderNavSection = (section: NavSection) => (
    <div key={section.title} className="space-y-2">
      {section.title && (
        <>
          <h3 className="px-2 text-sm font-semibold text-gray-500">{section.title}</h3>
          <hr className="my-1 h-px border-0 bg-indigo-500" />
        </>
      )}
      {section.items.map((item) => (
        <Link key={item.path} to={item.path} className={linkClass(item.path)}>
          {item.icon}
          {item.label}
        </Link>
      ))}
    </div>
  );

  return (
    <div className="grid min-h-screen w-full md:grid-cols-[220px_1fr] lg:grid-cols-[220px_1fr]">
      <div className="hidden border-r md:block">
        <div className="w-[220px] fixed flex h-full max-h-screen flex-col items-center">
          <div className="flex gap-3 h-14 items-center border-b px-4 lg:h-[60px] lg:px-6">
            <Link to="/Home" className="flex items-center gap-2 font-semibold">
              <img
                src={imageSrc}
                alt=""
                className="h-14 transition-all group-hover:scale-110"
              />
            </Link>
          </div>
          <div className="flex-1 w-full overflow-y-auto">
            <nav className="grid items-start px-2 gap-y-4 text-sm font-medium lg:px-4 mt-4">
              {navigationSections.map(renderNavSection)}
            </nav>
          </div>
          <div className="mt-auto p-4 flex items-center justify-center w-full">
            <Card>
              <CardHeader className="p-2 pt-0 md:p-4">
                <CardTitle>Push Notification</CardTitle>
              </CardHeader>
              <CardContent className="p-2 pt-0 md:p-4 md:pt-0">
                <Link to="/Notification">
                  <Button size="sm" className="w-full bg-accent_color">
                    Notification
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
      <div className="flex flex-col">
        <header className="flex fixed bg-white w-full h-14 items-center gap-4 border-b bg-muted/40 px-4 lg:h-[60px] lg:px-6">
          <Sheet>
            <SheetTrigger asChild>
              <Button
                variant="outline"
                size="icon"
                className="shrink-0 md:hidden"
              >
                <Menu className="h-5 w-5" />
                <span className="sr-only">Toggle navigation menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="flex flex-col">
              <img src={imageSrc} alt="" className="h-12 mx-16" />
              <nav className="grid gap-2 text-lg font-medium mt-4">
                {navigationSections.map(renderNavSection)}
              </nav>
            </SheetContent>
          </Sheet>
          <div className="w-full flex-1"></div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="secondary" size="icon" className="rounded-full">
                <CircleUser className="h-5 w-5" />
                <span className="sr-only">Toggle user menu</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>My Account</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem>Settings</DropdownMenuItem>
              <DropdownMenuItem>Support</DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={handleLogOut}>Logout</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </header>
        <main className="flex flex-1 flex-col gap-4 p-4 lg:gap-6 lg:p-6 mt-12 overflow-y-auto bg-[#f3f4f6]">
          {children}
        </main>
        <Toaster position="top-center" reverseOrder={false} />
      </div>
    </div>
  );
};

export default Layout;
