import { useState, useEffect } from 'react';
import { toast } from 'react-hot-toast';
import {
  Recruiter,
  getRecruiters,
  getRecruiterById,
  addRecruiter,
  updateRecruiter,
  deleteRecruiter,
  updateRecruiterStatus,
  addHiringHistory,
  getRecruiterStats,
} from '@/services/recruiterService';

export const useRecruiter = () => {
  const [recruiters, setRecruiters] = useState<Recruiter[]>([]);
  const [selectedRecruiter, setSelectedRecruiter] = useState<Recruiter | null>(null);
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchRecruiters = async (filters?: { status?: string; industry?: string }) => {
    try {
      setLoading(true);
      const data = await getRecruiters(filters);
      setRecruiters(data);
      setError(null);
    } catch (err) {
      setError('Failed to fetch recruiters');
      toast.error('Failed to fetch recruiters');
    } finally {
      setLoading(false);
    }
  };

  const fetchRecruiterById = async (id: string) => {
    try {
      setLoading(true);
      const data = await getRecruiterById(id);
      setSelectedRecruiter(data);
      setError(null);
      return data;
    } catch (err) {
      setError('Failed to fetch recruiter details');
      toast.error('Failed to fetch recruiter details');
      return null;
    } finally {
      setLoading(false);
    }
  };

  const createRecruiter = async (recruiterData: Omit<Recruiter, 'id'>) => {
    try {
      setLoading(true);
      const id = await addRecruiter(recruiterData);
      toast.success('Recruiter added successfully');
      await fetchRecruiters();
      return id;
    } catch (err) {
      setError('Failed to add recruiter');
      toast.error('Failed to add recruiter');
      return null;
    } finally {
      setLoading(false);
    }
  };

  const updateRecruiterDetails = async (id: string, data: Partial<Recruiter>) => {
    try {
      setLoading(true);
      await updateRecruiter(id, data);
      toast.success('Recruiter updated successfully');
      await fetchRecruiters();
    } catch (err) {
      setError('Failed to update recruiter');
      toast.error('Failed to update recruiter');
    } finally {
      setLoading(false);
    }
  };

  const removeRecruiter = async (id: string) => {
    try {
      setLoading(true);
      await deleteRecruiter(id);
      toast.success('Recruiter deleted successfully');
      await fetchRecruiters();
    } catch (err) {
      setError('Failed to delete recruiter');
      toast.error('Failed to delete recruiter');
    } finally {
      setLoading(false);
    }
  };

  const toggleRecruiterStatus = async (id: string, status: 'active' | 'inactive') => {
    try {
      setLoading(true);
      await updateRecruiterStatus(id, status);
      toast.success('Recruiter status updated successfully');
      await fetchRecruiters();
    } catch (err) {
      setError('Failed to update recruiter status');
      toast.error('Failed to update recruiter status');
    } finally {
      setLoading(false);
    }
  };

  const addNewHiringHistory = async (
    id: string,
    history: { year: number; studentsHired: number; averagePackage: number }
  ) => {
    try {
      setLoading(true);
      await addHiringHistory(id, history);
      toast.success('Hiring history added successfully');
      await fetchRecruiterById(id);
    } catch (err) {
      setError('Failed to add hiring history');
      toast.error('Failed to add hiring history');
    } finally {
      setLoading(false);
    }
  };

  const fetchStats = async () => {
    try {
      setLoading(true);
      const data = await getRecruiterStats();
      setStats(data);
      setError(null);
    } catch (err) {
      setError('Failed to fetch recruiter statistics');
      toast.error('Failed to fetch recruiter statistics');
    } finally {
      setLoading(false);
    }
  };

  return {
    recruiters,
    selectedRecruiter,
    stats,
    loading,
    error,
    fetchRecruiters,
    fetchRecruiterById,
    createRecruiter,
    updateRecruiterDetails,
    removeRecruiter,
    toggleRecruiterStatus,
    addNewHiringHistory,
    fetchStats,
  };
}; 