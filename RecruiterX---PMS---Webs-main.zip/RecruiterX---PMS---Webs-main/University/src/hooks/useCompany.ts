import { useState, useEffect } from 'react';
import { toast } from 'react-hot-toast';
import { Company, JobPosting, JobStats } from '@/types/placement';
import {
  getCompanies,
  addCompany,
  updateCompany,
  deleteCompany,
  getJobPostings,
  addJobPosting,
  updateJobPosting,
  deleteJobPosting,
  incrementJobView,
} from '@/services/companyService';

interface JobFilters {
  status?: string[];
  type?: string;
  minimumCGPA?: number;
  branches?: string[];
  batchYears?: string[];
}

interface UseCompanyReturn {
  companies: Company[];
  jobs: JobPosting[];
  jobStats: JobStats | null;
  loading: boolean;
  error: Error | null;
  companyFilters: {
    status: string;
    industry: string;
  };
  jobFilters: JobFilters;
  setCompanyFilters: (filters: { status: string; industry: string }) => void;
  setJobFilters: (filters: JobFilters) => void;
  addNewCompany: (company: Omit<Company, 'id'>) => Promise<string>;
  updateCompanyDetails: (id: string, data: Partial<Company>) => Promise<void>;
  removeCompany: (id: string) => Promise<void>;
  addNewJob: (job: Omit<JobPosting, 'id' | 'applicationStats'>) => Promise<string>;
  updateJob: (id: string, data: Partial<JobPosting>) => Promise<void>;
  removeJob: (id: string) => Promise<void>;
  incrementJobViews: (id: string) => Promise<void>;
  refreshJobStats: () => Promise<void>;
}

export const useCompany = (): UseCompanyReturn => {
  const [companies, setCompanies] = useState<Company[]>([]);
  const [jobs, setJobs] = useState<JobPosting[]>([]);
  const [jobStats, setJobStats] = useState<JobStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);
  const [companyFilters, setCompanyFilters] = useState({
    status: '',
    industry: '',
  });
  const [jobFilters, setJobFilters] = useState<JobFilters>({});

  // Fetch companies when filters change
  useEffect(() => {
    const fetchCompanies = async () => {
      try {
        setLoading(true);
        const data = await getCompanies(companyFilters);
        setCompanies(data);
        setError(null);
      } catch (err) {
        setError(err as Error);
        toast.error('Failed to fetch companies');
      } finally {
        setLoading(false);
      }
    };

    fetchCompanies();
  }, [companyFilters]);

  // Fetch jobs when filters change
  useEffect(() => {
    const fetchJobs = async () => {
      try {
        setLoading(true);
        const data = await getJobPostings(jobFilters);
        setJobs(data);
        setError(null);
      } catch (err) {
        setError(err as Error);
        toast.error('Failed to fetch jobs');
      } finally {
        setLoading(false);
      }
    };

    fetchJobs();
  }, [jobFilters]);

  const addNewCompany = async (company: Omit<Company, 'id'>): Promise<string> => {
    try {
      const id = await addCompany(company);
      toast.success('Company added successfully');
      // Refresh companies list
      const data = await getCompanies(companyFilters);
      setCompanies(data);
      return id;
    } catch (err) {
      toast.error('Failed to add company');
      throw err;
    }
  };

  const updateCompanyDetails = async (id: string, data: Partial<Company>): Promise<void> => {
    try {
      await updateCompany(id, data);
      toast.success('Company updated successfully');
      // Refresh companies list
      const updatedData = await getCompanies(companyFilters);
      setCompanies(updatedData);
    } catch (err) {
      toast.error('Failed to update company');
      throw err;
    }
  };

  const removeCompany = async (id: string): Promise<void> => {
    try {
      await deleteCompany(id);
      toast.success('Company deleted successfully');
      // Update local state
      setCompanies(prev => prev.filter(company => company.id !== id));
    } catch (err) {
      toast.error('Failed to delete company');
      throw err;
    }
  };

  const addNewJob = async (job: Omit<JobPosting, 'id' | 'applicationStats'>): Promise<string> => {
    try {
      const id = await addJobPosting(job);
      toast.success('Job posting added successfully');
      // Refresh jobs list
      const data = await getJobPostings(jobFilters);
      setJobs(data);
      return id;
    } catch (err) {
      toast.error('Failed to add job posting');
      throw err;
    }
  };

  const updateJob = async (id: string, data: Partial<JobPosting>): Promise<void> => {
    try {
      await updateJobPosting(id, data);
      toast.success('Job posting updated successfully');
      // Refresh jobs list
      const updatedData = await getJobPostings(jobFilters);
      setJobs(updatedData);
    } catch (err) {
      toast.error('Failed to update job posting');
      throw err;
    }
  };

  const removeJob = async (id: string): Promise<void> => {
    try {
      await deleteJobPosting(id);
      toast.success('Job posting deleted successfully');
      // Update local state
      setJobs(prev => prev.filter(job => job.id !== id));
    } catch (err) {
      toast.error('Failed to delete job posting');
      throw err;
    }
  };

  const incrementJobViews = async (id: string): Promise<void> => {
    try {
      await incrementJobView(id);
      // Update local state
      setJobs(prev => prev.map(job => 
        job.id === id 
          ? { ...job, applicationStats: { ...job.applicationStats, views: job.applicationStats.views + 1 } }
          : job
      ));
    } catch (err) {
      console.error('Failed to increment job views:', err);
    }
  };

  const refreshJobStats = async (): Promise<void> => {
    try {
    //   const stats = await getJobStats();
    //   setJobStats(stats);
    } catch (err) {
      toast.error('Failed to fetch job statistics');
      throw err;
    }
  };

  return {
    companies,
    jobs,
    jobStats,
    loading,
    error,
    companyFilters,
    jobFilters,
    setCompanyFilters,
    setJobFilters,
    addNewCompany,
    updateCompanyDetails,
    removeCompany,
    addNewJob,
    updateJob,
    removeJob,
    incrementJobViews,
    refreshJobStats,
  };
}; 