import { useState } from 'react';
import { toast } from 'react-hot-toast';
import {
  Student,
} from '@/types/placement';
import {
  getStudents,
  getStudentById,
  addStudent,
  updateStudent,
  deleteStudent,
  bulkUploadStudents,
  updatePlacementStatus,
  updateAssessment,
  updateInterview,
  getStudentStats,
} from '@/services/studentService';

export const useStudent = () => {
  const [students, setStudents] = useState<Student[]>([]);
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [stats, setStats] = useState<{
    totalStudents: number;
    placedStudents: number;
    unplacedStudents: number;
    debarredStudents: number;
    branchWiseStats: Record<string, { total: number; placed: number; unplaced: number; debarred: number }>;
    batchWiseStats: Record<string, { total: number; placed: number; unplaced: number; debarred: number }>;
  } | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchStudents = async (filters?: {
    branch?: string;
    batchYear?: string;
    placementStatus?: string;
    search?: string;
  }) => {
    try {
      setLoading(true);
      const data = await getStudents(filters);
      setStudents(data);
      setError(null);
    } catch (err) {
      setError('Failed to fetch students');
      toast.error('Failed to fetch students');
    } finally {
      setLoading(false);
    }
  };

  const fetchStudentById = async (id: string) => {
    try {
      setLoading(true);
      const data = await getStudentById(id);
      setSelectedStudent(data);
      setError(null);
      return data;
    } catch (err) {
      setError('Failed to fetch student details');
      toast.error('Failed to fetch student details');
      return null;
    } finally {
      setLoading(false);
    }
  };

  const createStudent = async (studentData: Omit<Student, 'id'>, resumeFile?: File) => {
    try {
      setLoading(true);
      const id = await addStudent(studentData, resumeFile);
      toast.success('Student added successfully');
      await fetchStudents();
      return id;
    } catch (err) {
      setError('Failed to add student');
      toast.error('Failed to add student');
      return null;
    } finally {
      setLoading(false);
    }
  };

  const updateStudentDetails = async (id: string, data: Partial<Student>, resumeFile?: File) => {
    try {
      setLoading(true);
      await updateStudent(id, data, resumeFile);
      toast.success('Student updated successfully');
      await fetchStudents();
    } catch (err) {
      setError('Failed to update student');
      toast.error('Failed to update student');
    } finally {
      setLoading(false);
    }
  };

  const removeStudent = async (id: string) => {
    try {
      setLoading(true);
      await deleteStudent(id);
      toast.success('Student deleted successfully');
      await fetchStudents();
    } catch (err) {
      setError('Failed to delete student');
      toast.error('Failed to delete student');
    } finally {
      setLoading(false);
    }
  };

  const uploadBulkStudents = async (students: Omit<Student, 'id'>[]) => {
    try {
      setLoading(true);
      await bulkUploadStudents(students);
      toast.success('Students uploaded successfully');
      await fetchStudents();
    } catch (err) {
      setError('Failed to upload students');
      toast.error('Failed to upload students');
    } finally {
      setLoading(false);
    }
  };

  const updateStudentPlacementStatus = async (
    id: string,
    status: 'placed' | 'unplaced' | 'debarred',
    placementDetails?: Student['placementDetails']
  ) => {
    try {
      setLoading(true);
      await updatePlacementStatus(id, status, placementDetails);
      toast.success('Placement status updated successfully');
      await fetchStudents();
    } catch (err) {
      setError('Failed to update placement status');
      toast.error('Failed to update placement status');
    } finally {
      setLoading(false);
    }
  };

  const addOrUpdateAssessment = async (
    studentId: string,
    assessment: Student['assessments'][0]
  ) => {
    try {
      setLoading(true);
      await updateAssessment(studentId, assessment);
      toast.success('Assessment updated successfully');
      await fetchStudentById(studentId);
    } catch (err) {
      setError('Failed to update assessment');
      toast.error('Failed to update assessment');
    } finally {
      setLoading(false);
    }
  };

  const addOrUpdateInterview = async (
    studentId: string,
    interview: Student['interviews'][0]
  ) => {
    try {
      setLoading(true);
      await updateInterview(studentId, interview);
      toast.success('Interview updated successfully');
      await fetchStudentById(studentId);
    } catch (err) {
      setError('Failed to update interview');
      toast.error('Failed to update interview');
    } finally {
      setLoading(false);
    }
  };

  const fetchStats = async () => {
    try {
      setLoading(true);
      const data = await getStudentStats();
      setStats(data);
      setError(null);
    } catch (err) {
      setError('Failed to fetch student statistics');
      toast.error('Failed to fetch student statistics');
    } finally {
      setLoading(false);
    }
  };

  return {
    students,
    selectedStudent,
    stats,
    loading,
    error,
    fetchStudents,
    fetchStudentById,
    createStudent,
    updateStudentDetails,
    removeStudent,
    uploadBulkStudents,
    updateStudentPlacementStatus,
    addOrUpdateAssessment,
    addOrUpdateInterview,
    fetchStats,
  };
}; 