import { useState, useEffect } from 'react';
import {
  Student,
  Company,
  JobPosting,
  JobApplication,
  Assessment,
  Document,
  PlacementStats,
} from '@/types/placement';
import * as placementService from '@/services/placementService';

export const usePlacement = () => {
  const [students, setStudents] = useState<Student[]>([]);
  const [companies, setCompanies] = useState<Company[]>([]);
  const [jobPostings, setJobPostings] = useState<JobPosting[]>([]);
  const [applications, setApplications] = useState<JobApplication[]>([]);
  const [assessments, setAssessments] = useState<Assessment[]>([]);
  const [documents, setDocuments] = useState<Document[]>([]);
  const [stats, setStats] = useState<PlacementStats | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Fetch students
  const fetchStudents = async () => {
    try {
      setLoading(true);
      const data = await placementService.getStudents();
      setStudents(data);
      setError(null);
    } catch (err) {
      setError('Failed to fetch students');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // Fetch companies
  const fetchCompanies = async () => {
    try {
      setLoading(true);
      const data = await placementService.getCompanies();
      setCompanies(data);
      setError(null);
    } catch (err) {
      setError('Failed to fetch companies');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // Fetch job postings
  const fetchJobPostings = async (companyId?: string) => {
    try {
      setLoading(true);
      const data = await placementService.getJobPostings(companyId);
      setJobPostings(data);
      setError(null);
    } catch (err) {
      setError('Failed to fetch job postings');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // Add new job posting
  const addJobPosting = async (job: Omit<JobPosting, 'id'>) => {
    try {
      setLoading(true);
      await placementService.addJobPosting(job);
      await fetchJobPostings();
      setError(null);
    } catch (err) {
      setError('Failed to add job posting');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // Fetch applications
  const fetchApplications = async (studentId?: string, jobId?: string) => {
    try {
      setLoading(true);
      const data = await placementService.getApplications(studentId, jobId);
      setApplications(data);
      setError(null);
    } catch (err) {
      setError('Failed to fetch applications');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // Submit application
  const submitApplication = async (application: Omit<JobApplication, 'id'>) => {
    try {
      setLoading(true);
      await placementService.addApplication(application);
      await fetchApplications();
      setError(null);
    } catch (err) {
      setError('Failed to submit application');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // Upload document
  const uploadDocument = async (file: File, studentId: string, type: Document['type']) => {
    try {
      setLoading(true);
      await placementService.uploadDocument(file, studentId, type);
      await fetchDocuments(studentId);
      setError(null);
    } catch (err) {
      setError('Failed to upload document');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // Fetch documents
  const fetchDocuments = async (studentId: string) => {
    try {
      setLoading(true);
      const data = await placementService.getDocuments(studentId);
      setDocuments(data);
      setError(null);
    } catch (err) {
      setError('Failed to fetch documents');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // Fetch placement stats
  const fetchPlacementStats = async (batchYear: number) => {
    try {
      setLoading(true);
      const data = await placementService.getPlacementStats(batchYear);
      setStats(data);
      setError(null);
    } catch (err) {
      setError('Failed to fetch placement stats');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // Send bulk message
  const sendBulkMessage = async (
    type: 'email' | 'sms' | 'whatsapp',
    subject: string,
    content: string,
    recipients: string[]
  ) => {
    try {
      setLoading(true);
      await placementService.sendBulkMessage({
        type,
        subject,
        content,
        recipients,
      });
      setError(null);
    } catch (err) {
      setError('Failed to send bulk message');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return {
    students,
    companies,
    jobPostings,
    applications,
    assessments,
    documents,
    stats,
    loading,
    error,
    fetchStudents,
    fetchCompanies,
    fetchJobPostings,
    addJobPosting,
    fetchApplications,
    submitApplication,
    uploadDocument,
    fetchDocuments,
    fetchPlacementStats,
    sendBulkMessage,
  };
};

export default usePlacement; 