import React from "react";
import { collection, getDocs, doc, writeBatch } from "firebase/firestore";
import toast from "react-hot-toast";
import { db } from "@/config/FirebaseConfig";
import { Button } from "@/components/ui/button";

interface DeleteAllQuizzesProps {
  collectionName: string; // Dynamic top-level collection name
  examId?: string;
  yearId?: string;
  onComplete?: () => void;
}

const DeleteAllQuizzes: React.FC<DeleteAllQuizzesProps> = ({
  collectionName,
  examId,
  yearId,
  onComplete,
}) => {
  const handleDeleteAllQuizzes = async () => {
    try {
      if (!collectionName || !examId || !yearId) {
        toast.error("Collection name, Exam ID, or Year ID is missing.");
        return;
      }

      const quizCollectionRef = collection(
        db,
        collectionName,
        examId,
        "years",
        yearId,
        "quizzes"
      );

      const querySnapshot = await getDocs(quizCollectionRef);
      console.log(collectionName,examId,yearId)

      if (querySnapshot.empty) {
        toast.success("No quizzes to delete.");
        return;
      }
      const batch = writeBatch(db);

      querySnapshot.forEach((docSnap) => {
        const quizDocRef = doc(
          db,
          collectionName,
          examId,
          "years",
          yearId,
          "quizzes",
          docSnap.id
        );
        batch.delete(quizDocRef);
      });

      await batch.commit();

      toast.success("All quizzes deleted successfully!and Page Will Refreshing....");

      if (onComplete) onComplete(); // Call the callback if provided
     
      const refreshToastId = toast.loading("Page will refresh shortly...");
      setTimeout(() => {
       toast.dismiss(refreshToastId); 
       window.location.reload();
     }, 3000); 
    } catch (error) {
      console.error(error);
      toast.error("Failed to delete quizzes.");
    }
  };

  return (
    <Button variant="destructive" onClick={handleDeleteAllQuizzes}>
      Delete All Quizzes
    </Button>
  );
};

export default DeleteAllQuizzes;
