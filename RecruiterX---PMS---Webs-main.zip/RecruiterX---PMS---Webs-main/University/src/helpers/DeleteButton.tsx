import React, { useState } from 'react';
import { Trash2 } from 'lucide-react';  // Or use any delete icon you prefer
import ConfirmationModal from './ConfirmModal';

interface DeleteButtonProps {
  onDelete: () => void;
  itemName: string; // Name of the item being deleted for better UI/UX
}

const DeleteButton: React.FC<DeleteButtonProps> = ({ onDelete, itemName }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleDelete = () => {
    setIsModalOpen(true);
  };

  const handleConfirmDelete = () => {
    onDelete();
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
  };

  return (
    <>
      <button
        className="flex items-center space-x-2 text-red-500 hover:text-red-600"
        onClick={handleDelete}
      >
        <Trash2 />
        <span>Delete {itemName}</span>
      </button>

      <ConfirmationModal
        isOpen={isModalOpen}
        onClose={handleCloseModal}
        onConfirm={handleConfirmDelete}
        message={`Are you sure you want to delete the ${itemName}?`}
      />
    </>
  );
};

export default DeleteButton;
