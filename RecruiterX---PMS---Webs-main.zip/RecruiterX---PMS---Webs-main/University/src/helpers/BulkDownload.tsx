import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";
import React from "react";
import { utils, writeFile } from "xlsx";

interface QuizFormData {
  quizz_id: string;
  Question: string;
  options: {
    Option_ID: string;
    Option_Text: string;
  }[];
  correctAnswer: string;
  explanation: string;
  Question_image: string[];
}

interface BulkDownloadExcelProps {
  quizzes: QuizFormData[];
  yearId?: string; // Now optional
  examId?: string; // Now optional
}
const BulkDownloadExcel: React.FC<BulkDownloadExcelProps> = ({
  quizzes,
  yearId,
  examId,
}) => {
  const handleDownloadExcel = () => {
    // Format quizzes for Excel
    const formattedData = quizzes.map((quiz) => ({
      quizz_id: quiz.quizz_id,
      Question: quiz.Question,
      Option_1: quiz.options[0]?.Option_Text || "",
      Option_2: quiz.options[1]?.Option_Text || "",
      Option_3: quiz.options[2]?.Option_Text || "",
      Option_4: quiz.options[3]?.Option_Text || "",
      correctAnswer: quiz.correctAnswer,
      explanation: quiz.explanation,
    }));

    // Create a worksheet
    const worksheet = utils.json_to_sheet(formattedData);

    // Create a workbook and add the worksheet
    const workbook = utils.book_new();
    utils.book_append_sheet(workbook, worksheet, "Quizzes");

    // Write the workbook to a file
    writeFile(workbook, `${examId}-${yearId} - Quizzes.xlsx`);
  };

  return (
    <Button
      variant="secondary"
      className=" bg-indigo-500 hover:bg-indigo-600 text-white"
      onClick={handleDownloadExcel}
    >
      <Download /> Download Excel
    </Button>
  );
};

export default BulkDownloadExcel;
