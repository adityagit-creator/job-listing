import React, { useState } from "react";
import * as XLSX from "xlsx"; // Library to parse Excel files
import axios from "axios";
import toast from "react-hot-toast";

interface Hospital {
  name: string;
  mobile: string;
  website: string;
}

const WhatsAppSender: React.FC = () => {
  const [hospitals, setHospitals] = useState<Hospital[]>([]);
  const [isSending, setIsSending] = useState(false);

  // Function to parse Excel file and extract hospital details
  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      const data = e.target?.result;
      const workbook = XLSX.read(data, { type: "binary" });
      const sheetName = workbook.SheetNames[0];
      const sheet = workbook.Sheets[sheetName];
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const rows: any[] = XLSX.utils.sheet_to_json(sheet, { header: 1 });

      const parsedHospitals = rows
        .slice(1) // Skip header
        .map((row) => ({
          name: row[0]?.toString(),
          mobile: row[1]?.toString(),
          website: row[2]?.toString(),
        }))
        .filter((hospital) => hospital.mobile && hospital.name);

      // Log the parsed hospitals to the console
      console.log("Parsed Hospitals:", parsedHospitals);

      // Set the hospitals in state to display
      setHospitals(parsedHospitals);
    };
    reader.readAsBinaryString(file);
  };

  // Function to send WhatsApp messages
  const sendMessage = async (hospital: Hospital) => {
    const message1 = `Hi *${hospital.name}* team 👋,\n\nI’m Mugesh, a web developer from Chennai. I specialize in creating affordable, high-converting websites for businesses like yours.\n\nI’d love to help *${hospital.name}* enhance its online presence. Check out my work here: [Portfolio](https://mugesh-rao.web.app/).\n\nIf this is of interest, I’d be happy to discuss how we can create a website that reflects your amazing work—all within your budget.\n\nLooking forward to hearing from you!\n\nBest,\nMugesh`;
    const message = `  
    Hi *${hospital.name}* Team, 👋 \n\nI'm Mugesh Rao, a Web Developer.\n\n I noticed Your isn't Business online, which could be making it hard for Customers to find your services.I can help you by building affordable, mobile-friendly websites that attract more clients. For example, I helped Medgyrus & So many Business boost sales by 60% in just 2 months! 🚀\n\nWould you be open to a quick 15-min chat to explore how a website could help *${hospital.name}* grow?\n\nCheck out my work here: https://mugesh-rao.web.app/ 
    `;
    
    const formattedMobile = hospital.mobile
      .replace(/\s+/g, "")
      .replace(/^0+/, ""); // Remove spaces and leading zeros
    const apiUrl = `https://api.textmebot.com/send.php?recipient=+91${formattedMobile}&apikey=xqVoHxJtM417&text=${encodeURIComponent(
      message
    )}`;

    try {
      await axios.get(apiUrl);
      console.log(`Message sent to ${hospital.name} (${hospital.mobile})`);
    } catch (error) {
      console.error(`Failed to send message to ${hospital.name}:`, error);
    }
  };

  // Function to start sending messages
  const startSendingMessages = async () => {
    setIsSending(true);

    for (let i = 0; i < hospitals.length; i++) {
      const hospital = hospitals[i];
      await sendMessage(hospital);
      toast.success(`Message sent to ${hospital.name} at ${hospital.mobile}`);

      await new Promise((resolve) => setTimeout(resolve, 8000)); // Delay of 8 seconds
      console.log("Delay of 8 seconds");
    }
    setIsSending(false);
  };

  return (
    <div className="flex flex-col w-full items-center justify-center p-6">
      <div className="bg-white border border-gray-500 rounded-lg p-8 max-w-5xl w-full">
        <h1 className="text-2xl font-bold text-gray-800 text-center mb-6">
          WhatsApp Message Sender for Hospitals
        </h1>
        <div className="flex flex-col space-y-4">
          <input
            type="file"
            accept=".xlsx, .xls"
            onChange={handleFileUpload}
            disabled={isSending}
            className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100 disabled:opacity-50 disabled:cursor-not-allowed"
          />
          <button
            onClick={startSendingMessages}
            disabled={isSending || hospitals.length === 0}
            className={`w-full py-2 px-4 rounded-lg font-semibold text-white ${
              isSending || hospitals.length === 0
                ? "bg-gray-400 cursor-not-allowed"
                : "bg-blue-500 hover:bg-blue-600"
            }`}
          >
            {isSending ? "Sending..." : "Start Sending Messages"}
          </button>
        </div>
        <ul className="mt-6 grid sm:grid-cols-3 text-center grid-cols-1 text-sm text-gray-700">
          {hospitals.map((hospital, index) => (
            <li
              key={index}
              className="px-4 py-2 m-1 bg-gray-100 rounded sm flex justify-center items-center"
            >
              {hospital.name} ({hospital.mobile})
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default WhatsAppSender;
