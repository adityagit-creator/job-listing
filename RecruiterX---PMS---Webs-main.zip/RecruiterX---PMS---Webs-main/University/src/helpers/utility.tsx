// Loader.tsx
import React from "react";

export const Loader: React.FC = () => {
  return (
    <div className="flex justify-center items-center h-full">
      <div className="animate-spin rounded-full h-16 w-16 border-y-4 border-black"></div>
    </div>
  );
};

export const SimpleLoader: React.FC = () => {
  return (
    <div className="flex justify-center items-center h-full">
      <div className="animate-spin rounded-full h-8 w-8 border-y-2 border-black"></div>
    </div>
  );
};
// utils.js (or utils.ts)
// eslint-disable-next-line react-refresh/only-export-components
export function capitalizeWords(str: string): string {
  if (!str) return "";
  return str
    .split(" ")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
    .join(" ");
}
