import {
  collection,
  doc,
  getDoc,
  getDocs,
  addDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  Timestamp,
} from 'firebase/firestore';
import { db } from '@/config/firebase';

export interface Recruiter {
  id: string;
  companyName: string;
  industry: string;
  hrContactName: string;
  hrEmail: string;
  hrPhone: string;
  companyWebsite: string;
  companyDescription: string;
  status: 'active' | 'inactive';
  registrationDate: Date;
  lastVisit?: Date;
  jobPostings: number;
  hiringHistory: {
    year: number;
    studentsHired: number;
    averagePackage: number;
  }[];
  documents: {
    type: string;
    url: string;
    uploadedAt: Date;
  }[];
  createdAt: Date;
  updatedAt: Date;
}

// Get all recruiters with optional filters
export const getRecruiters = async (filters?: { 
  status?: string; 
  industry?: string;
}) => {
  try {
    let q = collection(db, 'recruiters');
    const conditions = [];

    if (filters?.status) {
      conditions.push(where('status', '==', filters.status));
    }
    if (filters?.industry) {
      conditions.push(where('industry', '==', filters.industry));
    }

    conditions.push(orderBy('createdAt', 'desc'));
    q = query(q, ...conditions);

    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
      registrationDate: doc.data().registrationDate?.toDate(),
      lastVisit: doc.data().lastVisit?.toDate(),
      createdAt: doc.data().createdAt?.toDate(),
      updatedAt: doc.data().updatedAt?.toDate(),
    })) as Recruiter[];
  } catch (error) {
    console.error('Error getting recruiters:', error);
    throw error;
  }
};

// Get single recruiter by ID
export const getRecruiterById = async (id: string) => {
  try {
    const docRef = doc(db, 'recruiters', id);
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      const data = docSnap.data();
      return {
        id: docSnap.id,
        ...data,
        registrationDate: data.registrationDate?.toDate(),
        lastVisit: data.lastVisit?.toDate(),
        createdAt: data.createdAt?.toDate(),
        updatedAt: data.updatedAt?.toDate(),
      } as Recruiter;
    }
    return null;
  } catch (error) {
    console.error('Error getting recruiter:', error);
    throw error;
  }
};

// Add new recruiter
export const addRecruiter = async (recruiter: Omit<Recruiter, 'id'>) => {
  try {
    const docRef = await addDoc(collection(db, 'recruiters'), {
      ...recruiter,
      createdAt: Timestamp.now(),
      updatedAt: Timestamp.now(),
      registrationDate: Timestamp.now(),
      status: 'active',
      jobPostings: 0,
      hiringHistory: [],
      documents: [],
    });
    return docRef.id;
  } catch (error) {
    console.error('Error adding recruiter:', error);
    throw error;
  }
};

// Update recruiter
export const updateRecruiter = async (id: string, data: Partial<Recruiter>) => {
  try {
    const docRef = doc(db, 'recruiters', id);
    await updateDoc(docRef, {
      ...data,
      updatedAt: Timestamp.now(),
    });
  } catch (error) {
    console.error('Error updating recruiter:', error);
    throw error;
  }
};

// Delete recruiter
export const deleteRecruiter = async (id: string) => {
  try {
    await deleteDoc(doc(db, 'recruiters', id));
  } catch (error) {
    console.error('Error deleting recruiter:', error);
    throw error;
  }
};

// Update recruiter status
export const updateRecruiterStatus = async (id: string, status: 'active' | 'inactive') => {
  try {
    const docRef = doc(db, 'recruiters', id);
    await updateDoc(docRef, {
      status,
      updatedAt: Timestamp.now(),
    });
  } catch (error) {
    console.error('Error updating recruiter status:', error);
    throw error;
  }
};

// Add hiring history
export const addHiringHistory = async (
  id: string, 
  history: { year: number; studentsHired: number; averagePackage: number }
) => {
  try {
    const docRef = doc(db, 'recruiters', id);
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      const currentHistory = docSnap.data().hiringHistory || [];
      await updateDoc(docRef, {
        hiringHistory: [...currentHistory, history],
        updatedAt: Timestamp.now(),
      });
    }
  } catch (error) {
    console.error('Error adding hiring history:', error);
    throw error;
  }
};

// Get recruiter statistics
export const getRecruiterStats = async () => {
  try {
    const querySnapshot = await getDocs(collection(db, 'recruiters'));
    const recruiters = querySnapshot.docs.map(doc => doc.data());

    return {
      totalRecruiters: recruiters.length,
      activeRecruiters: recruiters.filter(r => r.status === 'active').length,
      totalJobPostings: recruiters.reduce((sum, r) => sum + (r.jobPostings || 0), 0),
      industryDistribution: recruiters.reduce((acc, r) => {
        acc[r.industry] = (acc[r.industry] || 0) + 1;
        return acc;
      }, {} as Record<string, number>),
    };
  } catch (error) {
    console.error('Error getting recruiter stats:', error);
    throw error;
  }
}; 