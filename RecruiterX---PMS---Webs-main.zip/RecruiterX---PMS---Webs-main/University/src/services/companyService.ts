import {
  collection,
  doc,
  addDoc,
  updateDoc,
  deleteDoc,
  getDocs,
  getDoc,
  query,
  where,
  orderBy,
  Timestamp,
  increment,
} from 'firebase/firestore';
import { db } from '@/config/firebase';
import { Company, JobPosting } from '@/types/placement';

// Get all companies
export const getCompanies = async (filters?: { 
  status?: string; 
  industry?: string;
}) => {
  try {
    let q = collection(db, 'companies');
    
    if (filters?.status) {
      q = query(q, where('status', '==', filters.status));
    }
    if (filters?.industry) {
      q = query(q, where('industry', '==', filters.industry));
    }
    
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({ 
      id: doc.id, 
      ...doc.data(),
      createdAt: doc.data().createdAt?.toDate(),
      updatedAt: doc.data().updatedAt?.toDate()
    } as Company));
  } catch (error) {
    console.error('Error getting companies:', error);
    throw error;
  }
};

// Get company by ID
export const getCompanyById = async (id: string) => {
  try {
    const docRef = doc(db, 'companies', id);
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      return {
        id: docSnap.id,
        ...docSnap.data(),
        createdAt: docSnap.data().createdAt?.toDate(),
        updatedAt: docSnap.data().updatedAt?.toDate()
      } as Company;
    }
    return null;
  } catch (error) {
    console.error('Error getting company:', error);
    throw error;
  }
};

// Add new company
export const addCompany = async (company: Omit<Company, 'id'>) => {
  try {
    const docRef = await addDoc(collection(db, 'companies'), {
      ...company,
      createdAt: Timestamp.now(),
      updatedAt: Timestamp.now()
    });
    return docRef.id;
  } catch (error) {
    console.error('Error adding company:', error);
    throw error;
  }
};

// Update company
export const updateCompany = async (id: string, data: Partial<Company>) => {
  try {
    const docRef = doc(db, 'companies', id);
    await updateDoc(docRef, {
      ...data,
      updatedAt: Timestamp.now()
    });
  } catch (error) {
    console.error('Error updating company:', error);
    throw error;
  }
};

// Delete company
export const deleteCompany = async (id: string) => {
  try {
    await deleteDoc(doc(db, 'companies', id));
  } catch (error) {
    console.error('Error deleting company:', error);
    throw error;
  }
};

// Get company job postings
export const getCompanyJobs = async (companyId: string) => {
  try {
    const q = query(
      collection(db, 'jobPostings'),
      where('companyId', '==', companyId),
      orderBy('createdAt', 'desc')
    );
    
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
      deadline: doc.data().deadline?.toDate(),
      createdAt: doc.data().createdAt?.toDate()
    } as JobPosting));
  } catch (error) {
    console.error('Error getting company jobs:', error);
    throw error;
  }
};

// Get job postings with filters
export const getJobPostings = async (filters?: {
  companyId?: string;
  status?: string[];
  type?: string;
  minimumCGPA?: number;
  branches?: string[];
  batchYears?: string[];
}) => {
  try {
    let q = collection(db, 'jobPostings');
    
    if (filters?.companyId) {
      q = query(q, where('companyId', '==', filters.companyId));
    }
    if (filters?.status && filters.status.length > 0) {
      q = query(q, where('status', 'in', filters.status));
    }
    if (filters?.type) {
      q = query(q, where('type', '==', filters.type));
    }
    if (filters?.minimumCGPA) {
      q = query(q, where('eligibility.minimumCGPA', '<=', filters.minimumCGPA));
    }
    if (filters?.branches && filters.branches.length > 0) {
      q = query(q, where('eligibility.allowedBranches', 'array-contains-any', filters.branches));
    }
    if (filters?.batchYears && filters.batchYears.length > 0) {
      q = query(q, where('eligibility.allowedBatchYears', 'array-contains-any', filters.batchYears));
    }
    
    q = query(q, orderBy('createdAt', 'desc'));
    
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
      deadline: doc.data().deadline?.toDate(),
      createdAt: doc.data().createdAt?.toDate(),
      updatedAt: doc.data().updatedAt?.toDate(),
      publishedAt: doc.data().publishedAt?.toDate(),
    } as JobPosting));
  } catch (error) {
    console.error('Error getting job postings:', error);
    throw error;
  }
};

// Add job posting
export const addJobPosting = async (job: Omit<JobPosting, 'id' | 'applicationStats'>) => {
  try {
    const docRef = await addDoc(collection(db, 'jobPostings'), {
      ...job,
      applicationStats: {
        views: 0,
        applications: 0,
        shortlisted: 0,
        selected: 0,
      },
      createdAt: Timestamp.now(),
      updatedAt: Timestamp.now(),
      publishedAt: job.status === 'open' ? Timestamp.now() : null,
    });
    return docRef.id;
  } catch (error) {
    console.error('Error adding job posting:', error);
    throw error;
  }
};

// Update job posting
export const updateJobPosting = async (id: string, data: Partial<JobPosting>) => {
  try {
    const docRef = doc(db, 'jobPostings', id);
    const updateData = {
      ...data,
      updatedAt: Timestamp.now(),
    };
    
    // If status is being changed to 'open', set publishedAt
    if (data.status === 'open') {
      updateData.publishedAt = Timestamp.now();
    }
    
    await updateDoc(docRef, updateData);
  } catch (error) {
    console.error('Error updating job posting:', error);
    throw error;
  }
};

// Delete job posting
export const deleteJobPosting = async (id: string) => {
  try {
    await deleteDoc(doc(db, 'jobPostings', id));
  } catch (error) {
    console.error('Error deleting job posting:', error);
    throw error;
  }
};

// Increment job posting view count
export const incrementJobView = async (id: string) => {
  try {
    const docRef = doc(db, 'jobPostings', id);
    await updateDoc(docRef, {
      'applicationStats.views': increment(1),
    });
  } catch (error) {
    console.error('Error incrementing job view:', error);
    throw error;
  }
};

// Get company statistics
export const getCompanyStats = async (companyId: string) => {
  try {
    // Get all job postings for the company
    const jobs = await getCompanyJobs(companyId);
    
    // Get all applications for company's jobs
    const applications = await Promise.all(
      jobs.map(async job => {
        const q = query(
          collection(db, 'applications'),
          where('jobId', '==', job.id)
        );
        const querySnapshot = await getDocs(q);
        return querySnapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        }));
      })
    );
    
    // Calculate statistics
    const flatApplications = applications.flat();
    const totalApplications = flatApplications.length;
    const shortlisted = flatApplications.filter(app => app.status === 'shortlisted').length;
    const pending = flatApplications.filter(app => app.status === 'pending').length;
    const conversionRate = totalApplications > 0 
      ? ((shortlisted / totalApplications) * 100).toFixed(1) 
      : 0;
    
    return {
      totalApplications,
      shortlisted,
      pending,
      conversionRate,
      activeJobs: jobs.filter(job => job.status === 'open').length,
      totalJobs: jobs.length
    };
  } catch (error) {
    console.error('Error getting company statistics:', error);
    throw error;
  }
}; 