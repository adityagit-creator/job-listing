import {
  collection,
  doc,
  addDoc,
  updateDoc,
  deleteDoc,
  getDocs,
  getDoc,
  query,
  where,
  orderBy,
  Timestamp,
} from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { db, storage } from '@/config/firebase';
import {
  Student,
  Company,
  JobPosting,
  JobApplication,
  Assessment,
  Interview,
  Document,
  BulkMessage,
  PlacementStats,
} from '@/types/placement';

// Students
export const getStudents = async () => {
  const querySnapshot = await getDocs(collection(db, 'students'));
  return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Student));
};

export const getStudentById = async (id: string) => {
  const docRef = doc(db, 'students', id);
  const docSnap = await getDoc(docRef);
  return docSnap.exists() ? { id: docSnap.id, ...docSnap.data() } as Student : null;
};

export const addStudent = async (student: Omit<Student, 'id'>) => {
  return await addDoc(collection(db, 'students'), student);
};

export const updateStudent = async (id: string, data: Partial<Student>) => {
  const docRef = doc(db, 'students', id);
  await updateDoc(docRef, data);
};

// Companies
export const getCompanies = async () => {
  const querySnapshot = await getDocs(collection(db, 'companies'));
  return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Company));
};

export const addCompany = async (company: Omit<Company, 'id'>) => {
  return await addDoc(collection(db, 'companies'), company);
};

// Job Postings
export const getJobPostings = async (companyId?: string) => {
  const jobsRef = collection(db, 'jobPostings');
  const q = companyId 
    ? query(jobsRef, where('companyId', '==', companyId), orderBy('createdAt', 'desc'))
    : query(jobsRef, orderBy('createdAt', 'desc'));
  
  const querySnapshot = await getDocs(q);
  return querySnapshot.docs.map(doc => ({ 
    id: doc.id, 
    ...doc.data(),
    deadline: (doc.data().deadline as Timestamp).toDate(),
    createdAt: (doc.data().createdAt as Timestamp).toDate(),
  } as JobPosting));
};

export const addJobPosting = async (job: Omit<JobPosting, 'id'>) => {
  return await addDoc(collection(db, 'jobPostings'), {
    ...job,
    createdAt: Timestamp.now(),
  });
};

// Applications
export const getApplications = async (studentId?: string, jobId?: string) => {
  const applicationsRef = collection(db, 'applications');
  let q = query(applicationsRef);
  
  if (studentId) {
    q = query(q, where('studentId', '==', studentId));
  }
  if (jobId) {
    q = query(q, where('jobId', '==', jobId));
  }
  
  const querySnapshot = await getDocs(q);
  return querySnapshot.docs.map(doc => ({ 
    id: doc.id, 
    ...doc.data(),
    appliedAt: (doc.data().appliedAt as Timestamp).toDate(),
  } as JobApplication));
};

export const addApplication = async (application: Omit<JobApplication, 'id'>) => {
  return await addDoc(collection(db, 'applications'), {
    ...application,
    appliedAt: Timestamp.now(),
  });
};

// Assessments & Interviews
export const getAssessments = async (jobId: string) => {
  const q = query(
    collection(db, 'assessments'),
    where('jobId', '==', jobId),
    orderBy('scheduledDate')
  );
  const querySnapshot = await getDocs(q);
  return querySnapshot.docs.map(doc => ({ 
    id: doc.id, 
    ...doc.data(),
    scheduledDate: (doc.data().scheduledDate as Timestamp).toDate(),
  } as Assessment));
};

export const addAssessment = async (assessment: Omit<Assessment, 'id'>) => {
  return await addDoc(collection(db, 'assessments'), {
    ...assessment,
    scheduledDate: Timestamp.fromDate(assessment.scheduledDate),
  });
};

// Documents
export const uploadDocument = async (file: File, studentId: string, type: Document['type']) => {
  const storageRef = ref(storage, `documents/${studentId}/${type}/${file.name}`);
  await uploadBytes(storageRef, file);
  const url = await getDownloadURL(storageRef);
  
  const document: Omit<Document, 'id'> = {
    studentId,
    type,
    url,
    status: 'pending',
  };
  
  return await addDoc(collection(db, 'documents'), document);
};

export const getDocuments = async (studentId: string) => {
  const q = query(
    collection(db, 'documents'),
    where('studentId', '==', studentId)
  );
  const querySnapshot = await getDocs(q);
  return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Document));
};

export const verifyDocument = async (documentId: string, verifiedBy: string, status: Document['status'], comments?: string) => {
  const docRef = doc(db, 'documents', documentId);
  await updateDoc(docRef, {
    status,
    verifiedBy,
    verifiedAt: Timestamp.now(),
    comments,
  });
};

// Bulk Communication
export const sendBulkMessage = async (message: Omit<BulkMessage, 'id' | 'status' | 'sentAt'>) => {
  return await addDoc(collection(db, 'messages'), {
    ...message,
    status: 'sent',
    sentAt: Timestamp.now(),
  });
};

// Analytics
export const getPlacementStats = async (batchYear: number) => {
  const docRef = doc(db, 'placementStats', batchYear.toString());
  const docSnap = await getDoc(docRef);
  return docSnap.exists() ? { id: docSnap.id, ...docSnap.data() } as PlacementStats : null;
}; 