import {
  collection,
  doc,
  getDoc,
  getDocs,
  updateDoc,
  query,
  where,
  orderBy,
  Timestamp,
  addDoc,
  deleteDoc,
} from 'firebase/firestore';
import { db } from '@/config/firebase';
import { Student, Company, JobPosting, Assessment, Interview, Document, BulkMessage } from '@/types/placement';

// Student Management
export const getStudents = async (filters?: { branch?: string; verificationStatus?: string }) => {
  try {
    let q = collection(db, 'students');
    const conditions = [];

    if (filters?.branch) {
      conditions.push(where('branch', '==', filters.branch));
    }
    if (filters?.verificationStatus) {
      conditions.push(where('verificationStatus', '==', filters.verificationStatus));
    }

    conditions.push(orderBy('createdAt', 'desc'));
    q = query(q, ...conditions);

    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    })) as Student[];
  } catch (error) {
    console.error('Error getting students:', error);
    throw error;
  }
};

export const verifyStudent = async (studentId: string, status: 'approved' | 'rejected', comments?: string) => {
  try {
    const docRef = doc(db, 'students', studentId);
    await updateDoc(docRef, {
      verificationStatus: status,
      verificationComments: comments || '',
      verifiedAt: Timestamp.now(),
    });

    // Create notification
    await addDoc(collection(db, 'notifications'), {
      studentId,
      type: 'verification',
      title: `Registration ${status}`,
      message: status === 'approved'
        ? 'Your registration has been approved. You can now access the portal.'
        : `Your registration has been rejected. Reason: ${comments}`,
      read: false,
      createdAt: Timestamp.now(),
    });
  } catch (error) {
    console.error('Error verifying student:', error);
    throw error;
  }
};

// Document Verification
export const verifyDocument = async (documentId: string, status: 'verified' | 'rejected', verifiedBy: string, comments?: string) => {
  try {
    const docRef = doc(db, 'documents', documentId);
    await updateDoc(docRef, {
      status,
      verifiedBy,
      verifiedAt: Timestamp.now(),
      comments,
    });

    // Get document details to create notification
    const docSnap = await getDoc(docRef);
    const documentData = docSnap.data() as Document;

    // Create notification
    await addDoc(collection(db, 'notifications'), {
      studentId: documentData.studentId,
      type: 'document_verification',
      title: `Document ${status}`,
      message: status === 'verified'
        ? `Your ${documentData.type} has been verified.`
        : `Your ${documentData.type} has been rejected. Reason: ${comments}`,
      read: false,
      createdAt: Timestamp.now(),
    });
  } catch (error) {
    console.error('Error verifying document:', error);
    throw error;
  }
};

// Assessment Management
export const scheduleAssessment = async (assessment: Omit<Assessment, 'id'>) => {
  try {
    const docRef = await addDoc(collection(db, 'assessments'), {
      ...assessment,
      createdAt: Timestamp.now(),
      scheduledDate: Timestamp.fromDate(assessment.scheduledDate),
    });

    // Create notifications for all participants
    const notifications = assessment.participants.map(studentId => ({
      studentId,
      type: 'assessment',
      title: 'New Assessment Scheduled',
      message: `An assessment has been scheduled for ${assessment.jobId} on ${assessment.scheduledDate.toLocaleDateString()}.`,
      read: false,
      createdAt: Timestamp.now(),
    }));

    await Promise.all(
      notifications.map(notification =>
        addDoc(collection(db, 'notifications'), notification)
      )
    );

    return docRef.id;
  } catch (error) {
    console.error('Error scheduling assessment:', error);
    throw error;
  }
};

// Interview Management
export const scheduleInterview = async (interview: Omit<Interview, 'id'>) => {
  try {
    const docRef = await addDoc(collection(db, 'interviews'), {
      ...interview,
      createdAt: Timestamp.now(),
      scheduledDate: Timestamp.fromDate(interview.scheduledDate),
    });

    // Create notifications for all participants
    const notifications = interview.participants.map(studentId => ({
      studentId,
      type: 'interview',
      title: 'Interview Scheduled',
      message: `An interview has been scheduled for ${interview.jobId} on ${interview.scheduledDate.toLocaleDateString()}.`,
      read: false,
      createdAt: Timestamp.now(),
    }));

    await Promise.all(
      notifications.map(notification =>
        addDoc(collection(db, 'notifications'), notification)
      )
    );

    return docRef.id;
  } catch (error) {
    console.error('Error scheduling interview:', error);
    throw error;
  }
};

// Bulk Communication
export const sendBulkMessage = async (message: Omit<BulkMessage, 'id' | 'status' | 'sentAt'>) => {
  try {
    const docRef = await addDoc(collection(db, 'messages'), {
      ...message,
      status: 'sent',
      sentAt: Timestamp.now(),
    });

    // Create notifications for all recipients
    const notifications = message.recipients.map(studentId => ({
      studentId,
      type: message.type,
      title: message.subject || 'New Message',
      message: message.content,
      read: false,
      createdAt: Timestamp.now(),
    }));

    await Promise.all(
      notifications.map(notification =>
        addDoc(collection(db, 'notifications'), notification)
      )
    );

    return docRef.id;
  } catch (error) {
    console.error('Error sending bulk message:', error);
    throw error;
  }
};

// Analytics
export const getPlacementStats = async (batchYear: number) => {
  try {
    const studentsRef = collection(db, 'students');
    const applicationsRef = collection(db, 'applications');
    const offersRef = collection(db, 'offers');

    // Get total students
    const totalStudentsQuery = query(
      studentsRef,
      where('batchYear', '==', batchYear)
    );
    const totalStudentsSnapshot = await getDocs(totalStudentsQuery);
    const totalStudents = totalStudentsSnapshot.size;

    // Get placed students
    const placedStudentsQuery = query(
      studentsRef,
      where('batchYear', '==', batchYear),
      where('placementStatus', '==', 'placed')
    );
    const placedStudentsSnapshot = await getDocs(placedStudentsQuery);
    const placedStudents = placedStudentsSnapshot.size;

    // Get branch-wise stats
    const branches = ['CSE', 'IT', 'ECE', 'ME'];
    const branchWiseStats: { [key: string]: { total: number; placed: number; averagePackage: number } } = {};

    for (const branch of branches) {
      const branchStudentsQuery = query(
        studentsRef,
        where('batchYear', '==', batchYear),
        where('branch', '==', branch)
      );
      const branchStudentsSnapshot = await getDocs(branchStudentsQuery);
      const branchPlacedStudentsQuery = query(
        studentsRef,
        where('batchYear', '==', batchYear),
        where('branch', '==', branch),
        where('placementStatus', '==', 'placed')
      );
      const branchPlacedStudentsSnapshot = await getDocs(branchPlacedStudentsQuery);

      branchWiseStats[branch] = {
        total: branchStudentsSnapshot.size,
        placed: branchPlacedStudentsSnapshot.size,
        averagePackage: 0, // Calculate this based on offers
      };
    }

    return {
      batchYear,
      totalStudents,
      placedStudents,
      placementRate: (placedStudents / totalStudents) * 100,
      branchWiseStats,
    };
  } catch (error) {
    console.error('Error getting placement stats:', error);
    throw error;
  }
}; 