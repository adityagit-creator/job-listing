import {
  collection,
  addDoc,
  query,
  where,
  getDocs,
  updateDoc,
  doc,
  Timestamp,
  orderBy
} from 'firebase/firestore';
import { db } from '@/config/firebase';
import { Student } from '@/types/placement';

interface NotificationData {
  id?: string;
  title: string;
  message: string;
  type: 'placement' | 'assessment' | 'interview' | 'document' | 'general';
  priority: 'high' | 'medium' | 'low';
  recipients: {
    branches?: string[];
    batchYear?: string;
    placementStatus?: 'placed' | 'unplaced';
    cgpaCriteria?: number;
  };
  sentVia: ('app' | 'whatsapp' | 'email')[];
  status: 'sent' | 'failed';
  createdAt: Date;
  readBy: string[];
}

// Send notification to students based on criteria
export const sendNotification = async (notificationData: Omit<NotificationData, 'id' | 'status' | 'createdAt' | 'readBy'>) => {
  try {
    // Build query based on recipient criteria
    let studentsQuery = query(collection(db, 'students'));
    
    if (notificationData.recipients.branches?.length) {
      studentsQuery = query(studentsQuery, where('branch', 'in', notificationData.recipients.branches));
    }
    
    if (notificationData.recipients.batchYear) {
      studentsQuery = query(studentsQuery, where('batchYear', '==', notificationData.recipients.batchYear));
    }
    
    if (notificationData.recipients.placementStatus) {
      studentsQuery = query(studentsQuery, where('placementStatus', '==', notificationData.recipients.placementStatus));
    }
    
    if (notificationData.recipients.cgpaCriteria) {
      studentsQuery = query(studentsQuery, where('cgpa', '>=', notificationData.recipients.cgpaCriteria));
    }

    const studentsSnapshot = await getDocs(studentsQuery);
    const students = studentsSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Student));

    // Create notification in database
    const notification = {
      ...notificationData,
      status: 'sent',
      createdAt: Timestamp.now(),
      readBy: []
    };

    const notificationRef = await addDoc(collection(db, 'notifications'), notification);

    // Send WhatsApp messages if enabled
    if (notificationData.sentVia.includes('whatsapp')) {
      for (const student of students) {
        if (student.whatsappEnabled && student.phone) {
          await sendWhatsAppMessage(student.phone, {
            title: notificationData.title,
            message: notificationData.message
          });
        }
      }
    }

    // Send emails if enabled
    if (notificationData.sentVia.includes('email')) {
      for (const student of students) {
        if (student.email) {
          await sendEmail(student.email, {
            subject: notificationData.title,
            body: notificationData.message
          });
        }
      }
    }

    return notificationRef.id;
  } catch (error) {
    console.error('Error sending notification:', error);
    throw error;
  }
};

// Get notifications for a specific student
export const getStudentNotifications = async (studentId: string) => {
  try {
    const notificationsRef = collection(db, 'notifications');
    const q = query(notificationsRef, orderBy('createdAt', 'desc'));
    const snapshot = await getDocs(q);
    
    const notifications = snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
      createdAt: doc.data().createdAt.toDate()
    }));

    // Filter notifications based on student criteria
    const studentDoc = await doc(db, 'students', studentId).get();
    const studentData = studentDoc.data() as Student;

    return notifications.filter(notification => {
      const criteria = notification.recipients;
      return (
        (!criteria.branches?.length || criteria.branches.includes(studentData.branch)) &&
        (!criteria.batchYear || criteria.batchYear === studentData.batchYear) &&
        (!criteria.placementStatus || criteria.placementStatus === studentData.placementStatus) &&
        (!criteria.cgpaCriteria || studentData.cgpa >= criteria.cgpaCriteria)
      );
    });
  } catch (error) {
    console.error('Error getting notifications:', error);
    throw error;
  }
};

// Mark notification as read
export const markNotificationAsRead = async (notificationId: string, studentId: string) => {
  try {
    const notificationRef = doc(db, 'notifications', notificationId);
    await updateDoc(notificationRef, {
      readBy: arrayUnion(studentId)
    });
  } catch (error) {
    console.error('Error marking notification as read:', error);
    throw error;
  }
};

const sendWhatsAppMessage = async (phone: string, { title, message }: { title: string; message: string }) => {
  try {
    const response = await fetch(`https://api.textmebot.com/send.php?recipient=${phone}&message=${encodeURIComponent(`${title}\n\n${message}`)}&apikey=YOUR_TEXTME_API_KEY`, {
      method: 'GET'
    });

    if (!response.ok) {
      throw new Error('Failed to send WhatsApp message');
    }

    return await response.text(); // textMe API returns a simple success message
  } catch (error) {
    console.error('Error sending WhatsApp message:', error);
    throw error;
  }
};


// Send email using your preferred email service
const sendEmail = async (email: string, { subject, body }: { subject: string; body: string }) => {
  // Implement your email sending logic here
  // You can use services like SendGrid, AWS SES, etc.
  console.log('Sending email to:', email, { subject, body });
}; 