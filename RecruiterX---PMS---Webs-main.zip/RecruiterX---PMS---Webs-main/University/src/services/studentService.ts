import {
  collection,
  doc,
  getDoc,
  getDocs,
  addDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  Timestamp,
  writeBatch,
} from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { db, storage } from '@/config/firebase';
import { Student } from '@/types/placement';

// Get all students with optional filters
export const getStudents = async (filters?: {
  branch?: string;
  batchYear?: string;
  placementStatus?: string;
  search?: string;
}) => {
  try {
    let q = collection(db, 'students');
    const conditions = [];

    if (filters?.branch) {
      conditions.push(where('branch', '==', filters.branch));
    }
    if (filters?.batchYear) {
      conditions.push(where('batchYear', '==', filters.batchYear));
    }
    if (filters?.placementStatus) {
      conditions.push(where('placementStatus', '==', filters.placementStatus));
    }

    conditions.push(orderBy('createdAt', 'desc'));
    q = query(q, ...conditions);

    const querySnapshot = await getDocs(q);
    const students = querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
      createdAt: doc.data().createdAt?.toDate(),
      updatedAt: doc.data().updatedAt?.toDate(),
    })) as Student[];

    if (filters?.search) {
      const searchLower = filters.search.toLowerCase();
      return students.filter(
        student =>
          student.name.toLowerCase().includes(searchLower) ||
          student.email.toLowerCase().includes(searchLower) ||
          student.rollNumber.toLowerCase().includes(searchLower)
      );
    }

    return students;
  } catch (error) {
    console.error('Error getting students:', error);
    throw error;
  }
};

// Get single student by ID
export const getStudentById = async (id: string) => {
  try {
    const docRef = doc(db, 'students', id);
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      const data = docSnap.data();
      return {
        id: docSnap.id,
        ...data,
        createdAt: data.createdAt?.toDate(),
        updatedAt: data.updatedAt?.toDate(),
      } as Student;
    }
    return null;
  } catch (error) {
    console.error('Error getting student:', error);
    throw error;
  }
};

// Add new student
export const addStudent = async (student: Omit<Student, 'id'>, resumeFile?: File) => {
  try {
    let resumeUrl = '';
    if (resumeFile) {
      const storageRef = ref(storage, `resumes/${Date.now()}_${resumeFile.name}`);
      await uploadBytes(storageRef, resumeFile);
      resumeUrl = await getDownloadURL(storageRef);
    }

    const docRef = await addDoc(collection(db, 'students'), {
      ...student,
      resume: resumeUrl ? {
        url: resumeUrl,
        uploadedAt: Timestamp.now()
      } : null,
      createdAt: Timestamp.now(),
      updatedAt: Timestamp.now(),
    });

    return docRef.id;
  } catch (error) {
    console.error('Error adding student:', error);
    throw error;
  }
};

// Update student
export const updateStudent = async (id: string, data: Partial<Student>, resumeFile?: File) => {
  try {
    let resumeUrl = '';
    if (resumeFile) {
      const storageRef = ref(storage, `resumes/${Date.now()}_${resumeFile.name}`);
      await uploadBytes(storageRef, resumeFile);
      resumeUrl = await getDownloadURL(storageRef);
    }

    const docRef = doc(db, 'students', id);
    await updateDoc(docRef, {
      ...data,
      ...(resumeUrl && {
        resume: {
          url: resumeUrl,
          uploadedAt: Timestamp.now()
        }
      }),
      updatedAt: Timestamp.now(),
    });
  } catch (error) {
    console.error('Error updating student:', error);
    throw error;
  }
};

// Delete student
export const deleteStudent = async (id: string) => {
  try {
    await deleteDoc(doc(db, 'students', id));
  } catch (error) {
    console.error('Error deleting student:', error);
    throw error;
  }
};

// Bulk upload students
export const bulkUploadStudents = async (students: Omit<Student, 'id'>[]) => {
  const batch = writeBatch(db);
  try {
    students.forEach((student) => {
      const docRef = doc(collection(db, 'students'));
      batch.set(docRef, {
        ...student,
        createdAt: Timestamp.now(),
        updatedAt: Timestamp.now(),
      });
    });

    await batch.commit();
  } catch (error) {
    console.error('Error bulk uploading students:', error);
    throw error;
  }
};

// Update placement status
export const updatePlacementStatus = async (
  id: string,
  status: 'placed' | 'unplaced' | 'debarred',
  placementDetails?: Student['placementDetails']
) => {
  try {
    const docRef = doc(db, 'students', id);
    await updateDoc(docRef, {
      placementStatus: status,
      ...(placementDetails && { placementDetails }),
      updatedAt: Timestamp.now(),
    });
  } catch (error) {
    console.error('Error updating placement status:', error);
    throw error;
  }
};

// Add or update assessment
export const updateAssessment = async (
  studentId: string,
  assessment: Student['assessments'][0]
) => {
  try {
    const docRef = doc(db, 'students', studentId);
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      const currentAssessments = docSnap.data().assessments || [];
      const index = currentAssessments.findIndex(a => a.id === assessment.id);
      
      if (index !== -1) {
        currentAssessments[index] = assessment;
      } else {
        currentAssessments.push(assessment);
      }

      await updateDoc(docRef, {
        assessments: currentAssessments,
        updatedAt: Timestamp.now(),
      });
    }
  } catch (error) {
    console.error('Error updating assessment:', error);
    throw error;
  }
};

// Add or update interview
export const updateInterview = async (
  studentId: string,
  interview: Student['interviews'][0]
) => {
  try {
    const docRef = doc(db, 'students', studentId);
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      const currentInterviews = docSnap.data().interviews || [];
      const index = currentInterviews.findIndex(i => i.id === interview.id);
      
      if (index !== -1) {
        currentInterviews[index] = interview;
      } else {
        currentInterviews.push(interview);
      }

      await updateDoc(docRef, {
        interviews: currentInterviews,
        updatedAt: Timestamp.now(),
      });
    }
  } catch (error) {
    console.error('Error updating interview:', error);
    throw error;
  }
};

// Get student statistics
export const getStudentStats = async () => {
  try {
    const querySnapshot = await getDocs(collection(db, 'students'));
    const students = querySnapshot.docs.map(doc => doc.data() as Student);

    return {
      totalStudents: students.length,
      placedStudents: students.filter(s => s.placementStatus === 'placed').length,
      unplacedStudents: students.filter(s => s.placementStatus === 'unplaced').length,
      debarredStudents: students.filter(s => s.placementStatus === 'debarred').length,
      branchWiseStats: students.reduce((acc, student) => {
        acc[student.branch] = acc[student.branch] || {
          total: 0,
          placed: 0,
          unplaced: 0,
          debarred: 0,
        };
        acc[student.branch].total++;
        acc[student.branch][student.placementStatus]++;
        return acc;
      }, {} as Record<string, { total: number; placed: number; unplaced: number; debarred: number }>),
      batchWiseStats: students.reduce((acc, student) => {
        acc[student.batchYear] = acc[student.batchYear] || {
          total: 0,
          placed: 0,
          unplaced: 0,
          debarred: 0,
        };
        acc[student.batchYear].total++;
        acc[student.batchYear][student.placementStatus]++;
        return acc;
      }, {} as Record<string, { total: number; placed: number; unplaced: number; debarred: number }>),
    };
  } catch (error) {
    console.error('Error getting student stats:', error);
    throw error;
  }
}; 