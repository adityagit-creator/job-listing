import { 
  collection,
  doc,
  getDoc,
  getDocs,
  addDoc,
  updateDoc,
  query,
  where,
  orderBy,
  Timestamp 
} from 'firebase/firestore';
import { db } from '../config/firebase';

// Assessment Platform Integration
const PLATFORM_CONFIGS = {
  hackerrank: {
    baseUrl: 'https://www.hackerrank.com/test',
    apiKey: process.env.HACKERRANK_API_KEY
  },
  codility: {
    baseUrl: 'https://app.codility.com/test',
    apiKey: process.env.CODILITY_API_KEY
  },
  mettl: {
    baseUrl: 'https://tests.mettl.com',
    apiKey: process.env.METTL_API_KEY
  }
};

// Get Assessment Details
export const getAssessmentDetails = async (assessmentId) => {
  try {
    const docRef = doc(db, 'assessments', assessmentId);
    const docSnap = await getDoc(docRef);
    
    if (docSnap.exists()) {
      return { id: docSnap.id, ...docSnap.data() };
    }
    return null;
  } catch (error) {
    console.error('Error getting assessment details:', error);
    throw error;
  }
};

// Get Student's Assessments
export const getStudentAssessments = async (studentId) => {
  try {
    const q = query(
      collection(db, 'assessment_assignments'),
      where('studentId', '==', studentId),
      orderBy('deadline', 'desc')
    );
    
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    }));
  } catch (error) {
    console.error('Error getting student assessments:', error);
    throw error;
  }
};

// Start Assessment
export const startAssessment = async (studentId, assessmentId) => {
  try {
    const assessment = await getAssessmentDetails(assessmentId);
    if (!assessment) {
      throw new Error('Assessment not found');
    }
    
    const platform = PLATFORM_CONFIGS[assessment.platform];
    if (!platform) {
      throw new Error('Assessment platform not supported');
    }
    
    // Create assessment session
    const session = {
      studentId,
      assessmentId,
      platform: assessment.platform,
      status: 'started',
      startedAt: Timestamp.now()
    };
    
    const sessionRef = await addDoc(collection(db, 'assessment_sessions'), session);
    
    // Generate platform-specific test link
    const testUrl = await generateTestLink(assessment, studentId);
    
    return {
      sessionId: sessionRef.id,
      testUrl,
      duration: assessment.duration,
      instructions: assessment.instructions
    };
  } catch (error) {
    console.error('Error starting assessment:', error);
    throw error;
  }
};

// Submit Assessment
export const submitAssessment = async (sessionId, answers) => {
  try {
    const sessionRef = doc(db, 'assessment_sessions', sessionId);
    const sessionDoc = await getDoc(sessionRef);
    
    if (!sessionDoc.exists()) {
      throw new Error('Assessment session not found');
    }
    
    const session = sessionDoc.data();
    
    // Update session status
    await updateDoc(sessionRef, {
      status: 'submitted',
      answers,
      submittedAt: Timestamp.now()
    });
    
    // Create submission record
    const submission = {
      sessionId,
      studentId: session.studentId,
      assessmentId: session.assessmentId,
      answers,
      submittedAt: Timestamp.now()
    };
    
    await addDoc(collection(db, 'assessment_submissions'), submission);
    
    return { status: 'success' };
  } catch (error) {
    console.error('Error submitting assessment:', error);
    throw error;
  }
};

// Get Assessment Results
export const getAssessmentResults = async (sessionId) => {
  try {
    const sessionRef = doc(db, 'assessment_sessions', sessionId);
    const sessionDoc = await getDoc(sessionRef);
    
    if (!sessionDoc.exists()) {
      throw new Error('Assessment session not found');
    }
    
    const session = sessionDoc.data();
    
    // Get results from assessment platform
    const results = await fetchPlatformResults(session);
    
    // Update session with results
    await updateDoc(sessionRef, {
      results,
      status: 'completed',
      completedAt: Timestamp.now()
    });
    
    return results;
  } catch (error) {
    console.error('Error getting assessment results:', error);
    throw error;
  }
};

// Helper Functions
const generateTestLink = async (assessment, studentId) => {
  try {
    const platform = PLATFORM_CONFIGS[assessment.platform];
    
    // Here you would implement platform-specific logic to generate test links
    // This is a placeholder implementation
    const testUrl = `${platform.baseUrl}/${assessment.id}?student=${studentId}&token=${generateToken()}`;
    
    return testUrl;
  } catch (error) {
    console.error('Error generating test link:', error);
    throw error;
  }
};

const fetchPlatformResults = async (session) => {
  try {
    const platform = PLATFORM_CONFIGS[session.platform];
    
    // Here you would implement platform-specific logic to fetch results
    // This is a placeholder implementation
    return {
      score: 0,
      maxScore: 100,
      timeTaken: 0,
      feedback: [],
      status: 'pending'
    };
  } catch (error) {
    console.error('Error fetching platform results:', error);
    throw error;
  }
};

const generateToken = () => {
  // Generate a random token for test authentication
  return Math.random().toString(36).substring(2);
};

// Assessment Analytics
export const getAssessmentAnalytics = async (studentId) => {
  try {
    const q = query(
      collection(db, 'assessment_sessions'),
      where('studentId', '==', studentId),
      where('status', '==', 'completed')
    );
    
    const querySnapshot = await getDocs(q);
    const sessions = querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    }));
    
    // Calculate analytics
    const analytics = {
      totalAssessments: sessions.length,
      averageScore: 0,
      completionRate: 0,
      timeSpent: 0,
      assessmentsByPlatform: {},
      scoreDistribution: {
        excellent: 0,
        good: 0,
        average: 0,
        needsImprovement: 0
      }
    };
    
    sessions.forEach(session => {
      if (session.results) {
        // Update average score
        analytics.averageScore += (session.results.score / sessions.length);
        
        // Update completion rate
        analytics.completionRate = (sessions.filter(s => s.status === 'completed').length / sessions.length) * 100;
        
        // Update time spent
        if (session.completedAt && session.startedAt) {
          analytics.timeSpent += session.completedAt.seconds - session.startedAt.seconds;
        }
        
        // Update platform distribution
        analytics.assessmentsByPlatform[session.platform] = (analytics.assessmentsByPlatform[session.platform] || 0) + 1;
        
        // Update score distribution
        const score = (session.results.score / session.results.maxScore) * 100;
        if (score >= 90) analytics.scoreDistribution.excellent++;
        else if (score >= 75) analytics.scoreDistribution.good++;
        else if (score >= 60) analytics.scoreDistribution.average++;
        else analytics.scoreDistribution.needsImprovement++;
      }
    });
    
    return analytics;
  } catch (error) {
    console.error('Error getting assessment analytics:', error);
    throw error;
  }
}; 