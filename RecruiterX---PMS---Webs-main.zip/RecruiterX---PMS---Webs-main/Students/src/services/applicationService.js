import { 
  collection,
  doc,
  getDoc,
  getDocs,
  addDoc,
  updateDoc,
  query,
  where,
  orderBy,
  Timestamp 
} from 'firebase/firestore';
import { db } from '../config/firebase';

// Job Applications
export const submitApplication = async (studentId, jobId, applicationData) => {
  try {
    const jobRef = doc(db, 'jobs', jobId);
    const jobDoc = await getDoc(jobRef);
    
    if (!jobDoc.exists()) {
      throw new Error('Job not found');
    }
    
    const application = {
      studentId,
      jobId,
      companyId: jobDoc.data().companyId,
      status: 'pending',
      ...applicationData,
      createdAt: Timestamp.now(),
      updatedAt: Timestamp.now()
    };
    
    const docRef = await addDoc(collection(db, 'applications'), application);
    return { id: docRef.id, ...application };
  } catch (error) {
    console.error('Error submitting application:', error);
    throw error;
  }
};

export const getStudentApplications = async (studentId) => {
  try {
    const q = query(
      collection(db, 'applications'),
      where('studentId', '==', studentId),
      orderBy('createdAt', 'desc')
    );
    
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    }));
  } catch (error) {
    console.error('Error getting applications:', error);
    throw error;
  }
};

export const updateApplicationStatus = async (applicationId, status, feedback = '') => {
  try {
    const docRef = doc(db, 'applications', applicationId);
    await updateDoc(docRef, {
      status,
      feedback,
      updatedAt: Timestamp.now()
    });
  } catch (error) {
    console.error('Error updating application status:', error);
    throw error;
  }
};

// Assessments
export const getAssessmentDetails = async (assessmentId) => {
  try {
    const docRef = doc(db, 'assessments', assessmentId);
    const docSnap = await getDoc(docRef);
    
    if (docSnap.exists()) {
      return { id: docSnap.id, ...docSnap.data() };
    }
    return null;
  } catch (error) {
    console.error('Error getting assessment details:', error);
    throw error;
  }
};

export const submitAssessment = async (studentId, assessmentId, answers) => {
  try {
    const submission = {
      studentId,
      assessmentId,
      answers,
      submittedAt: Timestamp.now()
    };
    
    const docRef = await addDoc(collection(db, 'assessment_submissions'), submission);
    return { id: docRef.id, ...submission };
  } catch (error) {
    console.error('Error submitting assessment:', error);
    throw error;
  }
};

export const getStudentAssessments = async (studentId) => {
  try {
    const q = query(
      collection(db, 'assessment_submissions'),
      where('studentId', '==', studentId),
      orderBy('submittedAt', 'desc')
    );
    
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    }));
  } catch (error) {
    console.error('Error getting assessments:', error);
    throw error;
  }
};

// Interview Scheduling
export const scheduleInterview = async (applicationId, interviewDetails) => {
  try {
    const docRef = doc(db, 'applications', applicationId);
    await updateDoc(docRef, {
      interview: {
        ...interviewDetails,
        scheduledAt: Timestamp.now()
      },
      status: 'interview_scheduled',
      updatedAt: Timestamp.now()
    });
  } catch (error) {
    console.error('Error scheduling interview:', error);
    throw error;
  }
};

export const updateInterviewStatus = async (applicationId, status, feedback = '') => {
  try {
    const docRef = doc(db, 'applications', applicationId);
    await updateDoc(docRef, {
      'interview.status': status,
      'interview.feedback': feedback,
      'interview.updatedAt': Timestamp.now(),
      updatedAt: Timestamp.now()
    });
  } catch (error) {
    console.error('Error updating interview status:', error);
    throw error;
  }
};

// Notifications
export const createNotification = async (studentId, type, title, message, actionUrl = null) => {
  try {
    const notification = {
      studentId,
      type,
      title,
      message,
      actionUrl,
      read: false,
      createdAt: Timestamp.now()
    };
    
    const docRef = await addDoc(collection(db, 'notifications'), notification);
    return { id: docRef.id, ...notification };
  } catch (error) {
    console.error('Error creating notification:', error);
    throw error;
  }
};

export const getStudentNotifications = async (studentId) => {
  try {
    const q = query(
      collection(db, 'notifications'),
      where('studentId', '==', studentId),
      orderBy('createdAt', 'desc')
    );
    
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    }));
  } catch (error) {
    console.error('Error getting notifications:', error);
    throw error;
  }
};

export const markNotificationAsRead = async (notificationId) => {
  try {
    const docRef = doc(db, 'notifications', notificationId);
    await updateDoc(docRef, {
      read: true,
      updatedAt: Timestamp.now()
    });
  } catch (error) {
    console.error('Error marking notification as read:', error);
    throw error;
  }
}; 