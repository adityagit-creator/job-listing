import { 
  collection, 
  doc, 
  getDocs, 
  getDoc, 
  setDoc, 
  updateDoc, 
  query, 
  where, 
  orderBy,
  Timestamp,
  limit
} from 'firebase/firestore';
import { getStorage, ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { db, storage } from '../contexts/FirebaseConfig';
import { auth } from '../contexts/FirebaseConfig';

// Profile Management
export const getStudentProfile = async (studentId) => {
  try {
    const docRef = doc(db, 'students', studentId);
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      return {
        id: docSnap.id,
        ...docSnap.data()
      };
    }
    return null;
  } catch (error) {
    console.error('Error getting student profile:', error);
    throw error;
  }
};

export const updateStudentProfile = async (studentId, profileData) => {
  try {
    const docRef = doc(db, 'students', studentId);
    await updateDoc(docRef, {
      ...profileData,
      updatedAt: Timestamp.now()
    });
  } catch (error) {
    console.error('Error updating student profile:', error);
    throw error;
  }
};

export const uploadDocument = async (file, studentId, documentType) => {
  try {
    const storageRef = ref(storage, `students/${studentId}/${documentType}/${file.name}`);
    await uploadBytes(storageRef, file);
    const downloadURL = await getDownloadURL(storageRef);
    
    // Update student profile with document URL
    const docRef = doc(db, 'students', studentId);
    await updateDoc(docRef, {
      [`documents.${documentType}`]: downloadURL,
      [`documents.${documentType}UpdatedAt`]: Timestamp.now()
    });
    
    return downloadURL;
  } catch (error) {
    console.error('Error uploading document:', error);
    throw error;
  }
};

// Job Applications
export const getStudentApplications = async (studentId) => {
  try {
    const q = query(
      collection(db, 'applications'),
      where('studentId', '==', studentId),
      orderBy('appliedAt', 'desc')
    );
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
      appliedAt: doc.data().appliedAt?.toDate(),
      updatedAt: doc.data().updatedAt?.toDate()
    }));
  } catch (error) {
    console.error('Error getting applications:', error);
    throw error;
  }
};

// Job Listings
export const getJobListings = async (filters = {}) => {
  try {
    let q = collection(db, 'jobs');
    
    if (filters.branch) {
      q = query(q, where('eligibility.branches', 'array-contains', filters.branch));
    }
    
    if (filters.type) {
      q = query(q, where('type', '==', filters.type));
    }
    
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
      deadline: doc.data().deadline?.toDate(),
      createdAt: doc.data().createdAt?.toDate()
    }));
  } catch (error) {
    console.error('Error getting job listings:', error);
    throw error;
  }
};

// Offer Letters
export const getOfferLetters = async (studentId) => {
  try {
    const q = query(
      collection(db, 'offers'),
      where('studentId', '==', studentId),
      orderBy('createdAt', 'desc')
    );
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
      createdAt: doc.data().createdAt?.toDate(),
      acceptanceDeadline: doc.data().acceptanceDeadline?.toDate()
    }));
  } catch (error) {
    console.error('Error getting offer letters:', error);
    throw error;
  }
};

export const updateOfferStatus = async (offerId, status) => {
  try {
    const docRef = doc(db, 'offers', offerId);
    await updateDoc(docRef, {
      status,
      updatedAt: Timestamp.now()
    });
  } catch (error) {
    console.error('Error updating offer status:', error);
    throw error;
  }
};

// Dashboard Stats
export const getStudentDashboardStats = async (studentId) => {
  try {
    const applications = await getStudentApplications(studentId);
    const offers = await getOfferLetters(studentId);
    
    return {
      totalApplications: applications.length,
      pendingApplications: applications.filter(app => app.status === 'pending').length,
      shortlistedApplications: applications.filter(app => app.status === 'shortlisted').length,
      activeOffers: offers.filter(offer => offer.status === 'pending').length,
      acceptedOffers: offers.filter(offer => offer.status === 'accepted').length
    };
  } catch (error) {
    console.error('Error getting dashboard stats:', error);
    throw error;
  }
};

// Notifications
export const getStudentNotifications = async (studentId) => {
  try {
    const q = query(
      collection(db, 'notifications'),
      where('studentId', '==', studentId),
      orderBy('createdAt', 'desc')
    );
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
      createdAt: doc.data().createdAt?.toDate()
    }));
  } catch (error) {
    console.error('Error getting notifications:', error);
    throw error;
  }
};

export const markNotificationAsRead = async (notificationId) => {
  try {
    const docRef = doc(db, 'notifications', notificationId);
    await updateDoc(docRef, {
      read: true,
      readAt: Timestamp.now()
    });
  } catch (error) {
    console.error('Error marking notification as read:', error);
    throw error;
  }
};

// Job Details and Application
export const getJobDetails = async (jobId) => {
  try {
    const docRef = doc(db, 'jobs', jobId);
    const docSnap = await getDoc(docRef);
    
    if (!docSnap.exists()) {
      return null;
    }

    // Check if the current user has already applied
    const currentUser = auth.currentUser;
    let hasApplied = false;
    
    if (currentUser) {
      const applicationsQuery = query(
        collection(db, 'applications'),
        where('jobId', '==', jobId),
        where('studentId', '==', currentUser.uid),
        limit(1)
      );
      const applicationsSnapshot = await getDocs(applicationsQuery);
      hasApplied = !applicationsSnapshot.empty;
    }

    return {
      id: docSnap.id,
      ...docSnap.data(),
      deadline: docSnap.data().deadline?.toDate(),
      createdAt: docSnap.data().createdAt?.toDate(),
      hasApplied
    };
  } catch (error) {
    console.error('Error getting job details:', error);
    throw error;
  }
};

export const applyForJob = async (jobId, studentId, resumeFile) => {
  try {
    // Upload resume
    const resumeRef = ref(storage, `applications/${jobId}/${studentId}/${resumeFile.name}`);
    await uploadBytes(resumeRef, resumeFile);
    const resumeUrl = await getDownloadURL(resumeRef);

    // Get student profile
    const studentProfile = await getStudentProfile(studentId);
    
    // Create application document
    const applicationData = {
      jobId,
      studentId,
      resumeUrl,
      status: 'pending',
      studentName: studentProfile.fullName,
      studentEmail: studentProfile.email,
      studentBranch: studentProfile.branch,
      studentCGPA: studentProfile.cgpa,
      appliedAt: Timestamp.now(),
      updatedAt: Timestamp.now()
    };

    // Add to applications collection
    const applicationRef = doc(collection(db, 'applications'));
    await setDoc(applicationRef, applicationData);

    // Create notification for student
    const notificationData = {
      studentId,
      type: 'application_submitted',
      title: 'Application Submitted',
      message: `Your application for the position has been submitted successfully.`,
      read: false,
      createdAt: Timestamp.now()
    };

    await setDoc(doc(collection(db, 'notifications')), notificationData);

    return applicationRef.id;
  } catch (error) {
    console.error('Error applying for job:', error);
    throw error;
  }
}; 