import { 
  collection,
  doc,
  getDoc,
  getDocs,
  addDoc,
  updateDoc,
  query,
  where,
  orderBy,
  Timestamp 
} from 'firebase/firestore';
import { db } from '../contexts/FirebaseConfig';

// Notification Types
export const NOTIFICATION_TYPES = {
  APPLICATION_STATUS: 'application_status',
  INTERVIEW_SCHEDULED: 'interview_scheduled',
  ASSESSMENT_REMINDER: 'assessment_reminder',
  DEADLINE_REMINDER: 'deadline_reminder',
  OFFER_LETTER: 'offer_letter',
  PROFILE_UPDATE: 'profile_update'
};

// Create Notification
export const createNotification = async (studentId, type, data) => {
  try {
    const notification = {
      studentId,
      type,
      title: getNotificationTitle(type, data),
      message: getNotificationMessage(type, data),
      data,
      read: false,
      createdAt: Timestamp.now()
    };
    
    const docRef = await addDoc(collection(db, 'notifications'), notification);
    
    // Send WhatsApp notification if enabled
    const studentRef = doc(db, 'students', studentId);
    const studentDoc = await getDoc(studentRef);
    
    if (studentDoc.exists() && studentDoc.data().preferences?.whatsappEnabled) {
      await sendWhatsAppNotification(
        studentDoc.data().preferences.whatsappPhone,
        notification
      );
    }
    
    return { id: docRef.id, ...notification };
  } catch (error) {
    console.error('Error creating notification:', error);
    throw error;
  }
};

// Get Student's Notifications
export const getStudentNotifications = async (studentId, options = {}) => {
  try {
    let conditions = [
      where('studentId', '==', studentId),
      orderBy('createdAt', 'desc')
    ];
    
    if (options.unreadOnly) {
      conditions.push(where('read', '==', false));
    }
    
    if (options.type) {
      conditions.push(where('type', '==', options.type));
    }
    
    const q = query(collection(db, 'notifications'), ...conditions);
    const querySnapshot = await getDocs(q);
    
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    }));
  } catch (error) {
    console.error('Error getting notifications:', error);
    throw error;
  }
};

// Mark Notification as Read
export const markNotificationAsRead = async (notificationId) => {
  try {
    const docRef = doc(db, 'notifications', notificationId);
    await updateDoc(docRef, {
      read: true,
      updatedAt: Timestamp.now()
    });
  } catch (error) {
    console.error('Error marking notification as read:', error);
    throw error;
  }
};

// Mark All Notifications as Read
export const markAllNotificationsAsRead = async (studentId) => {
  try {
    const q = query(
      collection(db, 'notifications'),
      where('studentId', '==', studentId),
      where('read', '==', false)
    );
    
    const querySnapshot = await getDocs(q);
    const batch = db.batch();
    
    querySnapshot.docs.forEach(doc => {
      batch.update(doc.ref, {
        read: true,
        updatedAt: Timestamp.now()
      });
    });
    
    await batch.commit();
  } catch (error) {
    console.error('Error marking all notifications as read:', error);
    throw error;
  }
};

// WhatsApp Integration
export const enableWhatsAppNotifications = async (studentId, phone) => {
  try {
    const docRef = doc(db, 'students', studentId);
    await updateDoc(docRef, {
      'preferences.whatsappEnabled': true,
      'preferences.whatsappPhone': phone,
      updatedAt: Timestamp.now()
    });
    
    // Send test WhatsApp message
    await sendWhatsAppNotification(phone, {
      title: 'WhatsApp Notifications Enabled',
      message: 'You will now receive important updates via WhatsApp.'
    });
  } catch (error) {
    console.error('Error enabling WhatsApp notifications:', error);
    throw error;
  }
};

export const disableWhatsAppNotifications = async (studentId) => {
  try {
    const docRef = doc(db, 'students', studentId);
    await updateDoc(docRef, {
      'preferences.whatsappEnabled': false,
      updatedAt: Timestamp.now()
    });
  } catch (error) {
    console.error('Error disabling WhatsApp notifications:', error);
    throw error;
  }
};

// Helper Functions
const getNotificationTitle = (type, data) => {
  switch (type) {
    case NOTIFICATION_TYPES.APPLICATION_STATUS:
      return `Application ${data.status}`;
    case NOTIFICATION_TYPES.INTERVIEW_SCHEDULED:
      return 'Interview Scheduled';
    case NOTIFICATION_TYPES.ASSESSMENT_REMINDER:
      return 'Assessment Reminder';
    case NOTIFICATION_TYPES.DEADLINE_REMINDER:
      return 'Application Deadline Reminder';
    case NOTIFICATION_TYPES.OFFER_LETTER:
      return 'New Offer Letter';
    case NOTIFICATION_TYPES.PROFILE_UPDATE:
      return 'Profile Update Required';
    default:
      return 'New Notification';
  }
};

const getNotificationMessage = (type, data) => {
  switch (type) {
    case NOTIFICATION_TYPES.APPLICATION_STATUS:
      return `Your application for ${data.position} at ${data.company} has been ${data.status}.`;
    case NOTIFICATION_TYPES.INTERVIEW_SCHEDULED:
      return `Your interview for ${data.position} at ${data.company} is scheduled for ${data.datetime}.`;
    case NOTIFICATION_TYPES.ASSESSMENT_REMINDER:
      return `You have an upcoming assessment for ${data.company}. Please complete it by ${data.deadline}.`;
    case NOTIFICATION_TYPES.DEADLINE_REMINDER:
      return `The application deadline for ${data.position} at ${data.company} is approaching (${data.deadline}).`;
    case NOTIFICATION_TYPES.OFFER_LETTER:
      return `Congratulations! You have received an offer letter from ${data.company}.`;
    case NOTIFICATION_TYPES.PROFILE_UPDATE:
      return `Please update your profile: ${data.message}`;
    default:
      return data.message || 'You have a new notification.';
  }
};

const sendWhatsAppNotification = async (phone, notification) => {
  try {
    // Here you would implement WhatsApp API integration
    // This is a placeholder implementation
    console.log('Sending WhatsApp notification to:', phone, notification);
    
    // Example using WhatsApp Business API
    const message = {
      to: phone,
      type: 'template',
      template: {
        name: 'notification_alert',
        language: {
          code: 'en'
        },
        components: [
          {
            type: 'body',
            parameters: [
              {
                type: 'text',
                text: notification.title
              },
              {
                type: 'text',
                text: notification.message
              }
            ]
          }
        ]
      }
    };
    
    // Make API call to WhatsApp Business API
    // const response = await axios.post('whatsapp-api-endpoint', message);
    // return response.data;
    
    return true;
  } catch (error) {
    console.error('Error sending WhatsApp notification:', error);
    throw error;
  }
};

export const getNotifications = async (userId) => {
  try {
    const q = query(
      collection(db, 'notifications'),
      where('userId', '==', userId),
      orderBy('createdAt', 'desc')
    );

    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
      createdAt: doc.data().createdAt?.toDate(),
      readAt: doc.data().readAt?.toDate()
    }));
  } catch (error) {
    console.error('Error getting notifications:', error);
    throw error;
  }
};

export const markAsRead = async (notificationId) => {
  try {
    const notificationRef = doc(db, 'notifications', notificationId);
    await updateDoc(notificationRef, {
      read: true,
      readAt: Timestamp.now()
    });
  } catch (error) {
    console.error('Error marking notification as read:', error);
    throw error;
  }
};

export const getUnreadCount = async (userId) => {
  try {
    const q = query(
      collection(db, 'notifications'),
      where('userId', '==', userId),
      where('read', '==', false)
    );

    const querySnapshot = await getDocs(q);
    return querySnapshot.size;
  } catch (error) {
    console.error('Error getting unread count:', error);
    throw error;
  }
}; 