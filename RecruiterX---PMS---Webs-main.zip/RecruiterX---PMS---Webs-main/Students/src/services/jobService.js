import { 
  collection,
  doc,
  getDoc,
  getDocs,
  query,
  where,
  orderBy,
  limit,
  startAfter,
  Timestamp,
  updateDoc,
  increment
} from 'firebase/firestore';
import { db } from '../contexts/FirebaseConfig';

// Job Listings
export const getJobListings = async (filters = {}, lastDoc = null, pageSize = 10) => {
  try {
    let q = collection(db, 'jobs');
    
    // Build query with filters
    const conditions = [];
    
    if (filters.branch) {
      conditions.push(where('eligibility.branches', 'array-contains', filters.branch));
    }
    
    if (filters.type) {
      conditions.push(where('type', '==', filters.type));
    }
    
    if (filters.minimumCGPA) {
      conditions.push(where('eligibility.minimumCGPA', '<=', filters.minimumCGPA));
    }
    
    if (filters.location) {
      conditions.push(where('location', '==', filters.location));
    }
    
    if (filters.package) {
      conditions.push(where('package.ctc', '>=', filters.package));
    }
    
    // Add ordering
    conditions.push(orderBy('createdAt', 'desc'));
    conditions.push(limit(pageSize));
    
    // Add pagination if lastDoc is provided
    if (lastDoc) {
      conditions.push(startAfter(lastDoc));
    }
    
    q = query(q, ...conditions);
    
    const querySnapshot = await getDocs(q);
    const lastVisible = querySnapshot.docs[querySnapshot.docs.length - 1];
    
    const jobs = querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    }));
    
    return {
      jobs,
      lastDoc: lastVisible
    };
  } catch (error) {
    console.error('Error getting job listings:', error);
    throw error;
  }
};

export const getJobDetails = async (jobId) => {
  try {
    const docRef = doc(db, 'jobs', jobId);
    const docSnap = await getDoc(docRef);
    
    if (docSnap.exists()) {
      return {
        id: docSnap.id,
        ...docSnap.data(),
        deadline: docSnap.data().deadline?.toDate(),
        createdAt: docSnap.data().createdAt?.toDate(),
        updatedAt: docSnap.data().updatedAt?.toDate()
      };
    }
    return null;
  } catch (error) {
    console.error('Error getting job details:', error);
    throw error;
  }
};

// Company Information
export const getCompanyDetails = async (companyId) => {
  try {
    const docRef = doc(db, 'companies', companyId);
    const docSnap = await getDoc(docRef);
    
    if (docSnap.exists()) {
      return { id: docSnap.id, ...docSnap.data() };
    }
    return null;
  } catch (error) {
    console.error('Error getting company details:', error);
    throw error;
  }
};

export const getCompanyJobs = async (companyId) => {
  try {
    const q = query(
      collection(db, 'jobs'),
      where('companyId', '==', companyId),
      where('active', '==', true),
      orderBy('createdAt', 'desc')
    );
    
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    }));
  } catch (error) {
    console.error('Error getting company jobs:', error);
    throw error;
  }
};

// Eligibility Checks
export const checkEligibility = async (studentId, jobId) => {
  try {
    // Get student profile
    const studentRef = doc(db, 'students', studentId);
    const studentDoc = await getDoc(studentRef);
    
    if (!studentDoc.exists()) {
      throw new Error('Student profile not found');
    }
    
    const student = studentDoc.data();
    
    // Get job details
    const jobRef = doc(db, 'jobs', jobId);
    const jobDoc = await getDoc(jobRef);
    
    if (!jobDoc.exists()) {
      throw new Error('Job not found');
    }
    
    const job = jobDoc.data();
    
    // Check eligibility criteria
    const eligible = {
      status: true,
      reasons: []
    };
    
    // Check CGPA
    if (job.eligibility.minimumCGPA && student.personalInfo.cgpa < job.eligibility.minimumCGPA) {
      eligible.status = false;
      eligible.reasons.push(`Minimum CGPA requirement is ${job.eligibility.minimumCGPA}`);
    }
    
    // Check branch
    if (job.eligibility.branches && !job.eligibility.branches.includes(student.personalInfo.branch)) {
      eligible.status = false;
      eligible.reasons.push('Your branch is not eligible for this position');
    }
    
    // Check if already applied
    const applicationQuery = query(
      collection(db, 'applications'),
      where('studentId', '==', studentId),
      where('jobId', '==', jobId)
    );
    
    const applicationSnapshot = await getDocs(applicationQuery);
    if (!applicationSnapshot.empty) {
      eligible.status = false;
      eligible.reasons.push('You have already applied for this position');
    }
    
    // Check if blacklisted
    if (student.blacklisted) {
      eligible.status = false;
      eligible.reasons.push('You are currently not eligible to apply');
    }
    
    return eligible;
  } catch (error) {
    console.error('Error checking eligibility:', error);
    throw error;
  }
};

// Job Search and Recommendations
export const searchJobs = async (query) => {
  try {
    // Here you would implement full-text search
    // For now, we'll do a simple query
    const q = collection(db, 'jobs');
    const querySnapshot = await getDocs(q);
    
    return querySnapshot.docs
      .map(doc => ({ id: doc.id, ...doc.data() }))
      .filter(job => 
        job.title.toLowerCase().includes(query.toLowerCase()) ||
        job.description.toLowerCase().includes(query.toLowerCase()) ||
        job.companyName.toLowerCase().includes(query.toLowerCase())
      );
  } catch (error) {
    console.error('Error searching jobs:', error);
    throw error;
  }
};

export const getRecommendedJobs = async (studentId) => {
  try {
    // Get student profile
    const studentRef = doc(db, 'students', studentId);
    const studentDoc = await getDoc(studentRef);
    
    if (!studentDoc.exists()) {
      throw new Error('Student profile not found');
    }
    
    const student = studentDoc.data();
    
    // Query jobs matching student's profile
    const q = query(
      collection(db, 'jobs'),
      where('eligibility.branches', 'array-contains', student.personalInfo.branch),
      where('eligibility.minimumCGPA', '<=', student.personalInfo.cgpa),
      where('active', '==', true),
      orderBy('createdAt', 'desc'),
      limit(10)
    );
    
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    }));
  } catch (error) {
    console.error('Error getting recommended jobs:', error);
    throw error;
  }
};

export const getJobPostings = async (filters = {}) => {
  try {
    let q = collection(db, 'jobs');
    const conditions = [];

    if (filters.type) {
      conditions.push(where('type', '==', filters.type));
    }

    if (filters.minimumCGPA) {
      conditions.push(where('eligibility.minimumCGPA', '>=', filters.minimumCGPA));
    }

    if (filters.branches && filters.branches.length > 0) {
      conditions.push(where('eligibility.branches', 'array-contains-any', filters.branches));
    }

    if (filters.status && filters.status.length > 0) {
      conditions.push(where('status', 'in', filters.status));
    }

    if (filters.batchYears && filters.batchYears.length > 0) {
      conditions.push(where('eligibility.batchYears', 'array-contains-any', filters.batchYears));
    }

    // Add conditions to query
    if (conditions.length > 0) {
      q = query(q, ...conditions);
    }

    // Always order by deadline
    q = query(q, orderBy('deadline', 'asc'));

    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
      deadline: doc.data().deadline?.toDate(),
      createdAt: doc.data().createdAt?.toDate(),
      updatedAt: doc.data().updatedAt?.toDate()
    }));
  } catch (error) {
    console.error('Error getting job postings:', error);
    throw error;
  }
};

export const incrementJobView = async (jobId) => {
  try {
    const jobRef = doc(db, 'jobs', jobId);
    await updateDoc(jobRef, {
      'applicationStats.views': increment(1),
      updatedAt: Timestamp.now()
    });
  } catch (error) {
    console.error('Error incrementing job views:', error);
    throw error;
  }
}; 