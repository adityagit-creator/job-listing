import { 
  collection, 
  doc, 
  getDocs, 
  getDoc, 
  addDoc, 
  updateDoc, 
  query, 
  where, 
  orderBy,
  Timestamp 
} from 'firebase/firestore';
import { db } from '../contexts/FirebaseConfig';

// Get all internships
export const getAllInternships = async () => {
  try {
    const q = query(
      collection(db, 'internships'),
      orderBy('createdAt', 'desc')
    );
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
      deadline: doc.data().deadline?.toDate(),
      createdAt: doc.data().createdAt?.toDate()
    }));
  } catch (error) {
    console.error('Error getting internships:', error);
    throw error;
  }
};

// Get single internship by ID
export const getInternshipById = async (id) => {
  try {
    const docRef = doc(db, 'internships', id);
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      return {
        id: docSnap.id,
        ...docSnap.data(),
        deadline: docSnap.data().deadline?.toDate(),
        createdAt: docSnap.data().createdAt?.toDate()
      };
    }
    return null;
  } catch (error) {
    console.error('Error getting internship:', error);
    throw error;
  }
};

// Submit internship application
export const submitApplication = async (internshipId, studentId, applicationData) => {
  try {
    const application = {
      internshipId,
      studentId,
      ...applicationData,
      status: 'pending',
      appliedAt: Timestamp.now()
    };

    const docRef = await addDoc(collection(db, 'applications'), application);
    return docRef.id;
  } catch (error) {
    console.error('Error submitting application:', error);
    throw error;
  }
};

// Check if student has already applied
export const checkApplicationStatus = async (internshipId, studentId) => {
  try {
    const q = query(
      collection(db, 'applications'),
      where('internshipId', '==', internshipId),
      where('studentId', '==', studentId)
    );
    const querySnapshot = await getDocs(q);
    return !querySnapshot.empty;
  } catch (error) {
    console.error('Error checking application status:', error);
    throw error;
  }
};

// Get student's applications
export const getStudentApplications = async (studentId) => {
  try {
    const q = query(
      collection(db, 'applications'),
      where('studentId', '==', studentId),
      orderBy('appliedAt', 'desc')
    );
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
      appliedAt: doc.data().appliedAt?.toDate()
    }));
  } catch (error) {
    console.error('Error getting student applications:', error);
    throw error;
  }
};

// Filter internships by criteria
export const filterInternships = async (filters) => {
  try {
    let q = collection(db, 'internships');
    
    if (filters.branch) {
      q = query(q, where('eligibility.branches', 'array-contains', filters.branch));
    }
    
    if (filters.duration) {
      q = query(q, where('duration', '==', filters.duration));
    }
    
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
      deadline: doc.data().deadline?.toDate(),
      createdAt: doc.data().createdAt?.toDate()
    }));
  } catch (error) {
    console.error('Error filtering internships:', error);
    throw error;
  }
}; 