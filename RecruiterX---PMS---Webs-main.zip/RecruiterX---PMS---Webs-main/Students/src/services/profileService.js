import { 
  doc, 
  getDoc, 
  setDoc, 
  updateDoc, 
  collection,
  query,
  where,
  getDocs,
  Timestamp 
} from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { db } from '../contexts/FirebaseConfig';

// Profile Management
export const getStudentProfile = async (userId) => {
  try {
    const docRef = doc(db, 'students', userId);
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      return { id: docSnap.id, ...docSnap.data() };
    }
    return null;
  } catch (error) {
    console.error('Error getting student profile:', error);
    throw error;
  }
};

export const createStudentProfile = async (userId, profileData) => {
  try {
    await setDoc(doc(db, 'students', userId), {
      ...profileData,
      createdAt: Timestamp.now(),
      updatedAt: Timestamp.now()
    });
  } catch (error) {
    console.error('Error creating student profile:', error);
    throw error;
  }
};

export const updateStudentProfile = async (userId, profileData) => {
  try {
    const docRef = doc(db, 'students', userId);
    await updateDoc(docRef, {
      ...profileData,
      updatedAt: Timestamp.now()
    });
  } catch (error) {
    console.error('Error updating student profile:', error);
    throw error;
  }
};

// Document Management
export const uploadDocument = async (userId, file, type) => {
  try {
    const storageRef = ref(storage, `students/${userId}/${type}/${file.name}`);
    await uploadBytes(storageRef, file);
    const url = await getDownloadURL(storageRef);
    
    const docRef = doc(db, 'students', userId);
    await updateDoc(docRef, {
      [`documents.${type}`]: url,
      [`documents.${type}UpdatedAt`]: Timestamp.now()
    });
    
    return url;
  } catch (error) {
    console.error('Error uploading document:', error);
    throw error;
  }
};

// Resume Parsing
export const parseResume = async (userId, resumeFile) => {
  try {
    // Upload resume first
    const url = await uploadDocument(userId, resumeFile, 'resume');
    
    // Here you would integrate with a resume parsing service
    // For now, we'll return a mock structure
    return {
      education: [],
      experience: [],
      skills: [],
      projects: [],
      certifications: []
    };
  } catch (error) {
    console.error('Error parsing resume:', error);
    throw error;
  }
};

// Social Media Integration
export const importLinkedInProfile = async (userId, accessToken) => {
  try {
    // Here you would integrate with LinkedIn API
    // For now, we'll return a mock structure
    return {
      education: [],
      experience: [],
      skills: [],
      certifications: []
    };
  } catch (error) {
    console.error('Error importing LinkedIn profile:', error);
    throw error;
  }
};

export const importGitHubProfile = async (userId, accessToken) => {
  try {
    // Here you would integrate with GitHub API
    // For now, we'll return a mock structure
    return {
      projects: [],
      skills: [],
      contributions: []
    };
  } catch (error) {
    console.error('Error importing GitHub profile:', error);
    throw error;
  }
};

// Profile Verification
export const verifyEmail = async (userId, email) => {
  try {
    const studentsRef = collection(db, 'students');
    const q = query(studentsRef, where('email', '==', email));
    const querySnapshot = await getDocs(q);
    
    if (!querySnapshot.empty) {
      throw new Error('Email already exists');
    }
    
    // Here you would integrate with email verification service
    return true;
  } catch (error) {
    console.error('Error verifying email:', error);
    throw error;
  }
};

export const verifyPhone = async (userId, phone) => {
  try {
    const studentsRef = collection(db, 'students');
    const q = query(studentsRef, where('phone', '==', phone));
    const querySnapshot = await getDocs(q);
    
    if (!querySnapshot.empty) {
      throw new Error('Phone number already exists');
    }
    
    // Here you would integrate with phone verification service
    return true;
  } catch (error) {
    console.error('Error verifying phone:', error);
    throw error;
  }
};

// WhatsApp Integration
export const enableWhatsAppNotifications = async (userId, phone) => {
  try {
    const docRef = doc(db, 'students', userId);
    await updateDoc(docRef, {
      whatsappEnabled: true,
      whatsappPhone: phone,
      updatedAt: Timestamp.now()
    });
  } catch (error) {
    console.error('Error enabling WhatsApp notifications:', error);
    throw error;
  }
}; 