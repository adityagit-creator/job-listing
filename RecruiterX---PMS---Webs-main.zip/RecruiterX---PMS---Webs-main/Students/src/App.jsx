import { useEffect, useState } from 'react';
import { Toaster } from 'react-hot-toast';
import {
  Route,
  RouterProvider,
  Routes,
  ScrollRestoration,
  createBrowserRouter
} from 'react-router-dom';

import {
  DesignComponent,
  MainNavigationBar,
  Preloader,
  PrivateOutlet,
  PublicOutlet
} from './components';

// Website Pages

// Student Pages

// Business & Account Pages
import Others from './components/Account/Other';
import UserFeedback from './components/Account/UserFeedBack';
import Navigator from './components/atoms/Navigator';
import Contact from './components/Biz-Page/ContactUs';
import AccountDelete from './components/Biz-Page/DeleteAccount';
import Pricing from './components/Biz-Page/Pricing';
import PrivacyPolicy from './components/Biz-Page/PrivacyPolicy';
import RefundPolicies from './components/Biz-Page/RefundCallencationPolicies';
import TermsConditions from './components/Biz-Page/Terms&Conditions';

import { AuthProvider } from './contexts/AuthContext';
import { About, Home,Profile } from './pages';
import PageNotFound from './pages/PageNotFound';
import ApplicationTracking from './pages/student/ApplicationTracking';
import InterviewPrep from './pages/student/InterviewPrep';
import JobListings from './pages/student/JobListings';
import Notifications from './pages/student/Notifications';
import OfferLetters from './pages/student/OfferLetters';
import OnlineAssessment from './pages/student/OnlineAssessment';

import './app.css';
import Internships from './pages/student/Internships';
import InternshipDetails from './pages/student/InternshipDetails';
import JobDetails from './pages/student/JobDetails';
import Auth from './pages/Auth';

const generalRoutes = [
  { path: '/', element: <Home /> },
  { path: '/about', element: <About /> },
 
  { path: '/feedback', element: <UserFeedback /> },
 
  { path: '/pricing', element: <Pricing /> },
  { path: '/others', element: <Others /> },
  { path: '/privacy-policy', element: <PrivacyPolicy /> },
  { path: '/contact-us', element: <Contact /> },
  { path: '/terms-conditions', element: <TermsConditions /> },
  { path: '/refund-cancellation', element: <RefundPolicies /> },
  { path: '/delete-account', element: <AccountDelete /> }
];

const studentRoutes = [
  { path: '/profile', element: <Profile /> },
  { path: '/jobs', element: <JobListings /> },
  { path: '/jobs/:id', element: <JobDetails /> },
  { path: '/applications', element: <ApplicationTracking /> },
  { path: '/assessments', element: <OnlineAssessment /> },
  { path: '/interview-prep', element: <InterviewPrep /> },
  { path: '/notifications', element: <Notifications /> },
  { path: '/offers', element: <OfferLetters /> },
  { path: '/internships', element: <Internships /> },
  { path: '/internship/:id', element: <InternshipDetails /> }
];

const authRoutes = [
    { path: '/login', element: <Auth /> }
];

function Root() {
  return (
    <>
      <ScrollRestoration />
      <Routes>
        <Route element={<MainNavigationBar />}>
          {generalRoutes.map((route) => (
            <Route
              key={route.path}
              element={route.element}
              errorElement={<PageNotFound />}
              path={route.path}
            />
          ))}

          <Route element={<PublicOutlet />}>
            {studentRoutes.map((route) => (
              <Route key={route.path} element={route.element} path={route.path} />
            ))}
            {authRoutes.map((route) => (
              <Route
                key={route.path}
                element={route.element}
                errorElement={<PageNotFound />}
                path={route.path}
              />
            ))}
          </Route>

          <Route element={<PrivateOutlet />}>
            <Route element={<Notifications />} path="/notifications" />
          </Route>

          <Route element={<PageNotFound />} path="*" />
        </Route>
      </Routes>
      <Navigator />
    </>
  );
}

const router = createBrowserRouter([{ path: '*', Component: Root }]);

function App() {
  useEffect(() => {
    document.documentElement.classList.remove('dark');
    localStorage.setItem('theme', 'light');
  }, []);

  const [preloading, setPreloading] = useState(true);
  useEffect(() => {
    setTimeout(() => {
      setPreloading(false);
    }, 1000);
  }, []);

  return (
    <div>
      {preloading && <Preloader />}
      <AuthProvider>
        <DesignComponent />
        <RouterProvider router={router} />
        <Toaster
          position="top-center"
          toastOptions={{
            style: {
              color: '#fff',
              fontWeight: 600,
              background: '#302ea7'
            },
            duration: 3000
          }}
        />
      </AuthProvider>
    </div>
  );
}

export default App;
