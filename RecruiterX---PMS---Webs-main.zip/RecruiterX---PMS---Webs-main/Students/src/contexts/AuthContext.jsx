import {
  GoogleAuthProvider,
  createUserWithEmailAndPassword,
  getAuth,
  onAuthStateChanged,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signInWithPopup,
  signOut,
  updateProfile,
  GithubAuthProvider,
} from "firebase/auth";
import { getDownloadURL, getStorage, ref, uploadBytes } from "firebase/storage";
import { createContext, useContext, useEffect, useMemo, useState } from "react";
import "../firebase";
import { arrayUnion, doc, getDoc, setDoc, updateDoc } from "firebase/firestore";
import { auth, db } from "./FirebaseConfig";
import { useAlert } from "../hooks";
import { Preloader } from "../components";

const AuthContext = createContext();

export function useAuth() {
  return useContext(AuthContext);
}

export function AuthProvider({ children }) {
  const [loading, setLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState(null);
  const [isFetchingUserData, setIsFetchingUserData] = useState(true);

  useEffect(() => {

    // Fetch full user details from Firestore
    const fetchUserData = async (uid) => {
      const userDoc = await getDoc(doc(db, "users", uid));
      if (userDoc.exists()) {
        return userDoc.data();
      } else {
        throw new Error("User data not found in Firestore");
      }
    };

    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        try {
          setIsFetchingUserData(true);
          const userData = await fetchUserData(user.uid);

          setCurrentUser({
            uid: user.uid,
            email: user.email,
            displayName: user.displayName,
            photoURL: user.photoURL,
            ...userData,
          });
        } catch (error) {
          console.error("Error fetching user data:", error);
          setCurrentUser(null);
        }
      } else {
        setCurrentUser(null);
      }
      setLoading(false);
      setIsFetchingUserData(false);
    });

    return unsubscribe;
  }, []);

  async function updateSubscription(
    uid,
    price,
    razorpay_payment_id,
    promoCode
  ) {
    try {
      const currentDate = new Date();
      const expiryDate = new Date();
      expiryDate.setMonth(currentDate.getMonth() + 2);
      await updateDoc(doc(db, "users", uid), {
        isVerified: true,
        subscription: {
          expiryDate,
          promoCode,
          price,
          currentDate,
          razorpay_payment_id,
        },
      });
      useAlert("success", "Subscription updated successfully.");
      window.location.reload();
    } catch (error) {
      console.error("Error updating subscription:", error);
      useAlert("error", "Failed to update subscription.");
    }
  }

  async function signUp(email, password, userName, phoneNumber) {
    const auth = getAuth();

    await createUserWithEmailAndPassword(auth, email, password);

    // Profile Update
    await updateProfile(auth.currentUser, {
      displayName: userName,
    });

    const user = auth.currentUser;

    // Save user to Firestore
    await setDoc(doc(db, "users", user.uid), {
      name: userName,
      email: email,
      collegeName: "",
      isVerified: false,
      createdAt: new Date(),
      yearOfStudy: "",
      isLoggedIn: true,
      phoneNumber: phoneNumber,
      token: await user.getIdToken(),
      subscription: {
        expiryDate: null,
        price: null,
        paymentDate: null,
        promoCode: null,
        razorpay_payment_id: null,
      },
      lastLogin: new Date(),
    });

    setCurrentUser({
      ...user,
    });
  }

  async function forceLogoutAllDevices(email, password) {
    const auth = getAuth();

    // Sign in with email and password to verify credentials
    await signInWithEmailAndPassword(auth, email, password);

    const user = auth.currentUser;
    if (user) {
      // Update the token in Firestore to invalidate all sessions
      const userRef = doc(db, "users", user.uid);
      await updateDoc(userRef, {
        token: await user.getIdToken(true), // Refresh token
        isLoggedIn: false, // Force log out
      });

      await signOut(auth); // Log out locally

      useAlert(
        "success",
        "Logged out all devices successfully. Please log in again."
      );
    } else {
      useAlert("error", "Invalid email or password.");
    }
  }

  // Sign In With Google
  async function signInWithGoogle() {
    const auth = getAuth();
    const provider = new GoogleAuthProvider();

    await signInWithPopup(auth, provider);
  }

  // Update User Name Function
  async function updateUserName(displayName) {
    const auth = getAuth();
    await updateProfile(auth.currentUser, { displayName });
  }

  // Update Profile Image Function
  async function updateProfileImage(imageFile) {
    const auth = getAuth();
    const storage = getStorage();
    const fileRef = ref(storage, auth.currentUser.uid);
    await uploadBytes(fileRef, imageFile);
    const photoURL = await getDownloadURL(fileRef);

    await updateProfile(auth.currentUser, { photoURL });
  }

  async function logIn(email, password) {
    const auth = getAuth();

    // Attempt to log in with email and password
    await signInWithEmailAndPassword(auth, email, password);

    const user = auth.currentUser;
    if (!user) {
      throw new Error("User not found after authentication.");
    }

    const userRef = doc(db, "users", user.uid);
    const userDoc = await getDoc(userRef);

    if (userDoc.exists()) {
      const userData = userDoc.data();

      // Check if the user is already logged in
      // if (userData.isLoggedIn && !forceLogout) {
      //   useAlert("error", "You are already logged in on another device.");
      //   await signOut(auth);
      //   return { redirectToForceLogout: true };
      // }
      // Mark as logged in
      await updateDoc(userRef, {
        isLoggedIn: true,
        lastLogin: new Date(),
        // token: await user.getIdToken(true), // Refresh token
      });

      setCurrentUser({
        uid: user.uid,
        email: user.email,
        displayName: user.displayName,
        photoURL: user.photoURL,
        ...userData,
      });

      useAlert("success", "Login successful!");
      // return { redirectToForceLogout: false }; // Indicate successful login
    }
  }

  async function updateCompletedExams(uid, yearId, examId, isCompleted) {
    try {
      const userRef = doc(db, "users", uid);
      const userDoc = await getDoc(userRef);

      if (userDoc.exists()) {
        const userData = userDoc.data();
        const completedExams = userData.completedExams || [];

        // Check if the exam already exists in the array
        const examExists = completedExams.some(
          (exam) => exam.yearId === yearId && exam.examId === examId
        );

        if (examExists) {
          // If the exam exists, update its `isCompleted` status
          const updatedExams = completedExams.map((exam) => {
            if (exam.yearId === yearId && exam.examId === examId) {
              return { ...exam, isCompleted }; // Update only the status
            }
            return exam;
          });

          // Update Firestore
          await updateDoc(userRef, { completedExams: updatedExams });
        } else {
          // If the exam doesn't exist, append it to the array
          await updateDoc(userRef, {
            completedExams: arrayUnion({ yearId, examId, isCompleted }),
          });
        }
      } else {
        useAlert("error", "User not found.");
      }
    } catch (error) {
      console.error("Error updating completed exams:", error);
      useAlert("error", "Failed to update completed exams.");
    }
  }

  // Log Out Function
  async function logOut() {
    const auth = getAuth();
    const userRef = doc(db, "users", currentUser.uid);

    // Update Firestore to mark the user as logged out
    await updateDoc(userRef, { isLoggedIn: false });

    await signOut(auth);
    useAlert("success", "Logged out successfully.");
  }

  // Reset Password Function
  async function resetPassword(email) {
    const auth = getAuth();
    await sendPasswordResetEmail(auth, email);
  }

  async function login(email, password) {
    return signInWithEmailAndPassword(auth, email, password);
  }

  async function loginWithGithub() {
    const provider = new GithubAuthProvider();
    return signInWithPopup(auth, provider);
  }

  async function loginWithLinkedIn() {
    // Note: LinkedIn authentication requires additional setup with Firebase
    // This is a placeholder for LinkedIn authentication
    throw new Error('LinkedIn authentication not implemented yet');
  }

  const memoValue = useMemo(
    () => ({
      currentUser,
      signUp,
      logIn,
      logOut,
      resetPassword,
      updateUserName,
      signInWithGoogle,
      updateCompletedExams,
      updateProfileImage,
      forceLogoutAllDevices,
      updateSubscription,
      login,
      loginWithGithub,
      loginWithLinkedIn,
    }),
    [currentUser]
  );
  return (
    <AuthContext.Provider value={memoValue}>
      {" "}
      {!loading && !isFetchingUserData ? (
        children
      ) : (
        // Show preloader while fetching data
        <Preloader />
      )}
    </AuthContext.Provider>
  );
}
