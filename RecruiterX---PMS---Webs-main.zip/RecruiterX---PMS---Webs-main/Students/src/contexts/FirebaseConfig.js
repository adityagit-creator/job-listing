import { getAnalytics } from 'firebase/analytics';
import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getMessaging } from 'firebase/messaging';
import { getStorage } from 'firebase/storage';

const firebaseConfig = {
  apiKey: "AIzaSyBFLTQBGxCgTkmSVxhlzF3N6jfXepAXMRI",
  authDomain: "growto-exams.firebaseapp.com",
  projectId: "growto-exams",
  storageBucket: "growto-exams.firebasestorage.app",
  messagingSenderId: "1045432867980",
  appId: "1:1045432867980:web:f4f82b211e6d6624402fa9",
  measurementId: "G-JHCFFRCLC1"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firebase services
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);
export const analytics = getAnalytics(app);
export const messaging = getMessaging(app);
