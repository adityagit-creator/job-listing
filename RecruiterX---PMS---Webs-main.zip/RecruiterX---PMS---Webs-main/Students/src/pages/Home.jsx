/* eslint-disable jsx-a11y/no-static-element-interactions */
import { useState } from "react";
import { FaArrowRight } from "react-icons/fa";
import { Link } from "react-router-dom";

import { hero } from "../assets";
import { BasicInfo, ContactUs, Footer } from "../components";
import { MovingTextWithDiamond } from "../components/atoms/MovingText";
import StatsCard from "../components/home/StatsCard";

function Home() {
  const [imageLoaded, setImageLoaded] = useState(false);
  // const { currentUser } = useAuth();

  const features = [
    {
      title: "Talent Pool",
      description: "Access to a diverse pool of qualified candidates",
      count: "10,000+"
    },
    {
      title: "Successful Hires",
      description: "Top talent hired through our platform",
      count: "5,000+"
    },
    {
      title: "Partner Companies",
      description: "Leading companies partnered with RecruiterX",
      count: "500+"
    }
  ];

  return (
    <div
      className={` animate-reveal mt-[90px] flex flex-col items-center justify-center ${
        !imageLoaded && "hidden"
      }`}
    >
      <div className="mx-8 mt-28   flex flex-col items-center justify-center gap-2 sm:mt-2">
        <p className="font-serif page-heading my-2 text-center text-3xl font-extrabold uppercase text-black md:text-5xl dark:text-white">
          RecruiterX
          <span className="text-primary my-1   block text-center text-4xl font-extrabold drop-2xl">
            Your Talent Acquisition Partner
          </span>
        </p>
      </div>
      <div className="p-4  w-full max-w-2xl">
        <div className="w-full  p-4 bg-white rounded-xl ">
         <Link to="/login">
         <h2 className="text-xl p-3 rounded-xl font-semibold text-center text-blue-50 mb-4 bg-primary">
            Recruiter Login - Access Your Hiring Dashboard
          </h2></Link>

          <a href="https://recruiterx.web.app/" className="flex justify-center space-x-4 w-full" target="_blank" rel="noopener noreferrer">
            <button className="w-full h-12 bg-primary  rounded-lg flex items-center justify-between px-4">
              <span className="text-white">Post a Job</span>
              <FaArrowRight className="text-white" />
            </button>
            <button className="w-full h-12 bg-white border-2 border-blue-600 text-blue-600 rounded-lg flex items-center justify-between px-4">
              <span>Candidate Search</span>
              <FaArrowRight className="text-blue-600" />
            </button>
          </a>
        </div>
      </div>

      <div className="w-[90%] mt-12">
        <h1 className="text-primary text-center text-3xl font-bold mb-8">
          Streamline Your Hiring Process
        </h1>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <div key={index} className="bg-white p-6 rounded-lg sm">
              <h3 className="text-2xl font-bold text-primary mb-2">{feature.count}</h3>
              <h4 className="text-lg font-semibold mb-2">{feature.title}</h4>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="w-[90%] mt-12">
        <h1 className="text-primary text-center text-3xl font-bold mb-8">
          Comprehensive Career Resources
        </h1>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white p-6 rounded-lg sm">
            <h2 className="text-xl font-semibold mb-4">Interview Preparation</h2>
            <ul className="space-y-2">
              <li>• Mock Interviews with Industry Experts</li>
              <li>• Technical and HR Interview Guidelines</li>
              <li>• Company-Specific Interview Prep</li>
            </ul>
          </div>
          <div className="bg-white p-6 rounded-lg sm">
            <h2 className="text-xl font-semibold mb-4">Skill Development</h2>
            <ul className="space-y-2">
              <li>• Online Assessment Platform</li>
              <li>• Technical Skill Workshops</li>
              <li>• Soft Skills Training</li>
            </ul>
          </div>
        </div>
      </div>

      <div className="relative  mx-auto mt-4 aspect-[8/5] max-w-xl overflow-hidden px-4 xl:mt-8 2xl:max-w-3xl">
        <img
          alt="SchoolX Placements"
          className="hidden object-cover drop-lg"
          height={450}
          src={hero}
          width={720}
          onLoad={() => setImageLoaded(true)}
        />
      </div>

      {/* <div className="w-full">
      <QRCodeComponent currentUser={currentUser} />

      </div> */}
      <div className="bg-primary mb-16 w-full overflow-x-hidden border-y-2 border-black py-10 drop-lg dark:border-white">
        <StatsCard />
      </div>
      <BasicInfo />

      <MovingTextWithDiamond />

      <ContactUs />
      <Footer />
    </div>
  );
}

export default Home;
