export { default as About } from './About';
export { default as Home } from './Home';

export { default as PageNotFound } from './PageNotFound';
export { default as Profile } from './Profile';





