/* eslint-disable tailwindcss/no-custom-classname */

import { Footer } from "../components";

/* eslint-disable jsx-a11y/anchor-has-content */
const SchoolXExamsStory = [
  `At SchoolX Exams, we’re not just about empowering students—we’re also building a community of professionals committed to shaping the future of Tamil Nadu’s public service workforce.`,
  `Our team includes dedicated staff, teachers, lecturers, and IT professionals who bring diverse expertise to the table. Whether it’s guiding learners through a subject or developing innovative learning tools, each staff member plays a vital role in making government exam preparation accessible and effective.`,
  `By joining the SchoolX Exams platform, professionals can contribute to a movement that supports the ambitions of thousands of Tamil Nadu aspirants.`,
  `As we continue to evolve, we invite more passionate individuals to help us deliver quality content, expert guidance, and efficient study plans to every learner on their path to government success.`,
];

function About() {
  return (
    <>
      <div className="animate-reveal mx-auto flex w-[85%] flex-col items-center justify-center">
        <h1 className="page-heading">About SchoolX Exams</h1>

        <div className="card flex !w-full max-w-4xl flex-col gap-10 p-6 text-justify font-medium sm:w-3/5 sm:text-xl dark:text-red-300">
          {SchoolXExamsStory.map((para, index2) => (
            <p
              key={index2}
              className="indent-10 first-letter:text-xl sm:first-letter:text-2xl dark:text-gray-300"
            >
              {para}
            </p>
          ))}
        </div>

        <span className="mt-14 block font-semibold tracking-wide">
          Developed with
          <a
            className="cursor-pointer hover:underline"
            href="www"
            rel="noreferrer"
            target="_blank"
          >
            ❤️
          </a>
        </span>

        <div className=" mt-8 inline-flex w-full items-center justify-center">
          <hr className="bg-primary dark:bg-secondary my-8 h-1 w-64 rounded border-0" />
          <div className="bg-light dark:bg-dark absolute left-1/2 -translate-x-1/2 px-4">
            <svg
              aria-hidden="true"
              className="size-5 text-gray-700 dark:text-gray-300"
              fill="none"
              viewBox="0 0 24 27"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M14.017 18L14.017 10.609C14.017 4.905 17.748 1.039 23 0L23.995 2.151C21.563 3.068 20 5.789 20 8H24V18H14.017ZM0 18V10.609C0 4.905 3.748 1.038 9 0L9.996 2.151C7.563 3.068 6 5.789 6 8H9.983L9.983 18L0 18Z"
                fill="currentColor"
              />
            </svg>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
}

export default About;
