import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { toast } from 'react-hot-toast';
import { FaBriefcase, FaBuilding, FaGraduationCap, FaCalendar, FaRupeeSign, FaFileAlt } from 'react-icons/fa';
import { getInternshipById, submitApplication, checkApplicationStatus } from '../../services/internshipService';
import { useAuth } from '../../contexts/AuthContext';

const InternshipDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { currentUser } = useAuth();
  const [internship, setInternship] = useState(null);
  const [loading, setLoading] = useState(true);
  const [hasApplied, setHasApplied] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    fetchInternshipDetails();
  }, [id]);

  useEffect(() => {
    if (currentUser && internship) {
      checkIfApplied();
    }
  }, [currentUser, internship]);

  const fetchInternshipDetails = async () => {
    try {
      const data = await getInternshipById(id);
      if (!data) {
        toast.error('Internship not found');
        return;
      }
      setInternship(data);
    } catch (error) {
      console.error('Error fetching internship details:', error);
      toast.error('Failed to load internship details');
    } finally {
      setLoading(false);
    }
  };

  const checkIfApplied = async () => {
    try {
      const hasAlreadyApplied = await checkApplicationStatus(id, currentUser.uid);
      setHasApplied(hasAlreadyApplied);
    } catch (error) {
      console.error('Error checking application status:', error);
    }
  };

  const handleApply = async () => {
    if (!currentUser) {
      toast.error('Please login to apply');
      navigate('/login');
      return;
    }

    try {
      setSubmitting(true);
      const applicationData = {
        resume: currentUser.resume || '', // You should implement resume upload
        transcript: currentUser.transcript || '', // You should implement transcript upload
        coverLetter: '', // You could add a cover letter field in the form
      };

      await submitApplication(id, currentUser.uid, applicationData);
      setHasApplied(true);
      toast.success('Application submitted successfully!');
    } catch (error) {
      console.error('Error submitting application:', error);
      toast.error('Failed to submit application');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  if (!internship) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold text-gray-800">Internship not found</h2>
        <button
          onClick={() => navigate('/internships')}
          className="mt-4 text-indigo-600 hover:text-indigo-800"
        >
          Back to Internships
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      {/* Header Section */}
      <div className="bg-white rounded-lg md p-6 mb-6">
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 mb-2">{internship.position}</h1>
            <div className="flex items-center text-gray-600 mb-4">
              <FaBuilding className="mr-2" />
              <span>{internship.companyName}</span>
            </div>
          </div>
          <button
            onClick={handleApply}
            disabled={hasApplied || submitting}
            className={`px-6 py-2 rounded-md text-white font-medium ${
              hasApplied
                ? 'bg-green-500 cursor-not-allowed'
                : submitting
                ? 'bg-gray-400 cursor-not-allowed'
                : 'bg-indigo-600 hover:bg-indigo-700'
            }`}
          >
            {submitting ? 'Submitting...' : hasApplied ? 'Applied' : 'Apply Now'}
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
          <div className="flex items-center text-gray-600">
            <FaBriefcase className="mr-2" />
            <span>Duration: {internship.duration}</span>
          </div>
          <div className="flex items-center text-gray-600">
            <FaRupeeSign className="mr-2" />
            <span>Stipend: {internship.stipend}</span>
          </div>
          <div className="flex items-center text-gray-600">
            <FaCalendar className="mr-2" />
            <span>Apply by: {internship.deadline?.toLocaleDateString()}</span>
          </div>
          <div className="flex items-center text-gray-600">
            <FaGraduationCap className="mr-2" />
            <span>Min. CGPA: {internship.eligibility?.cgpa}</span>
          </div>
        </div>
      </div>

      {/* Details Sections */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Left Column */}
        <div className="space-y-6">
          <section className="bg-white rounded-lg md p-6">
            <h2 className="text-xl font-semibold mb-4">Description</h2>
            <p className="text-gray-700">{internship.description}</p>
          </section>

          <section className="bg-white rounded-lg md p-6">
            <h2 className="text-xl font-semibold mb-4">Requirements</h2>
            <ul className="list-disc list-inside space-y-2 text-gray-700">
              {internship.requirements?.map((req, index) => (
                <li key={index}>{req}</li>
              ))}
            </ul>
          </section>

          <section className="bg-white rounded-lg md p-6">
            <h2 className="text-xl font-semibold mb-4">Responsibilities</h2>
            <ul className="list-disc list-inside space-y-2 text-gray-700">
              {internship.responsibilities?.map((resp, index) => (
                <li key={index}>{resp}</li>
              ))}
            </ul>
          </section>
        </div>

        {/* Right Column */}
        <div className="space-y-6">
          <section className="bg-white rounded-lg md p-6">
            <h2 className="text-xl font-semibold mb-4">Eligibility</h2>
            <div className="space-y-4">
              <div>
                <h3 className="font-medium text-gray-700">Branches</h3>
                <div className="flex flex-wrap gap-2 mt-2">
                  {internship.eligibility?.branches?.map((branch) => (
                    <span
                      key={branch}
                      className="px-3 py-1 bg-gray-100 rounded-full text-sm text-gray-700"
                    >
                      {branch}
                    </span>
                  ))}
                </div>
              </div>
              <div>
                <h3 className="font-medium text-gray-700">Required Skills</h3>
                <div className="flex flex-wrap gap-2 mt-2">
                  {internship.eligibility?.skills?.map((skill) => (
                    <span
                      key={skill}
                      className="px-3 py-1 bg-indigo-100 rounded-full text-sm text-indigo-700"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
              <div>
                <h3 className="font-medium text-gray-700">Year of Passing</h3>
                <p className="mt-1 text-gray-600">{internship.eligibility?.yearOfPassing}</p>
              </div>
            </div>
          </section>

          <section className="bg-white rounded-lg md p-6">
            <h2 className="text-xl font-semibold mb-4">Perks</h2>
            <ul className="space-y-2">
              {internship.perks?.map((perk, index) => (
                <li key={index} className="flex items-center text-gray-700">
                  <span className="h-2 w-2 bg-indigo-500 rounded-full mr-2"></span>
                  {perk}
                </li>
              ))}
            </ul>
          </section>

          <section className="bg-white rounded-lg md p-6">
            <h2 className="text-xl font-semibold mb-4">Required Documents</h2>
            <div className="space-y-3">
              <div className="flex items-center text-gray-700">
                <FaFileAlt className="mr-2 text-indigo-600" />
                <span>Updated Resume</span>
              </div>
              <div className="flex items-center text-gray-700">
                <FaFileAlt className="mr-2 text-indigo-600" />
                <span>Latest Transcript</span>
              </div>
            </div>
          </section>
        </div>
      </div>

      {/* Apply Button (Bottom) */}
      <div className="mt-8 text-center">
        <button
          onClick={handleApply}
          disabled={hasApplied || submitting}
          className={`px-8 py-3 rounded-md text-white font-medium ${
            hasApplied
              ? 'bg-green-500 cursor-not-allowed'
              : submitting
              ? 'bg-gray-400 cursor-not-allowed'
              : 'bg-indigo-600 hover:bg-indigo-700'
          }`}
        >
          {submitting 
            ? 'Submitting Application...' 
            : hasApplied 
            ? 'Application Submitted' 
            : 'Apply for this Internship'}
        </button>
      </div>
    </div>
  );
};

export default InternshipDetails; 