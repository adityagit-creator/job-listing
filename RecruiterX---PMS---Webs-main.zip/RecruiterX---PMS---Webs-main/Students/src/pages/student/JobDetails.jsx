import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { toast } from 'react-hot-toast';
import { FaBriefcase, FaBuilding, FaRupeeSign, FaMapMarkerAlt, FaCalendar, FaGraduationCap, FaFileAlt } from 'react-icons/fa';
import { getJobDetails, applyForJob } from '../../services/studentService';
import { useAuth } from '../../contexts/AuthContext';

const JobDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { currentUser } = useAuth();
  const [job, setJob] = useState(null);
  const [loading, setLoading] = useState(true);
  const [applying, setApplying] = useState(false);
  const [resume, setResume] = useState(null);

  useEffect(() => {
    fetchJobDetails();
  }, [id]);

  const fetchJobDetails = async () => {
    try {
      setLoading(true);
      const data = await getJobDetails(id);
      setJob(data);
    } catch (error) {
      console.error('Error fetching job details:', error);
      toast.error('Failed to load job details');
      navigate('/jobs');
    } finally {
      setLoading(false);
    }
  };

  const handleApply = async () => {
    if (!resume) {
      toast.error('Please upload your resume');
      return;
    }

    try {
      setApplying(true);
      await applyForJob(id, currentUser.uid, resume);
      toast.success('Application submitted successfully!');
      navigate('/applications');
    } catch (error) {
      console.error('Error applying for job:', error);
      toast.error('Failed to submit application');
    } finally {
      setApplying(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  if (!job) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900">Job not found</h2>
          <p className="mt-2 text-gray-600">The job posting you're looking for doesn't exist or has been removed.</p>
          <button
            onClick={() => navigate('/jobs')}
            className="mt-4 px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700"
          >
            Back to Jobs
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      {/* Header */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">{job.title}</h1>
            <div className="flex items-center text-gray-600 mb-4">
              <FaBuilding className="mr-2" />
              <span className="text-xl">{job.companyName}</span>
            </div>
          </div>
          <button
            onClick={handleApply}
            disabled={applying || job.hasApplied}
            className={`px-6 py-3 rounded-md text-white font-semibold ${
              job.hasApplied
                ? 'bg-green-500 cursor-not-allowed'
                : applying
                ? 'bg-indigo-400 cursor-wait'
                : 'bg-indigo-600 hover:bg-indigo-700'
            }`}
          >
            {job.hasApplied ? 'Applied' : applying ? 'Applying...' : 'Apply Now'}
          </button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
          <div className="flex items-center text-gray-600">
            <FaMapMarkerAlt className="mr-2" />
            <span>{job.location}</span>
          </div>
          <div className="flex items-center text-gray-600">
            <FaBriefcase className="mr-2" />
            <span>{job.type}</span>
          </div>
          <div className="flex items-center text-gray-600">
            <FaRupeeSign className="mr-2" />
            <span>{job.package.ctc} LPA</span>
          </div>
          <div className="flex items-center text-gray-600">
            <FaCalendar className="mr-2" />
            <span>Apply by: {job.deadline?.toLocaleDateString()}</span>
          </div>
        </div>
      </div>

      {/* Job Description */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <h2 className="text-xl font-semibold mb-4">Job Description</h2>
        <div className="prose max-w-none">
          <p className="whitespace-pre-line">{job.description}</p>
        </div>
      </div>

      {/* Requirements */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <h2 className="text-xl font-semibold mb-4">Requirements</h2>
        <div className="space-y-4">
          <div className="flex items-center">
            <FaGraduationCap className="mr-2 text-gray-600" />
            <span>Eligible Branches: </span>
            <div className="ml-2 flex flex-wrap gap-2">
              {job.eligibility?.branches?.map((branch) => (
                <span
                  key={branch}
                  className="px-2 py-1 bg-gray-100 rounded-full text-sm text-gray-700"
                >
                  {branch}
                </span>
              ))}
            </div>
          </div>
          <div className="flex items-center">
            <FaGraduationCap className="mr-2 text-gray-600" />
            <span>Minimum CGPA: {job.eligibility?.minimumCGPA}</span>
          </div>
          {job.requirements && (
            <div className="mt-4">
              <ul className="list-disc list-inside space-y-2">
                {job.requirements.map((req, index) => (
                  <li key={index}>{req}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </div>

      {/* Application Section */}
      {!job.hasApplied && (
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-semibold mb-4">Submit Application</h2>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Upload Resume (PDF)
              </label>
              <div className="flex items-center space-x-4">
                <input
                  type="file"
                  accept=".pdf"
                  onChange={(e) => setResume(e.target.files[0])}
                  className="block w-full text-sm text-gray-500
                    file:mr-4 file:py-2 file:px-4
                    file:rounded-md file:border-0
                    file:text-sm file:font-semibold
                    file:bg-indigo-50 file:text-indigo-700
                    hover:file:bg-indigo-100"
                />
                {resume && (
                  <div className="flex items-center text-green-600">
                    <FaFileAlt className="mr-1" />
                    <span>Resume selected</span>
                  </div>
                )}
              </div>
            </div>
            <button
              onClick={handleApply}
              disabled={applying || !resume}
              className={`w-full px-6 py-3 rounded-md text-white font-semibold ${
                !resume
                  ? 'bg-gray-400 cursor-not-allowed'
                  : applying
                  ? 'bg-indigo-400 cursor-wait'
                  : 'bg-indigo-600 hover:bg-indigo-700'
              }`}
            >
              {applying ? 'Submitting Application...' : 'Submit Application'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default JobDetails; 