import React, { useState, useEffect } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { toast } from 'react-hot-toast';
import {
  getOfferLetters,
  updateOfferStatus
} from '../../services/studentService';
import {
  FaCheckCircle,
  FaTimesCircle,
  FaClock,
  FaDownload,
  FaBuilding
} from 'react-icons/fa';

const OfferLetters = () => {
  const { currentUser } = useAuth();
  const [offers, setOffers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (currentUser) {
      fetchOffers();
    }
  }, [currentUser]);

  const fetchOffers = async () => {
    try {
      setLoading(true);
      const offerData = await getOfferLetters(currentUser.uid);
      setOffers(offerData);
    } catch (error) {
      console.error('Error fetching offers:', error);
      toast.error('Failed to load offer letters');
    } finally {
      setLoading(false);
    }
  };

  const handleStatusUpdate = async (offerId, status) => {
    try {
      await updateOfferStatus(offerId, status);
      setOffers(prev =>
        prev.map(offer =>
          offer.id === offerId ? { ...offer, status } : offer
        )
      );
      toast.success(`Offer ${status} successfully`);
    } catch (error) {
      console.error('Error updating offer status:', error);
      toast.error('Failed to update offer status');
    }
  };

  const getStatusBadgeColor = (status) => {
    switch (status) {
      case 'accepted':
        return 'bg-green-100 text-green-800';
      case 'rejected':
        return 'bg-red-100 text-red-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold text-gray-900 mb-8">Offer Letters</h1>

      {offers.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-lg shadow">
          <FaBuilding className="mx-auto text-4xl text-gray-400 mb-4" />
          <h2 className="text-xl font-semibold text-gray-700">No Offer Letters Yet</h2>
          <p className="text-gray-500 mt-2">Keep applying! Your offers will appear here.</p>
        </div>
      ) : (
        <div className="grid gap-6">
          {offers.map((offer) => (
            <div
              key={offer.id}
              className="bg-white rounded-lg md overflow-hidden"
            >
              <div className="p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <h2 className="text-xl font-semibold text-gray-900">
                      {offer.position}
                    </h2>
                    <div className="flex items-center text-gray-600 mt-1">
                      <FaBuilding className="mr-2" />
                      <span>{offer.companyName}</span>
                    </div>
                  </div>
                  <span
                    className={`px-3 py-1 rounded-full text-sm ${getStatusBadgeColor(
                      offer.status
                    )}`}
                  >
                    {offer.status.charAt(0).toUpperCase() + offer.status.slice(1)}
                  </span>
                </div>

                <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Package Details</h3>
                    <p className="mt-1 text-gray-900">{offer.package}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Joining Date</h3>
                    <p className="mt-1 text-gray-900">
                      {new Date(offer.joiningDate).toLocaleDateString()}
                    </p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Location</h3>
                    <p className="mt-1 text-gray-900">{offer.location}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Acceptance Deadline</h3>
                    <p className="mt-1 text-gray-900">
                      {new Date(offer.acceptanceDeadline).toLocaleDateString()}
                    </p>
                  </div>
                </div>

                {offer.offerLetterUrl && (
                  <div className="mt-4">
                    <a
                      href={offer.offerLetterUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center text-indigo-600 hover:text-indigo-800"
                    >
                      <FaDownload className="mr-2" />
                      Download Offer Letter
                    </a>
                  </div>
                )}

                {offer.status === 'pending' && (
                  <div className="mt-6 flex items-center space-x-4">
                    <button
                      onClick={() => handleStatusUpdate(offer.id, 'accepted')}
                      className="flex-1 inline-flex justify-center items-center px-4 py-2 border border-transparent rounded-md sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
                    >
                      <FaCheckCircle className="mr-2" />
                      Accept Offer
                    </button>
                    <button
                      onClick={() => handleStatusUpdate(offer.id, 'rejected')}
                      className="flex-1 inline-flex justify-center items-center px-4 py-2 border border-transparent rounded-md sm text-sm font-medium text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                    >
                      <FaTimesCircle className="mr-2" />
                      Decline Offer
                    </button>
                  </div>
                )}

                {offer.status !== 'pending' && (
                  <div className="mt-6 p-4 rounded-md bg-gray-50">
                    <div className="flex items-center">
                      {offer.status === 'accepted' ? (
                        <FaCheckCircle className="text-green-500 mr-2" />
                      ) : (
                        <FaTimesCircle className="text-red-500 mr-2" />
                      )}
                      <p className="text-sm text-gray-600">
                        You have {offer.status} this offer on{' '}
                        {new Date(offer.updatedAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default OfferLetters; 