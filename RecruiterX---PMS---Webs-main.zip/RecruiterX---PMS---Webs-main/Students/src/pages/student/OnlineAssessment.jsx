import React from 'react';
import { FaCode, FaBrain, FaUserCheck, FaClock, FaExternalLinkAlt } from 'react-icons/fa';

const OnlineAssessment = () => {
  const assessments = [
    {
      id: 1,
      company: 'Tech Corp',
      type: 'Coding Test',
      platform: 'HackerRank',
      duration: '120 minutes',
      deadline: '2024-02-20 14:00',
      status: 'Pending',
      instructions: [
        'Use any programming language',
        'Multiple test cases must pass',
        'Time and space complexity matters'
      ]
    },
    {
      id: 2,
      company: 'Data Systems',
      type: 'Aptitude Test',
      platform: 'TestGorilla',
      duration: '60 minutes',
      deadline: '2024-02-18 16:00',
      status: 'Completed',
      score: '85%'
    },
    {
      id: 3,
      company: 'Cloud Tech',
      type: 'Psychometric Test',
      platform: 'SHL',
      duration: '45 minutes',
      deadline: '2024-02-25 10:00',
      status: 'Pending'
    }
  ];

  const practiceResources = [
    {
      title: 'Coding Practice',
      items: [
        { name: 'LeetCode', link: 'https://leetcode.com' },
        { name: 'HackerRank', link: 'https://hackerrank.com' },
        { name: 'CodeChef', link: 'https://codechef.com' }
      ]
    },
    {
      title: 'Aptitude Practice',
      items: [
        { name: 'IndiaBix', link: 'https://indiabix.com' },
        { name: 'TestpotPro', link: 'https://testpotpro.com' }
      ]
    },
    {
      title: 'Mock Tests',
      items: [
        { name: 'MyPerfectice', link: 'https://myperfectice.com' },
        { name: 'Placement Season', link: 'https://placementseason.com' }
      ]
    }
  ];

  const getStatusColor = (status) => {
    switch (status.toLowerCase()) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getAssessmentIcon = (type) => {
    switch (type.toLowerCase()) {
      case 'coding test':
        return <FaCode className="text-indigo-600" />;
      case 'aptitude test':
        return <FaBrain className="text-purple-600" />;
      case 'psychometric test':
        return <FaUserCheck className="text-blue-600" />;
      default:
        return null;
    }
  };

  return (
    <div>
      <div className="max-w-6xl mx-auto mt-[150px]">
        <h1 className="text-2xl font-bold mb-6">Online Assessments</h1>

        {/* Upcoming Assessments */}
        <div className="mb-8">
          <h2 className="text-lg font-semibold mb-4">Upcoming & Recent Assessments</h2>
          <div className="grid gap-4">
            {assessments.map(assessment => (
              <div key={assessment.id} className="bg-white rounded-lg sm p-6">
                <div className="flex justify-between items-start">
                  <div className="flex items-start space-x-4">
                    <div className="p-3 bg-gray-100 rounded-lg">
                      {getAssessmentIcon(assessment.type)}
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold">{assessment.company}</h3>
                      <p className="text-gray-600">{assessment.type}</p>
                      <div className="flex items-center mt-2 text-sm text-gray-500">
                        <FaClock className="mr-2" />
                        Duration: {assessment.duration}
                      </div>
                    </div>
                  </div>
                  <div>
                    <span className={`px-3 py-1 rounded-full text-sm ${getStatusColor(assessment.status)}`}>
                      {assessment.status}
                    </span>
                    {assessment.score && (
                      <p className="text-sm font-medium text-green-600 mt-2">
                        Score: {assessment.score}
                      </p>
                    )}
                  </div>
                </div>

                <div className="mt-4">
                  <p className="text-sm text-gray-600">
                    <strong>Platform:</strong> {assessment.platform}
                  </p>
                  <p className="text-sm text-gray-600">
                    <strong>Deadline:</strong> {assessment.deadline}
                  </p>
                </div>

                {assessment.instructions && (
                  <div className="mt-4">
                    <h4 className="font-medium mb-2">Instructions:</h4>
                    <ul className="list-disc list-inside text-sm text-gray-600">
                      {assessment.instructions.map((instruction, index) => (
                        <li key={index}>{instruction}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {assessment.status === 'Pending' && (
                  <button className="mt-4 px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition-colors">
                    Start Assessment
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Practice Resources */}
        <div>
          <h2 className="text-lg font-semibold mb-4">Practice Resources</h2>
          <div className="grid grid-cols-3 gap-4">
            {practiceResources.map((section, index) => (
              <div key={index} className="bg-white rounded-lg sm p-6">
                <h3 className="font-semibold mb-4">{section.title}</h3>
                <ul className="space-y-3">
                  {section.items.map((item, itemIndex) => (
                    <li key={itemIndex}>
                      <a
                        href={item.link}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center text-indigo-600 hover:text-indigo-800"
                      >
                        {item.name}
                        <FaExternalLinkAlt className="ml-2 text-sm" />
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default OnlineAssessment; 