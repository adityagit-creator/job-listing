import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-hot-toast';
import { FaBriefcase, FaBuilding, FaRupeeSign, FaMapMarkerAlt, FaCalendar, FaSearch, FaFilter } from 'react-icons/fa';
import useJobs from '../../hooks/useJobs';

const JobListings = () => {
  const navigate = useNavigate();
  const { jobs, loading, error, filters, setFilters, incrementJobViews } = useJobs();
  const [localFilters, setLocalFilters] = useState({
    search: '',
    location: ''
  });

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    
    if (name === 'branch' || name === 'type') {
      // Server-side filters
      setFilters(prev => ({
        ...prev,
        [name === 'branch' ? 'branches' : 'type']: value ? [value] : []
      }));
    } else {
      // Client-side filters
      setLocalFilters(prev => ({
        ...prev,
        [name]: value
      }));
    }
  };

  // Client-side filtering for search and location
  const filteredJobs = jobs.filter(job => {
    return (
      (localFilters.search === '' || 
        job.title.toLowerCase().includes(localFilters.search.toLowerCase()) ||
        job.companyName.toLowerCase().includes(localFilters.search.toLowerCase())) &&
      (localFilters.location === '' || job.location.toLowerCase().includes(localFilters.location.toLowerCase()))
    );
  });

  const handleJobClick = (jobId) => {
    incrementJobViews(jobId);
    navigate(`/jobs/${jobId}`);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="text-center py-12 bg-white rounded-lg shadow-md">
          <FaExclamationCircle className="mx-auto text-4xl text-red-500 mb-4" />
          <h2 className="text-xl font-semibold text-gray-700">Error loading jobs</h2>
          <p className="text-gray-500 mt-2">Please try again later</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Job Listings</h1>
          <p className="mt-1 text-gray-500">Find and apply for job opportunities</p>
        </div>
      </div>

      {/* Filters */}
      <div className="card my-3">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Search</label>
            <div className="relative">
              <FaSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                name="search"
                value={localFilters.search}
                onChange={handleFilterChange}
                placeholder="Search jobs or companies"
                className="pl-10 w-full border rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Branch</label>
            <select
              name="branch"
              value={filters.branches?.[0] || ''}
              onChange={handleFilterChange}
              className="w-full border rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="">All Branches</option>
              <option value="CSE">Computer Science</option>
              <option value="IT">Information Technology</option>
              <option value="ECE">Electronics & Communication</option>
              <option value="EEE">Electrical & Electronics</option>
              <option value="MECH">Mechanical</option>
              <option value="CIVIL">Civil</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Job Type</label>
            <select
              name="type"
              value={filters.type || ''}
              onChange={handleFilterChange}
              className="w-full border rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="">All Types</option>
              <option value="full-time">Full Time</option>
              <option value="internship">Internship</option>
              <option value="contract">Contract</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Location</label>
            <input
              type="text"
              name="location"
              value={localFilters.location}
              onChange={handleFilterChange}
              placeholder="Filter by location"
              className="w-full border rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>
        </div>
      </div>

      {/* Job Cards */}
      {filteredJobs.length === 0 ? (
        <div className="text-center py-12 card">
          <FaBriefcase className="mx-auto text-4xl text-gray-400 mb-4" />
          <h2 className="text-xl font-semibold text-gray-700">No jobs found</h2>
          <p className="text-gray-500 mt-2">Try adjusting your filters or check back later</p>
        </div>
      ) : (
        <div className="grid gap-6">
          {filteredJobs.map((job) => (
            <div
              key={job.id}
              className="card"
              onClick={() => handleJobClick(job.id)}
            >
              <div className="flex justify-between items-start">
                <div>
                  <h2 className="text-xl font-semibold text-gray-900 mb-2">
                    {job.title}
                  </h2>
                  <div className="flex items-center text-gray-600 mb-4">
                    <FaBuilding className="mr-2" />
                    <span>{job.companyName}</span>
                  </div>
                </div>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    handleJobClick(job.id);
                  }}
                  className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700"
                >
                  View Details
                </button>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="flex items-center text-gray-600">
                  <FaMapMarkerAlt className="mr-2" />
                  <span>{job.location}</span>
                </div>
                <div className="flex items-center text-gray-600">
                  <FaBriefcase className="mr-2" />
                  <span>{job.type}</span>
                </div>
                <div className="flex items-center text-gray-600">
                  <FaRupeeSign className="mr-2" />
                  <span>{job.package?.ctc} LPA</span>
                </div>
                <div className="flex items-center text-gray-600">
                  <FaCalendar className="mr-2" />
                  <span>Apply by: {job.deadline?.toLocaleDateString()}</span>
                </div>
              </div>

              {job.eligibility && (
                <div className="mt-4">
                  <div className="flex flex-wrap gap-2">
                    {job.eligibility.branches?.map((branch) => (
                      <span
                        key={branch}
                        className="px-2 py-1 bg-gray-100 rounded-full text-sm text-gray-700"
                      >
                        {branch}
                      </span>
                    ))}
                    <span className="px-2 py-1 bg-indigo-100 rounded-full text-sm text-indigo-700">
                      Min CGPA: {job.eligibility.minimumCGPA}
                    </span>
                  </div>
                </div>
              )}

              {job.applicationStats && (
                <div className="mt-4 text-sm text-gray-500">
                  {job.applicationStats.views} views • {job.applicationStats.applications} applications
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default JobListings;
