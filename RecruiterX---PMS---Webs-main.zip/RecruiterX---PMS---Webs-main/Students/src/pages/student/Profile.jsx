import React, { useState, useEffect } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { toast } from 'react-hot-toast';
import {
  FaLinkedin,
  FaGithub,
  FaFileUpload,
  FaWhatsapp,
  FaUser,
  FaGraduationCap,
  FaBriefcase,
  FaCode
} from 'react-icons/fa';
import {
  getStudentProfile,
  updateStudentProfile,
  uploadDocument,
  parseResume,
  importLinkedInProfile,
  importGitHubProfile,
  enableWhatsAppNotifications
} from '../../services/profileService';

const Profile = () => {
  const { currentUser } = useAuth();
  const [loading, setLoading] = useState(true);
  const [profile, setProfile] = useState({
    personalInfo: {
      name: '',
      email: '',
      phone: '',
      rollNumber: '',
      branch: '',
      semester: '',
      cgpa: ''
    },
    education: [],
    experience: [],
    skills: [],
    projects: [],
    certifications: [],
    documents: {
      resume: null,
      transcript: null
    },
    preferences: {
      whatsappEnabled: false,
      whatsappPhone: ''
    }
  });
  const [editMode, setEditMode] = useState(false);

  useEffect(() => {
    if (currentUser) {
      fetchProfile();
    }
  }, [currentUser]);

  const fetchProfile = async () => {
    try {
      setLoading(true);
      const data = await getStudentProfile(currentUser.uid);
      if (data) {
        setProfile(data);
      }
    } catch (error) {
      console.error('Error fetching profile:', error);
      toast.error('Failed to load profile');
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (section, field, value) => {
    setProfile(prev => ({
      ...prev,
      [section]: {
        ...prev[section],
        [field]: value
      }
    }));
  };

  const handleArrayInputChange = (section, index, field, value) => {
    setProfile(prev => ({
      ...prev,
      [section]: prev[section].map((item, i) =>
        i === index ? { ...item, [field]: value } : item
      )
    }));
  };

  const handleAddItem = (section) => {
    setProfile(prev => ({
      ...prev,
      [section]: [...prev[section], {}]
    }));
  };

  const handleRemoveItem = (section, index) => {
    setProfile(prev => ({
      ...prev,
      [section]: prev[section].filter((_, i) => i !== index)
    }));
  };

  const handleSave = async () => {
    try {
      setLoading(true);
      await updateStudentProfile(currentUser.uid, profile);
      setEditMode(false);
      toast.success('Profile updated successfully');
    } catch (error) {
      console.error('Error updating profile:', error);
      toast.error('Failed to update profile');
    } finally {
      setLoading(false);
    }
  };

  const handleResumeUpload = async (event) => {
    try {
      const file = event.target.files[0];
      if (!file) return;

      setLoading(true);
      const parsedData = await parseResume(currentUser.uid, file);
      
      setProfile(prev => ({
        ...prev,
        ...parsedData,
        documents: {
          ...prev.documents,
          resume: file.name
        }
      }));
      
      toast.success('Resume uploaded and parsed successfully');
    } catch (error) {
      console.error('Error uploading resume:', error);
      toast.error('Failed to upload resume');
    } finally {
      setLoading(false);
    }
  };

  const handleLinkedInImport = async () => {
    try {
      setLoading(true);
      // Here you would implement LinkedIn OAuth flow
      const accessToken = 'dummy-token';
      const linkedInData = await importLinkedInProfile(currentUser.uid, accessToken);
      
      setProfile(prev => ({
        ...prev,
        ...linkedInData
      }));
      
      toast.success('LinkedIn profile imported successfully');
    } catch (error) {
      console.error('Error importing LinkedIn profile:', error);
      toast.error('Failed to import LinkedIn profile');
    } finally {
      setLoading(false);
    }
  };

  const handleGitHubImport = async () => {
    try {
      setLoading(true);
      // Here you would implement GitHub OAuth flow
      const accessToken = 'dummy-token';
      const githubData = await importGitHubProfile(currentUser.uid, accessToken);
      
      setProfile(prev => ({
        ...prev,
        ...githubData
      }));
      
      toast.success('GitHub profile imported successfully');
    } catch (error) {
      console.error('Error importing GitHub profile:', error);
      toast.error('Failed to import GitHub profile');
    } finally {
      setLoading(false);
    }
  };

  const handleWhatsAppEnable = async () => {
    try {
      setLoading(true);
      await enableWhatsAppNotifications(currentUser.uid, profile.personalInfo.phone);
      
      setProfile(prev => ({
        ...prev,
        preferences: {
          ...prev.preferences,
          whatsappEnabled: true,
          whatsappPhone: profile.personalInfo.phone
        }
      }));
      
      toast.success('WhatsApp notifications enabled successfully');
    } catch (error) {
      console.error('Error enabling WhatsApp:', error);
      toast.error('Failed to enable WhatsApp notifications');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      {/* Header */}
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Student Profile</h1>
        <div className="flex space-x-4">
          {editMode ? (
            <>
              <button
                onClick={handleSave}
                className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700"
              >
                Save Changes
              </button>
              <button
                onClick={() => setEditMode(false)}
                className="px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-50"
              >
                Cancel
              </button>
            </>
          ) : (
            <button
              onClick={() => setEditMode(true)}
              className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700"
            >
              Edit Profile
            </button>
          )}
        </div>
      </div>

      {/* Import Options */}
      <div className="bg-white rounded-lg md p-6 mb-6">
        <h2 className="text-lg font-semibold mb-4">Import Profile Data</h2>
        <div className="flex flex-wrap gap-4">
          <div>
            <input
              type="file"
              id="resume-upload"
              accept=".pdf,.doc,.docx"
              className="hidden"
              onChange={handleResumeUpload}
            />
            <label
              htmlFor="resume-upload"
              className="flex items-center px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-50 cursor-pointer"
            >
              <FaFileUpload className="mr-2" />
              Upload Resume
            </label>
          </div>
          <button
            onClick={handleLinkedInImport}
            className="flex items-center px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-50"
          >
            <FaLinkedin className="mr-2 text-blue-600" />
            Import from LinkedIn
          </button>
          <button
            onClick={handleGitHubImport}
            className="flex items-center px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-50"
          >
            <FaGithub className="mr-2" />
            Import from GitHub
          </button>
        </div>
      </div>

      {/* Personal Information */}
      <div className="bg-white rounded-lg md p-6 mb-6">
        <div className="flex items-center mb-4">
          <FaUser className="text-indigo-600 mr-2" />
          <h2 className="text-lg font-semibold">Personal Information</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">Name</label>
            <input
              type="text"
              value={profile.personalInfo.name}
              onChange={(e) => handleInputChange('personalInfo', 'name', e.target.value)}
              disabled={!editMode}
              className="mt-1 block w-full rounded-md border-gray-300 sm focus:border-indigo-500 focus:ring-indigo-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Email</label>
            <input
              type="email"
              value={profile.personalInfo.email}
              onChange={(e) => handleInputChange('personalInfo', 'email', e.target.value)}
              disabled={!editMode}
              className="mt-1 block w-full rounded-md border-gray-300 sm focus:border-indigo-500 focus:ring-indigo-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Phone</label>
            <input
              type="tel"
              value={profile.personalInfo.phone}
              onChange={(e) => handleInputChange('personalInfo', 'phone', e.target.value)}
              disabled={!editMode}
              className="mt-1 block w-full rounded-md border-gray-300 sm focus:border-indigo-500 focus:ring-indigo-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Roll Number</label>
            <input
              type="text"
              value={profile.personalInfo.rollNumber}
              onChange={(e) => handleInputChange('personalInfo', 'rollNumber', e.target.value)}
              disabled={!editMode}
              className="mt-1 block w-full rounded-md border-gray-300 sm focus:border-indigo-500 focus:ring-indigo-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Branch</label>
            <select
              value={profile.personalInfo.branch}
              onChange={(e) => handleInputChange('personalInfo', 'branch', e.target.value)}
              disabled={!editMode}
              className="mt-1 block w-full rounded-md border-gray-300 sm focus:border-indigo-500 focus:ring-indigo-500"
            >
              <option value="">Select Branch</option>
              <option value="CSE">Computer Science</option>
              <option value="IT">Information Technology</option>
              <option value="ECE">Electronics</option>
              <option value="ME">Mechanical</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">CGPA</label>
            <input
              type="number"
              step="0.01"
              min="0"
              max="10"
              value={profile.personalInfo.cgpa}
              onChange={(e) => handleInputChange('personalInfo', 'cgpa', e.target.value)}
              disabled={!editMode}
              className="mt-1 block w-full rounded-md border-gray-300 sm focus:border-indigo-500 focus:ring-indigo-500"
            />
          </div>
        </div>
      </div>

      {/* Education */}
      <div className="bg-white rounded-lg md p-6 mb-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center">
            <FaGraduationCap className="text-indigo-600 mr-2" />
            <h2 className="text-lg font-semibold">Education</h2>
          </div>
          {editMode && (
            <button
              onClick={() => handleAddItem('education')}
              className="text-indigo-600 hover:text-indigo-800"
            >
              + Add Education
            </button>
          )}
        </div>
        {profile.education.map((edu, index) => (
          <div key={index} className="mb-4 p-4 border rounded-lg">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Institution</label>
                <input
                  type="text"
                  value={edu.institution}
                  onChange={(e) => handleArrayInputChange('education', index, 'institution', e.target.value)}
                  disabled={!editMode}
                  className="mt-1 block w-full rounded-md border-gray-300 sm focus:border-indigo-500 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Degree</label>
                <input
                  type="text"
                  value={edu.degree}
                  onChange={(e) => handleArrayInputChange('education', index, 'degree', e.target.value)}
                  disabled={!editMode}
                  className="mt-1 block w-full rounded-md border-gray-300 sm focus:border-indigo-500 focus:ring-indigo-500"
                />
              </div>
            </div>
            {editMode && (
              <button
                onClick={() => handleRemoveItem('education', index)}
                className="mt-2 text-red-600 hover:text-red-800"
              >
                Remove
              </button>
            )}
          </div>
        ))}
      </div>

      {/* Experience */}
      <div className="bg-white rounded-lg md p-6 mb-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center">
            <FaBriefcase className="text-indigo-600 mr-2" />
            <h2 className="text-lg font-semibold">Experience</h2>
          </div>
          {editMode && (
            <button
              onClick={() => handleAddItem('experience')}
              className="text-indigo-600 hover:text-indigo-800"
            >
              + Add Experience
            </button>
          )}
        </div>
        {profile.experience.map((exp, index) => (
          <div key={index} className="mb-4 p-4 border rounded-lg">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Company</label>
                <input
                  type="text"
                  value={exp.company}
                  onChange={(e) => handleArrayInputChange('experience', index, 'company', e.target.value)}
                  disabled={!editMode}
                  className="mt-1 block w-full rounded-md border-gray-300 sm focus:border-indigo-500 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Position</label>
                <input
                  type="text"
                  value={exp.position}
                  onChange={(e) => handleArrayInputChange('experience', index, 'position', e.target.value)}
                  disabled={!editMode}
                  className="mt-1 block w-full rounded-md border-gray-300 sm focus:border-indigo-500 focus:ring-indigo-500"
                />
              </div>
            </div>
            {editMode && (
              <button
                onClick={() => handleRemoveItem('experience', index)}
                className="mt-2 text-red-600 hover:text-red-800"
              >
                Remove
              </button>
            )}
          </div>
        ))}
      </div>

      {/* Skills */}
      <div className="bg-white rounded-lg md p-6 mb-6">
        <div className="flex items-center mb-4">
          <FaCode className="text-indigo-600 mr-2" />
          <h2 className="text-lg font-semibold">Skills</h2>
        </div>
        <div className="flex flex-wrap gap-2">
          {profile.skills.map((skill, index) => (
            <div
              key={index}
              className="px-3 py-1 bg-gray-100 rounded-full text-sm text-gray-700 flex items-center"
            >
              {skill}
              {editMode && (
                <button
                  onClick={() => handleRemoveItem('skills', index)}
                  className="ml-2 text-red-600 hover:text-red-800"
                >
                  ×
                </button>
              )}
            </div>
          ))}
          {editMode && (
            <button
              onClick={() => handleAddItem('skills')}
              className="px-3 py-1 border border-dashed border-gray-300 rounded-full text-sm text-gray-600 hover:border-gray-400"
            >
              + Add Skill
            </button>
          )}
        </div>
      </div>

      {/* WhatsApp Notifications */}
      <div className="bg-white rounded-lg md p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <FaWhatsapp className="text-green-500 mr-2" />
            <h2 className="text-lg font-semibold">WhatsApp Notifications</h2>
          </div>
          {!profile.preferences.whatsappEnabled && (
            <button
              onClick={handleWhatsAppEnable}
              className="px-4 py-2 bg-green-500 text-white rounded-md hover:bg-green-600"
            >
              Enable WhatsApp Alerts
            </button>
          )}
        </div>
        {profile.preferences.whatsappEnabled && (
          <p className="mt-2 text-sm text-gray-600">
            WhatsApp notifications are enabled for {profile.preferences.whatsappPhone}
          </p>
        )}
      </div>
    </div>
  );
};

export default Profile; 