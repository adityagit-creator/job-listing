import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import {
  getStudentDashboardStats,
  getStudentApplications,
  getOfferLetters,
  getStudentNotifications,
  markNotificationAsRead
} from '../../services/studentService';
import {
  FaBriefcase,
  FaCheckCircle,
  FaClock,
  FaFileAlt,
  FaBell,
  FaChartLine
} from 'react-icons/fa';

const Dashboard = () => {
  const navigate = useNavigate();
  const { currentUser } = useAuth();
  const [stats, setStats] = useState(null);
  const [applications, setApplications] = useState([]);
  const [offers, setOffers] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (currentUser) {
      fetchDashboardData();
    }
  }, [currentUser]);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      const [dashboardStats, recentApplications, activeOffers, userNotifications] = await Promise.all([
        getStudentDashboardStats(currentUser.uid),
        getStudentApplications(currentUser.uid),
        getOfferLetters(currentUser.uid),
        getStudentNotifications(currentUser.uid)
      ]);

      setStats(dashboardStats);
      setApplications(recentApplications.slice(0, 5)); // Show only 5 recent applications
      setOffers(activeOffers.filter(offer => offer.status === 'pending'));
      setNotifications(userNotifications.filter(notif => !notif.read).slice(0, 5));
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleNotificationClick = async (notificationId) => {
    try {
      await markNotificationAsRead(notificationId);
      setNotifications(prev => prev.filter(n => n.id !== notificationId));
    } catch (error) {
      console.error('Error marking notification as read:', error);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold text-gray-900 mb-8">Student Dashboard</h1>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <FaChartLine className="text-indigo-600 text-2xl mr-4" />
            <div>
              <p className="text-gray-600">Total Applications</p>
              <p className="text-2xl font-semibold">{stats?.totalApplications || 0}</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <FaClock className="text-yellow-500 text-2xl mr-4" />
            <div>
              <p className="text-gray-600">Pending Applications</p>
              <p className="text-2xl font-semibold">{stats?.pendingApplications || 0}</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <FaCheckCircle className="text-green-500 text-2xl mr-4" />
            <div>
              <p className="text-gray-600">Shortlisted</p>
              <p className="text-2xl font-semibold">{stats?.shortlistedApplications || 0}</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <FaFileAlt className="text-blue-500 text-2xl mr-4" />
            <div>
              <p className="text-gray-600">Active Offers</p>
              <p className="text-2xl font-semibold">{stats?.activeOffers || 0}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Recent Applications */}
        <div className="bg-white rounded-lg shadow">
          <div className="p-6 border-b">
            <h2 className="text-xl font-semibold">Recent Applications</h2>
          </div>
          <div className="p-6">
            {applications.length > 0 ? (
              <div className="space-y-4">
                {applications.map((application) => (
                  <div
                    key={application.id}
                    className="flex items-center justify-between p-4 hover:bg-gray-50 rounded-lg cursor-pointer"
                    onClick={() => navigate(`/applications/${application.id}`)}
                  >
                    <div>
                      <h3 className="font-medium">{application.position}</h3>
                      <p className="text-sm text-gray-600">{application.companyName}</p>
                    </div>
                    <span className={`px-3 py-1 rounded-full text-sm ${
                      application.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                      application.status === 'shortlisted' ? 'bg-green-100 text-green-800' :
                      'bg-red-100 text-red-800'
                    }`}>
                      {application.status.charAt(0).toUpperCase() + application.status.slice(1)}
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-500 text-center py-4">No recent applications</p>
            )}
          </div>
        </div>

        {/* Notifications & Offers */}
        <div className="space-y-8">
          {/* Pending Offers */}
          <div className="bg-white rounded-lg shadow">
            <div className="p-6 border-b">
              <h2 className="text-xl font-semibold">Pending Offers</h2>
            </div>
            <div className="p-6">
              {offers.length > 0 ? (
                <div className="space-y-4">
                  {offers.map((offer) => (
                    <div
                      key={offer.id}
                      className="flex items-center justify-between p-4 hover:bg-gray-50 rounded-lg cursor-pointer"
                      onClick={() => navigate(`/offers/${offer.id}`)}
                    >
                      <div>
                        <h3 className="font-medium">{offer.position}</h3>
                        <p className="text-sm text-gray-600">{offer.companyName}</p>
                      </div>
                      <span className="text-sm text-gray-600">
                        Expires: {offer.acceptanceDeadline.toLocaleDateString()}
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-gray-500 text-center py-4">No pending offers</p>
              )}
            </div>
          </div>

          {/* Notifications */}
          <div className="bg-white rounded-lg shadow">
            <div className="p-6 border-b">
              <h2 className="text-xl font-semibold">Recent Notifications</h2>
            </div>
            <div className="p-6">
              {notifications.length > 0 ? (
                <div className="space-y-4">
                  {notifications.map((notification) => (
                    <div
                      key={notification.id}
                      className="flex items-center p-4 hover:bg-gray-50 rounded-lg cursor-pointer"
                      onClick={() => handleNotificationClick(notification.id)}
                    >
                      <FaBell className="text-indigo-600 mr-4" />
                      <div>
                        <p className="font-medium">{notification.title}</p>
                        <p className="text-sm text-gray-600">{notification.message}</p>
                        <p className="text-xs text-gray-500 mt-1">
                          {notification.createdAt.toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-gray-500 text-center py-4">No new notifications</p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard; 