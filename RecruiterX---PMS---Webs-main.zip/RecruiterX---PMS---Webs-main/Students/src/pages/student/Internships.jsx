import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { FaBriefcase, FaBuilding, FaRupeeSign, FaMapMarkerAlt, FaCalendar } from 'react-icons/fa';
import { getAllInternships, filterInternships } from '../../services/internshipService';
import { toast } from 'react-hot-toast';

const Internships = () => {
  const navigate = useNavigate();
  const [internships, setInternships] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    search: '',
    branch: '',
    location: '',
    duration: '',
  });

  useEffect(() => {
    fetchInternships();
  }, []);

  const fetchInternships = async () => {
    try {
      setLoading(true);
      const data = await getAllInternships();
      setInternships(data);
    } catch (error) {
      console.error('Error fetching internships:', error);
      toast.error('Failed to load internships');
    } finally {
      setLoading(false);
    }
  };

  const handleFilterChange = async (e) => {
    const { name, value } = e.target;
    const newFilters = {
      ...filters,
      [name]: value
    };
    setFilters(newFilters);

    // Only apply server-side filtering for branch and duration
    if (name === 'branch' || name === 'duration') {
      try {
        setLoading(true);
        const filteredData = await filterInternships({
          branch: newFilters.branch,
          duration: newFilters.duration
        });
        setInternships(filteredData);
      } catch (error) {
        console.error('Error filtering internships:', error);
        toast.error('Failed to filter internships');
      } finally {
        setLoading(false);
      }
    }
  };

  // Client-side filtering for search and location
  const filteredInternships = internships.filter(internship => {
    return (
      (filters.search === '' || 
        internship.position.toLowerCase().includes(filters.search.toLowerCase()) ||
        internship.companyName.toLowerCase().includes(filters.search.toLowerCase())) &&
      (filters.location === '' || internship.location.toLowerCase().includes(filters.location.toLowerCase()))
    );
  });

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Available Internships</h1>
        <div className="flex space-x-2">
          <select
            name="branch"
            value={filters.branch}
            onChange={handleFilterChange}
            className="border rounded-md px-3 py-2 text-gray-700"
          >
            <option value="">All Branches</option>
            <option value="CSE">CSE</option>
            <option value="IT">IT</option>
            <option value="ECE">ECE</option>
            <option value="Design">Design</option>
          </select>
          <select
            name="duration"
            value={filters.duration}
            onChange={handleFilterChange}
            className="border rounded-md px-3 py-2 text-gray-700"
          >
            <option value="">All Durations</option>
            <option value="3 months">3 months</option>
            <option value="6 months">6 months</option>
          </select>
        </div>
      </div>

      {/* Search Bar */}
      <div className="mb-6">
        <input
          type="text"
          name="search"
          value={filters.search}
          onChange={handleFilterChange}
          placeholder="Search by position or company..."
          className="w-full border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500"
        />
      </div>

      {/* Internship Cards */}
      <div className="grid grid-cols-1 gap-6">
        {filteredInternships.map((internship) => (
          <div
            key={internship.id}
            className="bg-white rounded-lg md hover:lg transition-shadow duration-200"
          >
            <div className="p-6">
              <div className="flex justify-between items-start">
                <div>
                  <h2 className="text-xl font-semibold text-gray-900 mb-2">
                    {internship.position}
                  </h2>
                  <div className="flex items-center text-gray-600 mb-4">
                    <FaBuilding className="mr-2" />
                    <span>{internship.companyName}</span>
                  </div>
                </div>
                <button
                  onClick={() => navigate(`/internship/${internship.id}`)}
                  className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition-colors"
                >
                  View Details
                </button>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
                <div className="flex items-center text-gray-600">
                  <FaMapMarkerAlt className="mr-2" />
                  <span>{internship.location}</span>
                </div>
                <div className="flex items-center text-gray-600">
                  <FaBriefcase className="mr-2" />
                  <span>{internship.duration}</span>
                </div>
                <div className="flex items-center text-gray-600">
                  <FaRupeeSign className="mr-2" />
                  <span>{internship.stipend}</span>
                </div>
                <div className="flex items-center text-gray-600">
                  <FaCalendar className="mr-2" />
                  <span>Apply by: {internship.deadline?.toLocaleDateString()}</span>
                </div>
              </div>

              <div className="mt-4">
                <div className="flex flex-wrap gap-2">
                  {internship.eligibility?.branches?.map((branch) => (
                    <span
                      key={branch}
                      className="px-2 py-1 bg-gray-100 rounded-full text-sm text-gray-700"
                    >
                      {branch}
                    </span>
                  ))}
                  <span className="px-2 py-1 bg-indigo-100 rounded-full text-sm text-indigo-700">
                    Min CGPA: {internship.eligibility?.cgpa}
                  </span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredInternships.length === 0 && (
        <div className="text-center py-12">
          <h2 className="text-xl font-semibold text-gray-700">No internships found</h2>
          <p className="text-gray-500 mt-2">Try adjusting your filters</p>
        </div>
      )}
    </div>
  );
};

export default Internships; 