import React from 'react';
import { useNavigate } from 'react-router-dom';
import { FaBell, FaCheck, FaClock, FaBriefcase, FaGraduationCap, FaCalendar, FaExclamationCircle } from 'react-icons/fa';
import useNotifications from '../../hooks/useNotifications';

const NotificationIcon = ({ type }) => {
  switch (type) {
    case 'application_submitted':
      return <FaBriefcase className="text-indigo-500" />;
    case 'application_status':
      return <FaCheck className="text-green-500" />;
    case 'interview_scheduled':
      return <FaCalendar className="text-blue-500" />;
    case 'offer_received':
      return <FaGraduationCap className="text-purple-500" />;
    default:
      return <FaBell className="text-gray-500" />;
  }
};

const Notifications = () => {
  const navigate = useNavigate();
  const { notifications, loading, error, markNotificationAsRead } = useNotifications();

  const handleNotificationClick = (notification) => {
    if (!notification.read) {
      markNotificationAsRead(notification.id);
    }

    // Navigate based on notification type
    switch (notification.type) {
      case 'application_submitted':
      case 'application_status':
        navigate('/applications');
        break;
      case 'interview_scheduled':
        navigate('/interview-prep');
        break;
      case 'offer_received':
        navigate('/offers');
        break;
      default:
        break;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="text-center py-12 bg-white rounded-lg shadow-md">
          <FaExclamationCircle className="mx-auto text-4xl text-red-500 mb-4" />
          <h2 className="text-xl font-semibold text-gray-700">Error loading notifications</h2>
          <p className="text-gray-500 mt-2">Please try again later</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Notifications</h1>
          <p className="mt-1 text-gray-500">Stay updated with your placement activities</p>
        </div>
      </div>

      {notifications.length === 0 ? (
        <div className="bg-white rounded-lg shadow-md p-6 text-center">
          <FaBell className="mx-auto text-4xl text-gray-400 mb-4" />
          <h2 className="text-xl font-semibold text-gray-700">No notifications yet</h2>
          <p className="text-gray-500 mt-2">We'll notify you when there are updates</p>
        </div>
      ) : (
        <div className="space-y-4">
          {notifications.map((notification) => (
            <div
              key={notification.id}
              onClick={() => handleNotificationClick(notification)}
              className={`bg-white rounded-lg shadow-md p-6 cursor-pointer transition-all duration-200 
                ${!notification.read ? 'border-l-4 border-indigo-500' : ''}
                hover:shadow-lg`}
            >
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0">
                  <NotificationIcon type={notification.type} />
                </div>
                <div className="flex-grow">
                  <h3 className={`text-lg font-semibold ${!notification.read ? 'text-gray-900' : 'text-gray-700'}`}>
                    {notification.title}
                  </h3>
                  <p className={`mt-1 ${!notification.read ? 'text-gray-800' : 'text-gray-600'}`}>
                    {notification.message}
                  </p>
                  <div className="mt-2 flex items-center text-sm text-gray-500">
                    <FaClock className="mr-1" />
                    <span>
                      {notification.createdAt.toLocaleDateString()} at{' '}
                      {notification.createdAt.toLocaleTimeString()}
                    </span>
                  </div>
                </div>
                {!notification.read && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      markNotificationAsRead(notification.id);
                    }}
                    className="flex-shrink-0 text-indigo-600 hover:text-indigo-700"
                  >
                    Mark as read
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Notifications; 