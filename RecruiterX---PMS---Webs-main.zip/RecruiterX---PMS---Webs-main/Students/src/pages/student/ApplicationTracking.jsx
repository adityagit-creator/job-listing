import React, { useState, useEffect } from 'react';
import { toast } from 'react-hot-toast';
import { FaBuilding, FaCalendar, FaFileAlt, FaSpinner } from 'react-icons/fa';
import { useNavigate } from 'react-router-dom';

import { useAuth } from '../../contexts/AuthContext';
import { getStudentApplications } from '../../services/studentService';

const ApplicationStatus = ({ status }) => {
  const getStatusColor = () => {
    switch (status.toLowerCase()) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'shortlisted':
        return 'bg-blue-100 text-blue-800';
      case 'rejected':
        return 'bg-red-100 text-red-800';
      case 'accepted':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <span className={`rounded-full px-3 py-1 text-sm font-medium ${getStatusColor()}`}>
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </span>
  );
};

const ApplicationTracking = () => {
  const navigate = useNavigate();
  const { currentUser } = useAuth();
  const [applications, setApplications] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchApplications();
  }, []);

  const fetchApplications = async () => {
    try {
      setLoading(true);
      const data = await getStudentApplications(currentUser.uid);
      setApplications(data);
    } catch (error) {
      console.error('Error fetching applications:', error);
      toast.error('Failed to load applications');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center ">
        <div className="size-12 animate-spin rounded-full border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  return (
    <div className="mx-auto mt-[80px] max-w-7xl px-4 py-8">
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">My Applications</h1>
      </div>

      {applications.length === 0 ? (
        <div className="rounded-lg bg-white p-6 text-center shadow-md">
          <h2 className="mb-2 text-xl font-semibold text-gray-700">No applications yet</h2>
          <p className="mb-4 text-gray-600">
            Start exploring job opportunities and submit your applications.
          </p>
          <button
            className="rounded-md bg-indigo-600 px-4 py-2 text-white hover:bg-indigo-700"
            onClick={() => navigate('/jobs')}
          >
            Browse Jobs
          </button>
        </div>
      ) : (
        <div className="grid gap-6">
          {applications.map((application) => (
            <div
              key={application.id}
              className="rounded-lg bg-white p-6 shadow-md transition-shadow duration-200 hover:shadow-lg"
            >
              <div className="mb-4 flex flex-col items-start justify-between md:flex-row md:items-center">
                <div>
                  <h2 className="mb-2 text-xl font-semibold text-gray-900">
                    {application.jobTitle}
                  </h2>
                  <div className="mb-2 flex items-center text-gray-600">
                    <FaBuilding className="mr-2" />
                    <span>{application.companyName}</span>
                  </div>
                </div>
                <ApplicationStatus status={application.status} />
              </div>

              <div className="mb-4 grid grid-cols-1 gap-4 md:grid-cols-3">
                <div className="flex items-center text-gray-600">
                  <FaCalendar className="mr-2" />
                  <span>Applied: {application.appliedAt.toLocaleDateString()}</span>
                </div>
                {application.updatedAt && application.updatedAt !== application.appliedAt && (
                  <div className="flex items-center text-gray-600">
                    <FaCalendar className="mr-2" />
                    <span>Last Update: {application.updatedAt.toLocaleDateString()}</span>
                  </div>
                )}
                <div className="flex items-center text-gray-600">
                  <FaFileAlt className="mr-2" />
                  <a
                    className="text-indigo-600 hover:text-indigo-700"
                    href={application.resumeUrl}
                    rel="noopener noreferrer"
                    target="_blank"
                  >
                    View Resume
                  </a>
                </div>
              </div>

              {application.feedback && (
                <div className="mt-4 rounded-md bg-gray-50 p-4">
                  <h3 className="mb-2 font-semibold text-gray-900">Feedback</h3>
                  <p className="text-gray-700">{application.feedback}</p>
                </div>
              )}

              {application.nextSteps && (
                <div className="mt-4 rounded-md bg-blue-50 p-4">
                  <h3 className="mb-2 font-semibold text-blue-900">Next Steps</h3>
                  <p className="text-blue-700">{application.nextSteps}</p>
                </div>
              )}

              <div className="mt-4">
                <button
                  className="font-medium text-indigo-600 hover:text-indigo-700"
                  onClick={() => navigate(`/jobs/${application.jobId}`)}
                >
                  View Job Details
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default ApplicationTracking;
