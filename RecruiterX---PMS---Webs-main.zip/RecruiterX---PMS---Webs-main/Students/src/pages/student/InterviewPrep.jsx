import React from 'react';
import { FaVideo, FaBook, FaLaptopCode, FaUserTie, FaCalendarAlt, FaExternalLinkAlt } from 'react-icons/fa';

const InterviewPrep = () => {
  const mockInterviews = [
    {
      id: 1,
      type: 'Technical Interview',
      interviewer: 'John Smith',
      date: '2024-02-20',
      time: '14:00',
      duration: '45 minutes',
      topics: ['Data Structures', 'Algorithms', 'System Design'],
      status: 'Scheduled'
    },
    {
      id: 2,
      type: 'HR Interview',
      interviewer: 'Sarah Johnson',
      date: '2024-02-22',
      time: '15:30',
      duration: '30 minutes',
      topics: ['Behavioral Questions', 'Company Culture', 'Career Goals'],
      status: 'Pending'
    }
  ];

  const learningResources = [
    {
      title: 'Technical Interview Prep',
      icon: <FaLaptopCode className="text-2xl text-indigo-600" />,
      resources: [
        {
          name: 'System Design Primer',
          link: 'https://github.com/donnemartin/system-design-primer'
        },
        {
          name: 'LeetCode Patterns',
          link: 'https://leetcode.com/discuss/general-discussion/460599/blind-75-leetcode-questions'
        },
        {
          name: 'Design Patterns',
          link: 'https://refactoring.guru/design-patterns'
        }
      ]
    },
    {
      title: 'HR Interview Prep',
      icon: <FaUserTie className="text-2xl text-purple-600" />,
      resources: [
        {
          name: 'Common HR Questions',
          link: 'https://www.glassdoor.com/blog/common-interview-questions/'
        },
        {
          name: 'STAR Method Guide',
          link: 'https://www.themuse.com/advice/star-interview-method'
        },
        {
          name: 'Salary Negotiation Tips',
          link: 'https://www.levels.fyi/blog/salary-negotiation-tips.html'
        }
      ]
    },
    {
      title: 'Mock Interview Platforms',
      icon: <FaVideo className="text-2xl text-green-600" />,
      resources: [
        {
          name: 'Pramp',
          link: 'https://www.pramp.com'
        },
        {
          name: 'InterviewBit',
          link: 'https://www.interviewbit.com'
        },
        {
          name: 'Interviewing.io',
          link: 'https://interviewing.io'
        }
      ]
    }
  ];

  const upcomingEvents = [
    {
      title: 'Resume Building Workshop',
      date: '2024-02-25',
      time: '11:00 AM',
      duration: '2 hours',
      instructor: 'Emily Brown',
      type: 'Workshop'
    },
    {
      title: 'System Design Masterclass',
      date: '2024-02-28',
      time: '2:00 PM',
      duration: '3 hours',
      instructor: 'David Wilson',
      type: 'Masterclass'
    }
  ];

  return (
    <div>
      <div className="max-w-6xl mx-auto mt-[150px]">
        <h1 className="text-2xl font-bold mb-6">Interview Preparation</h1>

        {/* Mock Interviews Section */}
        <div className="mb-8">
          <h2 className="text-lg font-semibold mb-4">Scheduled Mock Interviews</h2>
          <div className="grid gap-4">
            {mockInterviews.map(interview => (
              <div key={interview.id} className="bg-white rounded-lg sm p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="text-lg font-semibold flex items-center">
                      <FaVideo className="mr-2 text-indigo-600" />
                      {interview.type}
                    </h3>
                    <p className="text-gray-600">with {interview.interviewer}</p>
                    <div className="flex items-center mt-2 text-sm text-gray-500">
                      <FaCalendarAlt className="mr-2" />
                      {interview.date} at {interview.time} ({interview.duration})
                    </div>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-sm ${
                    interview.status === 'Scheduled' 
                      ? 'bg-green-100 text-green-800' 
                      : 'bg-yellow-100 text-yellow-800'
                  }`}>
                    {interview.status}
                  </span>
                </div>
                <div className="mt-4">
                  <h4 className="font-medium mb-2">Topics to be covered:</h4>
                  <div className="flex flex-wrap gap-2">
                    {interview.topics.map((topic, index) => (
                      <span
                        key={index}
                        className="bg-gray-100 text-gray-800 px-3 py-1 rounded-full text-sm"
                      >
                        {topic}
                      </span>
                    ))}
                  </div>
                </div>
                <div className="mt-4">
                  <button className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition-colors">
                    Join Interview
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Upcoming Events */}
        <div className="mb-8">
          <h2 className="text-lg font-semibold mb-4">Upcoming Events</h2>
          <div className="grid grid-cols-2 gap-4">
            {upcomingEvents.map((event, index) => (
              <div key={index} className="bg-white rounded-lg sm p-6">
                <h3 className="text-lg font-semibold">{event.title}</h3>
                <div className="mt-2 space-y-2 text-gray-600">
                  <p className="flex items-center">
                    <FaCalendarAlt className="mr-2" />
                    {event.date} at {event.time}
                  </p>
                  <p>Duration: {event.duration}</p>
                  <p>Instructor: {event.instructor}</p>
                </div>
                <button className="mt-4 px-4 py-2 bg-indigo-100 text-indigo-700 rounded-md hover:bg-indigo-200 transition-colors">
                  Register Now
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Learning Resources */}
        <div>
          <h2 className="text-lg font-semibold mb-4">Learning Resources</h2>
          <div className="grid grid-cols-3 gap-4">
            {learningResources.map((section, index) => (
              <div key={index} className="bg-white rounded-lg sm p-6">
                <div className="flex items-center mb-4">
                  {section.icon}
                  <h3 className="font-semibold ml-2">{section.title}</h3>
                </div>
                <ul className="space-y-3">
                  {section.resources.map((resource, resourceIndex) => (
                    <li key={resourceIndex}>
                      <a
                        href={resource.link}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center text-indigo-600 hover:text-indigo-800"
                      >
                        {resource.name}
                        <FaExternalLinkAlt className="ml-2 text-sm" />
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default InterviewPrep; 