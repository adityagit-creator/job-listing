import { collection, getDocs } from 'firebase/firestore';
import { useEffect, useState } from 'react';
import { db } from '../contexts/FirebaseConfig';

// Helper function to shuffle an array
const shuffleArray = (array) => {
  let shuffledArray = [...array];
  for (let i = shuffledArray.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffledArray[i], shuffledArray[j]] = [shuffledArray[j], shuffledArray[i]];
  }
  return shuffledArray;
};

export default function useQuiz(examId, yearId,subjectId) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [quiz, setQuiz] = useState([]);

  useEffect(() => {
    // Fetch the quiz questions from Firestore
    const fetchQuestions = async () => {
      const quizCollectionRef = collection(
        db,
        'exams',
        examId,
        'years',
        yearId,
        'subjects',
        subjectId,
        'quizzes'
      );

      try {
        setLoading(true);
        setError(false); // Reset error state before starting fetch

        // Fetch quiz data from Firestore
        const snapshot = await getDocs(quizCollectionRef);

        if (!snapshot.empty) {
          const quizData = snapshot.docs.map(doc => doc.data()); // Extract data from docs

          // Shuffle the quiz data randomly
          const shuffledQuizData = shuffleArray(quizData);
          
          setQuiz(shuffledQuizData); 
          
        } else {
          setQuiz([]); // If no data, reset to empty array
        }
      } catch (err) {
        console.error('Error fetching quiz questions:', err);
        setError(true);
      } finally {
        setLoading(false); // Ensure loading state is set to false
      }
    };

    fetchQuestions();
  }, [examId, yearId]); // Re-fetch when any of the dependencies change

  return { loading, error, quiz };
}

export  function useAptitue(examId, yearId) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [quiz, setQuiz] = useState([]);

  useEffect(() => {
    // Fetch the quiz questions from Firestore
    const fetchQuestions = async () => {
      const quizCollectionRef = collection(
        db,
        'Aptitude',
        examId,
        'years',
        yearId,
        'quizzes'
      );

      try {
        setLoading(true);
        setError(false); // Reset error state before starting fetch

        // Fetch quiz data from Firestore
        const snapshot = await getDocs(quizCollectionRef);

        if (!snapshot.empty) {
          const quizData = snapshot.docs.map(doc => doc.data()); // Extract data from docs

          // Shuffle the quiz data randomly
          const shuffledQuizData = shuffleArray(quizData);
          
          setQuiz(shuffledQuizData); 
          
        } else {
          setQuiz([]); // If no data, reset to empty array
        }
      } catch (err) {
        console.error('Error fetching quiz questions:', err);
        setError(true);
      } finally {
        setLoading(false); // Ensure loading state is set to false
      }
    };

    fetchQuestions();
  }, [examId, yearId]); // Re-fetch when any of the dependencies change

  return { loading, error, quiz };
}

export  function useCurrentAffairs(examId, yearId) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [quiz, setQuiz] = useState([]);

  useEffect(() => {
    // Fetch the quiz questions from Firestore
    const fetchQuestions = async () => {
      const quizCollectionRef = collection(
        db,
        'CurrentAffairs',
        examId,
        'years',
        yearId,
        'quizzes'
      );

      try {
        setLoading(true);
        setError(false); // Reset error state before starting fetch

        // Fetch quiz data from Firestore
        const snapshot = await getDocs(quizCollectionRef);

        if (!snapshot.empty) {
          const quizData = snapshot.docs.map(doc => doc.data()); // Extract data from docs

          // Shuffle the quiz data randomly
          const shuffledQuizData = shuffleArray(quizData);
          
          setQuiz(shuffledQuizData); 
          
        } else {
          setQuiz([]); // If no data, reset to empty array
        }
      } catch (err) {
        console.error('Error fetching quiz questions:', err);
        setError(true);
      } finally {
        setLoading(false); // Ensure loading state is set to false
      }
    };

    fetchQuestions();
  }, [examId, yearId]); // Re-fetch when any of the dependencies change

  return { loading, error, quiz };
}
