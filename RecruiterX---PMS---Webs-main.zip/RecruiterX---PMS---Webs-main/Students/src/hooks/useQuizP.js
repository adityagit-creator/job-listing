import { collection, getDocs, query, orderBy } from 'firebase/firestore';
import { useEffect, useState } from 'react';
import { db } from '../contexts/FirebaseConfig';


export default function useQuizP( examId, yearId) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [quiz, setQuiz] = useState([]);

  useEffect(() => {
    // Fetch the quiz questions from Firestore
    const fetchQuestions = async () => {
      const quizCollectionRef = collection(
        db,
        'PYQExam',
        examId,
        'years',
        yearId,
        'quizzes'
      );
      const quizQuery = query(quizCollectionRef, orderBy('quizz_id')); // Adjust the ordering field as per your Firestore structure

      try {
        setLoading(true);
        setError(false); // Reset error state before starting fetch

        // Fetch quiz data from Firestore
        const snapshot = await getDocs(quizQuery);

        if (!snapshot.empty) {
          const quizData = snapshot.docs.map(doc => doc.data()); // Extract data from docs
          setQuiz(quizData); 
          
        } else {
          setQuiz([]); // If no data, reset to empty array
        }
      } catch (err) {
        console.error('Error fetching quiz questions:', err);
        setError(true);
      } finally {
        setLoading(false); // Ensure loading state is set to false
      }
    };

    fetchQuestions();
  }, [ examId, yearId]); // Re-fetch when any of the dependencies change

  return { loading, error, quiz };
}
