import { doc, updateDoc, arrayUnion, getDoc, setDoc } from "firebase/firestore";
import { db } from "../contexts/FirebaseConfig";
import useAlert from "./useAlert";

// Function to store submission data in Firestore
export const storeSubmission = async (
  correctCount,
  incorrectCount,
  unattemptedCount,
  yearId,
  examId,
  subjectId,
  userId
) => {
  if (!userId) {
    useAlert("error", "User not authenticated");
    return;
  }

  const points = correctCount * 10;

  // Prepare the new submission data
  const newSubmission = {
    userId,
    correctCount, // Total correct answers
    incorrectCount, // Total incorrect answers
    unattemptedCount, // Total unattempted answers
    points, // Points for the submission
    examId, // Store examId
    yearId,
    subjectId, // Store yearId
    submissionDate: new Date(), // Date of submission
  };

  try {
    // Reference to the user's submissions document
    const submissionRef = doc(db, "submissions", userId);

    // Check if the document already exists
    const snapshot = await getDoc(submissionRef);

    if (snapshot.exists()) {
      // If the document exists, append the new submission to the array
      await updateDoc(submissionRef, {
        submissions: arrayUnion(newSubmission),
      });
    } else {
      // If the document does not exist, create it with the new submission in an array
      await setDoc(submissionRef, {
        submissions: [newSubmission],
      });
    }
  } catch (error) {
    console.error("Error storing submission:", error);
  }
};
