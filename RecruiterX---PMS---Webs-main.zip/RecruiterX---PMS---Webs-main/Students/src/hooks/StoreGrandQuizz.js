import {
    doc,
    updateDoc,
    setDoc,
    getDoc,
  } from "firebase/firestore";
  import { db } from "../contexts/FirebaseConfig";
  import useAlert from "./useAlert";
  
  // Function to store submission data in Firestore for leaderboard
  export const storeGrandTest = async (
    correctCount,
    incorrectCount,
    unattemptedCount,
    yearId,
    examId,
    userId,
    userName,
  ) => {
    if (!userId) {
      useAlert("error", "User not authenticated");
      return;
    }
  
    const points = correctCount * 10;
  
    // Prepare the new submission data
    const newSubmission = {
      userId,
      userName,
      correctCount, // Total correct answers
      incorrectCount, // Total incorrect answers
      unattemptedCount, // Total unattempted answers
      points, // Points for the submission
      examId, // Store examId
      yearId, // Store yearId
      submissionDate: new Date(), // Date of submission
    };
  
    try {
      // Reference to the user's submission document
      const submissionRef = doc(db, "grandTest", `${userId}`);
  
      // Check if the document already exists
   
      await setDoc(submissionRef, newSubmission);
  
      useAlert("success", "Submission stored successfully");
    } catch (error) {
      console.error("Error storing submission:", error);
      useAlert("error", "Failed to store submission");
    }
  };
  