import { useState, useEffect } from 'react';
import { toast } from 'react-hot-toast';
import { getNotifications, markAsRead, getUnreadCount } from '../services/notificationService';
import { useAuth } from '../contexts/AuthContext';

const useNotifications = () => {
  const { currentUser } = useAuth();
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (currentUser) {
      fetchNotifications();
      fetchUnreadCount();
    }
  }, [currentUser]);

  const fetchNotifications = async () => {
    try {
      setLoading(true);
      const data = await getNotifications(currentUser.uid);
      setNotifications(data);
      setError(null);
    } catch (err) {
      setError(err);
      toast.error('Failed to fetch notifications');
    } finally {
      setLoading(false);
    }
  };

  const fetchUnreadCount = async () => {
    try {
      const count = await getUnreadCount(currentUser.uid);
      setUnreadCount(count);
    } catch (err) {
      console.error('Error fetching unread count:', err);
    }
  };

  const markNotificationAsRead = async (notificationId) => {
    try {
      await markAsRead(notificationId);
      // Update local state
      setNotifications(prev => prev.map(notification =>
        notification.id === notificationId
          ? { ...notification, read: true, readAt: new Date() }
          : notification
      ));
      // Update unread count
      setUnreadCount(prev => Math.max(0, prev - 1));
    } catch (err) {
      toast.error('Failed to mark notification as read');
      throw err;
    }
  };

  const refreshNotifications = () => {
    fetchNotifications();
    fetchUnreadCount();
  };

  return {
    notifications,
    unreadCount,
    loading,
    error,
    markNotificationAsRead,
    refreshNotifications
  };
};

export default useNotifications; 