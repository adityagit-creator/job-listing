import { useState, useEffect } from 'react';
import { toast } from 'react-hot-toast';
import { getJobPostings, incrementJobView } from '../services/jobService';

const useJobs = () => {
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [filters, setFilters] = useState({
    status: [],
    type: '',
    minimumCGPA: null,
    branches: [],
    batchYears: []
  });

  // Fetch jobs when filters change
  useEffect(() => {
    const fetchJobs = async () => {
      try {
        setLoading(true);
        const data = await getJobPostings(filters);
        setJobs(data);
        setError(null);
      } catch (err) {
        setError(err);
        toast.error('Failed to fetch jobs');
      } finally {
        setLoading(false);
      }
    };

    fetchJobs();
  }, [filters]);

  const incrementJobViews = async (jobId) => {
    try {
      await incrementJobView(jobId);
      // Update local state
      setJobs(prev => prev.map(job => 
        job.id === jobId 
          ? { 
              ...job, 
              applicationStats: { 
                ...job.applicationStats, 
                views: (job.applicationStats?.views || 0) + 1 
              } 
            }
          : job
      ));
    } catch (err) {
      console.error('Failed to increment job views:', err);
    }
  };

  return {
    jobs,
    loading,
    error,
    filters,
    setFilters,
    incrementJobViews
  };
};

export default useJobs; 