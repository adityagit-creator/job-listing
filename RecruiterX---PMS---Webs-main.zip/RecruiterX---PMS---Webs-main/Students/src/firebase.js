import { initializeApp } from 'firebase/app';

const app = initializeApp({
  apiKey: "AIzaSyBFLTQBGxCgTkmSVxhlzF3N6jfXepAXMRI",
  authDomain: "growto-exams.firebaseapp.com",
  projectId: "growto-exams",
  storageBucket: "growto-exams.firebasestorage.app",
  messagingSenderId: "1045432867980",
  appId: "1:1045432867980:web:f4f82b211e6d6624402fa9",
  measurementId: "G-JHCFFRCLC1"
});

export default app;
