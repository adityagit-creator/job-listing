import { Navigate, Outlet } from 'react-router-dom';
import { useEffect } from 'react';
import { doc, onSnapshot } from 'firebase/firestore';
import { useAuth } from '../../contexts/AuthContext';
import { db } from '../../contexts/FirebaseConfig';
import { useAlert } from '../../hooks';


function PrivateOutlet() {
  const { currentUser, logOut } = useAuth();


  useEffect(() => {
    if (currentUser) {
      const userRef = doc(db, 'users', currentUser.uid);

      const unsubscribe = onSnapshot(userRef, (doc) => {
        if (doc.exists() && !doc.data()?.isLoggedIn) {
          useAlert('error', 'You have been logged out from another device.');
          logOut();
        }
      });

      return () => unsubscribe();
    }
  }, [currentUser, logOut, useAlert]);

  if (!currentUser) {
    useAlert('error', 'Login required to access this page.');
    return <Navigate to="/login" />;
  }

  return <Outlet />;
}

export default PrivateOutlet;
