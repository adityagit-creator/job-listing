/* eslint-disable jsx-a11y/no-static-element-interactions */
import { Link, useNavigate } from 'react-router-dom';

import { useAuth } from '../../contexts/AuthContext';
import { useAlert } from '../../hooks';
import Footer from '../common/Footer';

const ListItem = ({ to, href, text, icon, external = false }) => {
  const Wrapper = ({ children }) =>
    external ? (
      <a
        className="flex cursor-pointer flex-col border-b border-gray-800 p-1.5 text-gray-600 hover:rounded-lg hover:text-green-700"
        href={href}
        rel="noopener noreferrer"
        target="_blank"
      >
        {children}
      </a>
    ) : (
      <Link
        className="flex cursor-pointer flex-col bg-gray-50 border rounded-lg  my-1 p-1.5 text-gray-600 hover:rounded-lg hover:text-green-700"
        to={to}
      >
        {children}
      </Link>
    );

  return (
    <Wrapper>
      <div className="flex items-center justify-between">
        <div className="mr-auto flex items-center">
          <div className="flex -space-x-5">
            <span className="material-symbols-outlined relative size-9 object-cover  text-3xl text-black dark:text-white">
              {icon}
            </span>
          </div>
          <div className="ml-3 flex min-w-0 flex-col">
            <div className="font-semibold leading-none">{text}</div>
          </div>
        </div>
        <div className="ml-3 flex min-w-0 flex-col">
          <svg
            className="ml-2 size-5"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M9 5l7 7-7 7"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
            ></path>
          </svg>
        </div>
      </div>
    </Wrapper>
  );
};

function Others() {
  const { logOut } = useAuth();
  const navigate = useNavigate();
  const { currentUser } = useAuth();

  function handleLogOut() {
    logOut();
    useAlert('success', 'logout-success');
    navigate('/');
  }

  const placementItems = [
    { to: '/profile', text: 'Your Profile', icon: 'person' },
    { to: '/jobs', text: 'Job Listings', icon: 'work' },
    { to: '/applications', text: 'Application Tracking', icon: 'assignment' },
    { to: '/assessments', text: 'Online Assessments', icon: 'quiz' },
    { to: '/interview-prep', text: 'Interview Preparation', icon: 'school' },
    { to: '/notifications', text: 'Notifications', icon: 'notifications' },
    { to: '/offers', text: 'Offer Letters', icon: 'description' }
  ];

  const resourceItems = [
    { to: '/resume-builder', text: 'Resume Builder', icon: 'description' },
    { to: '/mock-tests', text: 'Mock Tests', icon: 'quiz' },
    { to: '/interview-tips', text: 'Interview Tips', icon: 'tips_and_updates' },
    { to: '/company-reviews', text: 'Company Reviews', icon: 'business' }
  ];

  const supportItems = [
    { to: '/about', text: 'About Us', icon: 'info' },
    { to: '/ContactUs', text: 'Contact Support', icon: 'support_agent' },
    { to: '/Privacy-Policy', text: 'Privacy Policy', icon: 'privacy_tip' },
    { to: '/Feedback', text: 'Send Feedback', icon: 'feedback' }
  ];

  return (
    <>
      <div className="mt-32 flex w-full flex-col items-center">
        <div className="w-[90%]">
          <div className="card mx-auto grid grid-cols-1 rounded-xl sm:grid-cols-1">
            <span className="text-primary text-xl font-bold my-2">Placement Dashboard</span>
            {placementItems.map((item, index) => (
              <ListItem key={index} {...item} />
            ))}
          </div>

          <div className="card mx-auto my-6 grid grid-cols-1 rounded-xl sm:grid-cols-1">
            <span className="text-primary text-xl font-bold my-2">Career Resources</span>
            {resourceItems.map((item, index) => (
              <ListItem key={index} {...item} />
            ))}
          </div>

          <div className="card mx-auto my-6 grid grid-cols-1 rounded-xl sm:grid-cols-1">
            <span className="text-primary text-xl font-bold my-2">Support & Help</span>
            {supportItems.map((item, index) => (
              <ListItem key={index} {...item} />
            ))}
          </div>

          {/* Logout Button */}
          {currentUser ? (
            <div
              className="my-4 flex cursor-pointer flex-col rounded-xl bg-red-700 p-1.5 text-gray-50 hover:bg-red-800"
              onClick={handleLogOut}
            >
              <div className="flex flex-row items-center justify-center">
                <div className="ml-3 flex min-w-0 flex-col">
                  <div className="font-medium leading-none text-white">Logout</div>
                </div>
                <div className="flex -space-x-5">
                  <span className="material-symbols-outlined relative size-9 object-cover text-3xl text-white">
                    arrow_circle_right
                  </span>
                </div>
              </div>
            </div>
          ) : null}
        </div>
      </div>
      <Footer />
    </>
  );
}

export default Others;
