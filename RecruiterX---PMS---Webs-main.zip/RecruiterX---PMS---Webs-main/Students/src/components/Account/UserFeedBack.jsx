/* eslint-disable tailwindcss/enforces-shorthand */
import { doc, setDoc } from "firebase/firestore";
import  { useState } from "react";
import { useNavigate } from "react-router-dom";
import { db } from "../../contexts/FirebaseConfig";
import { useAlert } from "../../hooks";

const RatingButtons = ({ onButtonClick }) => {
  const [selectedValue, setSelectedValue] = useState(null);

  const handleButtonClick = (value) => {
    setSelectedValue(value);
    onButtonClick(value);
  };

  return (
    <div className="my-2 grid grid-cols-5 sm:grid-cols-10 gap-x-5 gap-y-3  sm:gap-2">
      {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((value) => (
        <button
          key={value}
          className={`flex h-12 w-12 cursor-pointer items-center justify-center rounded-md text-lg font-semibold ${
            selectedValue === value ? "bg-secondary text-white" : "bg-primary"
          }`}
          value={value}
          onClick={() => handleButtonClick(value)}
        >
          {value}
        </button>
      ))}
    </div>
  );
};

const FeedbackOptions = ({ onSelectOption, selectedOption }) => {
  const options = [
    "Quizzes", // Core feature for exam preparation
    "FlashCard", // Quick revision tool
    "Payment", // Track progress and performance
    "Others", // Main entry point
  ];

  return (
    <div>
      <p className="container mx-4 font-semibold">
        {" "}
        <span>😐</span>Which you liked the least ?
      </p>

      <div className=" my-4 grid w-full grid-cols-2 sm:grid-cols-4 gap-x-2 gap-y-2 rounded-md border border-solid border-gray-200 p-4">
        {options.map((option, index) => (
          <p
            key={index}
            className={`m-1 cursor-pointer rounded-[30px] border border-solid px-2 py-2 text-center ${
              selectedOption === option
                ? "bg-primary/100 text-white"
                : "text-skin-base border-gray-200 bg-secondary"
            }`}
            onClick={() => onSelectOption(option)}
          >
            {option}
          </p>
        ))}
      </div>
    </div>
  );
};
function UserFeedback() {
  const [selectedValue, setSelectedValue] = useState(null);
  const [selectedOption, setSelectedOption] = useState(null);
  const [suggestions, setSuggestions] = useState("");
  const [hasError, setHasError] = useState(false);

  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState(false);

  const handleOptionSelect = (option) => {
    setSelectedOption(option);
  };

  const handleButtonClick = (value) => {
    setSelectedValue(value);
  };

  const handleSubmit = async () => {
    try {
      setLoading(true);

      // Validation check
      if (
        selectedValue === null ||
        (selectedValue >= 3 && selectedValue <= 8 && !selectedOption) ||
        !suggestions.trim()
      ) {
        setHasError(true);
        setErrorMessage("Please fill in all the fields before submitting.");
        setLoading(false);
        return;
      }

      // Reset error state
      setHasError(false);
      setErrorMessage("");

      // Create a unique document ID (using current timestamp)
      const docId = new Date().getTime().toString();

      // Create a document reference
      const feedbackDocRef = doc(db, "feedbacks", docId);

      // Set feedback data to Firestore
      await setDoc(feedbackDocRef, {
        rating: selectedValue,
        selectedOption,
        status: "Pending",
        suggestions,
        createdAt: new Date(), // Store the timestamp
      });

      // Simulate a delay of 2 seconds
      await new Promise((resolve) => setTimeout(resolve, 1500));

      // Show alert after feedback is stored
      useAlert("sucess", "Thank you for your feedback!");

      // Redirect to thank you page
      navigate("/");
    } catch (error) {
      console.error("Error submitting feedback:", error);
      setHasError(true);
      setErrorMessage("Oops! Something went wrong. Please try again later.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mt-20 flex flex-col items-center p-4">
      <div className="card relative m-8  flex h-full w-full  flex-col items-start justify-start rounded-lg border border-gray-200  sm:h-[45rem]">
        <div className=" w-full">
          <div className="w-full">
            <div className="my-2 mt-4  w-full rounded-md bg-primary/50 p-3 font-semibold">
              <h2 className="text-md font-bold sm:text-xl">
                Your Feedback will be anonymous !
              </h2>
            </div>
            <div className="my-3 flex w-full flex-col items-start justify-between">
              <p className="text-skin-base">Please rate your experience</p>
              <RatingButtons onButtonClick={handleButtonClick} />

              <div className="flex w-full items-center justify-between">
                <p className="text-skin-base">Awful</p>
                <p className="text-skin-base">Outstanding</p>
              </div>
            </div>
          </div>

          {selectedValue >= 3 && selectedValue <= 8 && (
            <FeedbackOptions
              selectedOption={selectedOption}
              onSelectOption={handleOptionSelect}
            />
          )}
          <div className="my-4 flex h-full w-full flex-col items-start justify-start px-4 ">
            <p>Any suggestions for us? We're listening!</p>

            <div className="my-5 flex w-full items-center rounded-md border border-black/30 bg-white p-2 outline-none dark:border-white/30 dark:bg-black/50">
              <textarea
                required
                className="ml-1 h-[100px] w-full resize-none rounded-lg border-none bg-transparent font-medium tracking-wide text-black outline-none dark:text-white lg:text-xl"
                placeholder="Your Message"
                onChange={(e) => setSuggestions(e.target.value)}
              />
              <span className="material-symbols-outlined mx-1 mb-auto mt-1 flex cursor-pointer items-center justify-center text-black dark:text-white md:text-3xl">
                comment
              </span>
            </div>
            <div className="flex w-full items-center   justify-center  ">
              <button
                className={`w-full rounded-md py-3 text-white ${
                  loading
                    ? "cursor-not-allowed bg-primary"
                    : "bg-primary hover:bg-primary/45"
                }`}
                disabled={loading}
                onClick={handleSubmit}
              >
                {loading ? "Submitting..." : "SUBMIT"}
              </button>
            </div>
          </div>
        </div>
        {hasError && (
          <div className="my-4 mx-4 text-center text-red-500 font-semibold">
            <p>{errorMessage}</p>
          </div>
        )}
      </div>
    </div>
  );
}

export default UserFeedback;
