// /* eslint-disable no-undef */
// import { get, getDatabase, push, ref, update } from 'firebase/database';
// import _ from 'lodash';
// import { useCallback, useEffect, useMemo, useReducer, useState } from 'react';
// import { useNavigate, useParams } from 'react-router-dom';

// import { PageNotFound } from './';

// import { AnswerBox, ProgressBar, Rules } from '../components';
// import { useAuth } from '../contexts/AuthContext';
// import { useQuiz } from '../hooks';

// const initialState = null;

// const reducer = (state, action) => {
//   switch (action.type) {
//     case 'quiz': {
//       const qnaSet = _.cloneDeep(action.value);
//       qnaSet.forEach((question) => {
//         question.options.forEach((option) => {
//           option.checked = false; // Mark all options as unchecked initially
//         });
//       });
//       return qnaSet;
//     }
//     case 'answer': {
//       const question = _.cloneDeep(state);
//       question[action.questionID].options[action.optionIndex].checked = action.value;
//       return question;
//     }
//     default:
//       return state;
//   }
// };

// function Quiz() {
//   const { examId, yearId, mode } = useParams(); // `mode` will determine whether it's "exam" or "learner"
//   const { loading, error, quiz } = useQuiz(examId, yearId); // Fetch quiz data based on IDs
//   const [currentQuestion, setCurrentQuestion] = useState(0);
//   const [qnaSet, dispatch] = useReducer(reducer, initialState);
//   const { currentUser } = useAuth();
//   const navigate = useNavigate();
//   const date = useMemo(() => new Date(), []); // Get the current date and time
//   const [selectedAnswers, setSelectedAnswers] = useState({});
//   const [timeLeft, setTimeLeft] = useState(60); // 60 seconds per question
//   const [isExamOver, setIsExamOver] = useState(false); // Flag for marking the end of the exam
//   const [answerSelected, setAnswerSelected] = useState(false); // Flag to track if an answer is selected

//   // Fetch quiz data into the local state (qnaSet) when quiz data is available
//   useEffect(() => {
//     if (quiz) {
//       dispatch({
//         type: 'quiz',
//         value: quiz,
//       });
//     }
//   }, [quiz]);

//   // Handle answer selection for both modes
//   const handleAnswerChange = useCallback(
//     (e, index) => {
//       dispatch({
//         type: 'answer',
//         questionID: currentQuestion,
//         optionIndex: index,
//         value: e.target.checked,
//       });
//       setSelectedAnswers((prev) => ({
//         ...prev,
//         [currentQuestion]: index,
//       }));
//       setAnswerSelected(true); // Mark answer as selected
//     },
//     [currentQuestion]
//   );

//   // Lock answer for Exam Mode
//   const lockAnswer = (index) => {
//     setSelectedAnswers((prev) => ({
//       ...prev,
//       [currentQuestion]: index,
//     }));
//     setAnswerSelected(true); // Mark answer as selected
//   };

//   // Move to the next question
//   const nextQuestion = useCallback(() => {
//     setAnswerSelected(false); // Reset answer selection state
//     if (currentQuestion < qnaSet.length - 1) {
//       setCurrentQuestion((curr) => curr + 1);
//     } else {
//       setIsExamOver(true); // End the quiz if it's the last question
//     }
//   }, [currentQuestion, qnaSet]);

//   // Previous question handler
//   const previousQuestion = useCallback(() => {
//     if (currentQuestion >= 1 && currentQuestion <= qnaSet.length) {
//       setCurrentQuestion((curr) => curr - 1);
//     }
//     setAnswerSelected(false); // Reset answer selection state
//   }, [currentQuestion, qnaSet]);

//   // Progress percentage calculation
//   const progressPercentage = qnaSet?.length > 0 ? ((currentQuestion + 1) * 100) / qnaSet.length : 0;

//   // Start countdown timer for Exam Mode
//   useEffect(() => {
//     if (mode === 'exam' && !isExamOver) {
//       const timer = setInterval(() => {
//         setTimeLeft((prevTime) => {
//           if (prevTime <= 1) {
//             clearInterval(timer); // Stop timer when it reaches 0
//             if (!answerSelected) {
//               nextQuestion(); // If no answer selected, move to next question
//             }
//             return 0;
//           }
//           return prevTime - 1;
//         });
//       }, 1000);

//       return () => clearInterval(timer); // Cleanup timer on unmount or when the exam ends
//     }
//   }, [timeLeft, mode, isExamOver, answerSelected, nextQuestion]);

//   // Submit quiz logic
//   const submitQuiz = useCallback(async () => {
//     if (!qnaSet || qnaSet.length === 0) {
//       console.error('Quiz data is invalid');
//       return;
//     }

//     // Calculate marks
//     const getMarkSheet = () => {
//       let correctAnswersCount = 0;
//       let incorrectAnswersCount = 0;
//       let unattemptedCount = 0;

//       qnaSet.forEach((question) => {
//         const correctIndexes = [];
//         const checkedIndexes = [];
//         question.options.forEach((option, idx) => {
//           if (option.correct) correctIndexes.push(idx);
//           if (option.checked) checkedIndexes.push(idx);
//         });

//         if (checkedIndexes.length === 0) unattemptedCount += 1;
//         else if (_.isEqual(correctIndexes, checkedIndexes)) correctAnswersCount += 1;
//         else incorrectAnswersCount += 1;
//       });

//       const noq = qnaSet.length;
//       const obtainedPoints = correctAnswersCount * 10 - incorrectAnswersCount * 2;
//       const obtainedPercentage = obtainedPoints / (0.1 * noq);

//       return [
//         noq,
//         correctAnswersCount,
//         incorrectAnswersCount,
//         unattemptedCount,
//         obtainedPoints,
//         obtainedPercentage,
//       ];
//     };

//     const [
//       noq,
//       correctAnswersCount,
//       incorrectAnswersCount,
//       unattemptedCount,
//       obtainedPoints,
//       obtainedPercentage,
//     ] = getMarkSheet();

//     const markSheetObject = {
//       topicId: yearId,
//       date: date.toLocaleDateString('en-IN'),
//       time: `${date.getHours() % 12 || 12}:${date.getMinutes().toString().padStart(2, '0')} ${date.getHours() < 12 ? 'AM' : 'PM'}`,
//       noq,
//       correctAnswersCount,
//       incorrectAnswersCount,
//       unattemptedCount,
//       obtainedPoints,
//       obtainedPercentage,
//       qnaSet: _.cloneDeep(qnaSet),
//     };

//     try {
//       const { uid } = currentUser;
//       const db = getDatabase();

//       // Create a new submission key
//       const submissionsRef = ref(db, `submissions/${uid}`);
//       const submissionsKey = push(submissionsRef).key;

//       // Prepare data to write
//       const submissionsData = { [`submissions/${uid}/${submissionsKey}`]: markSheetObject };

//       // Update database
//       await update(ref(db), submissionsData);

//       // Update submission count
//       const submissionCountRef = ref(db, `submissionCount/${yearId}`);
//       const snapshot = await get(submissionCountRef);
//       const currentSubmissionCount = snapshot.exists() ? snapshot.val() : 0;
//       await update(submissionCountRef, { [yearId]: currentSubmissionCount + 1 });

//       // Navigate to results page
//       navigate(`/result/${yearId}`, { state: { qnaSet, markSheetObject } });
//     } catch (error) {
//       console.error('Error submitting quiz:', error);
//     }
//   }, [qnaSet, currentUser, date, yearId, navigate]);

//   return (
//     <>
//       {loading && <p className="page-heading text-lg">Loading ...</p>}
//       {error && <PageNotFound />}
//       {!loading && !error && qnaSet && qnaSet?.length === 0 && <PageNotFound />}
//       {!loading && !error && qnaSet && qnaSet?.length > 0 && (
//         <div className="mx-auto w-[85%] animate-reveal">
//           <h1 className="page-heading"> Quiz!</h1>
//           <div className='flex flex-row gap-2'>
//           <Rules />
//             <div div="card mb-6 w-full ">
//     <div className="w-full flex items-center justify-center my-2">
//     <label className="relative mr-4 min-w-14 text-xl font-medium dark:text-primary text-secondary">
//    Learn Mode
//     </label>
//     <input
//       className="relative h-6 w-11 shrink-0 cursor-pointer appearance-none rounded-full bg-indigo-100 p-0.5 transition-colors duration-200 ease-in-out before:inline-block  before:size-5  before:translate-x-0

//                     before:rounded-full before:bg-primary before:shadow before:transition before:duration-200 before:ease-in-out checked:bg-secondary checked:bg-none checked:before:translate-x-full checked:before:bg-primary  focus:border-indigo-600"
//       id="basic-with-description"
//       type="checkbox"
//       value={mode}
//       onChange={(e) => setMode(e.target.value)}
//     />
//     <label className="relative ml-4 min-w-14 text-xl font-medium dark:text-primary text-secondary ">
//       Exam Mode
//     </label>
//   </div>
//             </div>
//           </div>
//           <div className="card mb-40 flex flex-col justify-center rounded-md p-3">
//             <div className="flex flex-col items-center justify-center text-xl font-bold text-black dark:text-white sm:text-3xl">
//               Q. {qnaSet[currentQuestion].Question}
//             </div>

//             <hr className="mb-8 mt-3 h-px border-t-0 bg-gray-300 dark:bg-neutral-700" />
//             <div className="quiz__answer">
//               {qnaSet[currentQuestion]?.options?.map((option, index) => (
//                 <AnswerBox
//                   key={index}
//                   option={option}
//                   handleAnswerChange={handleAnswerChange}
//                   index={index}
//                   selectedAnswer={selectedAnswers[currentQuestion] ?? null}
//                   lockAnswer={lockAnswer}
//                   mode={mode}
//                 />
//               ))}
//             </div>
//           </div>

//           <ProgressBar
//             nextQ={nextQuestion}
//             prevQ={previousQuestion}
//             progress={progressPercentage}
//             submit={submitQuiz}
//           />

//           {mode === 'exam' && !isExamOver && (
//             <div className="timer">Time left: {timeLeft}s</div>
//           )}
//         </div>
//       )}
//     </>
//   );
// }

// export default Quiz;
