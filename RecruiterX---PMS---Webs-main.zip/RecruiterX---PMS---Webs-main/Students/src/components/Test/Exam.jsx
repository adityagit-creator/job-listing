// import { useEffect, useState } from 'react';
// import { Link } from 'react-router-dom';

// import { db } from '../../contexts/FirebaseConfig';
// import { collection, getDocs } from 'firebase/firestore';
// import Footer from '../common/Footer';
// import Thumbnail from '../atoms/Thumbnail';

// function ExamQuizz() {
//     const [exams, setExams] = useState([]);
//     const [loading, setLoading] = useState(true);

//     useEffect(() => {
//       const fetchExams = async () => {
//         try {
//           // Check session storage for cached data

//           const cachedExams = sessionStorage.getItem("Quizzess");
//           if (cachedExams) {
//             setExams(JSON.parse(cachedExams));
//             setLoading(false);
//             return;
//           }

//           // If no cache, fetch from Firestore
//           const examCollectionRef = collection(db, "exams");
//           const examSnapshot = await getDocs(examCollectionRef);
//           const examList = examSnapshot.docs.map((doc) => ({
//             id: doc.id,
//             ...doc.data(),
//           }));

//           // Cache the fetched data in session storage
//           sessionStorage.setItem("Quizzess", JSON.stringify(examList));
//           setExams(examList);
//         } catch (error) {
//           console.error("Error fetching exams:", error);
//         } finally {
//           setLoading(false);
//         }
//       };

//       fetchExams();
//     }, []);

//   return (
//     <>
//     <div className="mx-auto mb-32 flex min-h-screen w-[90%] flex-col items-center">
//       <h1 className="page-heading">Question Bank</h1>

//       {loading ? (
//         <div className="flex items-center justify-center text-center text-xl">
//           Loading exams...
//         </div>
//       ) : (
//         <div className="mx-auto grid w-full grid-cols-1 gap-5 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
//           {exams.map((video) => (
//             <Link key={video.id} className="w-full" to={`/Exams/${video.examName}`}>
//               <Thumbnail link={video.imageUrl} title={video.examName} type="video" />
//             </Link>
//           ))}
//         </div>
//       )}

//       {exams.length === 0 && !loading && (
//         <div className="flex items-center justify-center text-center text-xl">
//           Coming Soon...
//         </div>
//       )}
//     </div>
//     <Footer />
//   </>
//   );
// }

// export default ExamQuizz;
