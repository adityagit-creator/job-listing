
import { Link } from 'react-router-dom';

function CTA({ headline, Descption }) {



  return (
    <div className="border-primary mx-auto mt-12 flex w-full flex-col  items-center gap-8 border-y-2 px-5 py-8 sm:py-14">
      <div>
        <p className="bg-primary  bg-clip-text text-center text-4xl font-bold text-transparent xl:text-5xl/[5rem]">
          {headline}
        </p>
        <p className="text-center text-2xl font-semibold xl:text-2xl">{Descption}</p>
      </div>
      <Link to="/pricing"
        className="ring-offset-background focus-visible:ring-ring bg-primary hover:bg-primary/90 inline-flex h-14 w-60 cursor-pointer items-center justify-center whitespace-nowrap rounded-md px-8 text-2xl font-medium text-white drop-xl transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50"
      >
        Get Now
      </Link>
    </div>
  );
}

export default CTA;
