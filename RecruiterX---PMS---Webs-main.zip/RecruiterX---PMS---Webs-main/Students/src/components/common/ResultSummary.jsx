import { useParams } from 'react-router-dom';
import { ScoreCard } from '..';

function ResultSummary({
  showTopicID = false,
  topicId,
  noq,
  correctCount,
  incorrectAnswersCount,
  unattemptedCount,
  date,
}) {
  const { id } = useParams();

  // Calculate obtained points based on correct answers only
  const obtainedPoints = correctCount * 10; // Assuming 10 points per correct answer

  // Calculate percentage based on obtained points
  const obtainedPercentage = Math.min(
    Math.max((obtainedPoints / (noq * 10)) * 100, 0),
    100
  );

  return (
    <div className="mx-auto">
      {showTopicID && <h1 className="page-heading">{id?.split('-').join(' ')} Quiz</h1>}
      <ScoreCard
        correctAnswersCount={correctCount}
        date={date}
        incorrectAnswersCount={incorrectAnswersCount}
        location="result"
        noq={noq}
        obtainedPercentage={obtainedPercentage}
        obtainedPoints={obtainedPoints}
        topicId={topicId}
        unattemptedCount={unattemptedCount}
      />
    </div>
  );
}

export default ResultSummary;
