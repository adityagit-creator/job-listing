import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';

const PrivateRoute = ({ role }) => {
  const { currentUser } = useAuth();

  // Check if user is authenticated and has the correct role
  if (!currentUser) {
    return <Navigate to={`/${role}/login`} />;
  }

  // You can add additional role-based checks here
  // For example, checking if the user's role in the database matches the required role

  return <Outlet />;
};

export default PrivateRoute; 