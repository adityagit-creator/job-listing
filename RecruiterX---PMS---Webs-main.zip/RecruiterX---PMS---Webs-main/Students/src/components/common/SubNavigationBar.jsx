import { NavLink } from 'react-router-dom';
import { FaBriefcase, FaClipboardList, FaGraduationCap, FaBell, FaFile, FaUserCircle, FaChalkboardTeacher } from 'react-icons/fa';
import { NavButton } from '..';

function SubNavigationBar({ className }) {
  const navItems = [
    { path: '/Jobs', icon: <FaFile />, text: 'Jobs' },
    { path: '/offers', icon: <FaFile />, text: 'Offers' },
    { path: '/applications', icon: <FaClipboardList />, text: 'Applications' },
    { path: '/profile', icon: <FaUserCircle />, text: 'Profile' },
    { path: '/notifications', icon: <FaBell />, text: 'Notifications' },
  ];

  return (
    <ul className={`flex items-center gap-6 ${className}`}>
      {navItems.map((item) => (
        <NavLink
          key={item.path}
          className={({ isActive }) => (isActive ? 'active-page' : null)}
          to={item.path}
        >
          <NavButton icon={item.icon} text={item.text} />
        </NavLink>
      ))}
    </ul>
  );
}

export default SubNavigationBar;
