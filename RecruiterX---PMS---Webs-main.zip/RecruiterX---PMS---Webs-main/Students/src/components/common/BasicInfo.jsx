/* eslint-disable tailwindcss/no-custom-classname */
import { info1, info2, info3, logo, placeholder } from "../../assets";
import Features from "../home/Features";




function BasicInfo() {
  return (
    <>
    
      <div className="mb-8 w-[85%]">
       
       <Features/>
      </div>
    </>
  );
}

export default BasicInfo;
