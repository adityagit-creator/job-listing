function ProgressBar({ nextQ, prevQ, progress, submit, isSubmitting }) {
  return (
    <div className="fixed bottom-0 left-0 right-0 card  ">
      <div className="w-full rounded-full bg-black/10 dark:bg-white/10 mb-2">
        <div
          className={`rounded-full text-center text-[10px] font-medium leading-none tracking-wider text-black transition-all duration-700 ease-in
    sm:text-xs ${
      progress === 100
        ? "bg-green-400"
        : progress >= 60
          ? "bg-orange-400"
          : "bg-red-400"
    }`}
          style={{ width: `${progress.toFixed(0)}%`, height: "5px" }}
        >
          {/* {progress.toFixed(0)}% */}
        </div>
      </div>

      <div className=" gap-5  mx-auto w-full flex flex-row lg:gap-5">
        <button
          className="w-full fill-button flex gap-2 border-red-700 bg-red-400 px-3 py-2 font-medium hover:bg-red-500"
          type="button"
          onClick={prevQ}
        >
          <span className="material-symbols-outlined text-3xl text-black">
            arrow_circle_left
          </span>
          <span className=" text-xl text-black lg:block">Back</span>
        </button>

        <button
          className="w-full fill-button flex gap-2 border-green-700 bg-green-400 px-3 py-2 font-medium hover:bg-green-500"
          type="button"
          onClick={progress === 100 ? submit : nextQ}
          disabled={isSubmitting}
        >
          <span className=" text-xl text-black lg:block">
            {progress === 100 ? "Submit" : "Next"}
          </span>
          <span className="material-symbols-outlined text-3xl text-black">
            {progress === 100 ? "check_circle" : "arrow_circle_right"}
          </span>
        </button>
      </div>
    </div>
  );
}

export default ProgressBar;
