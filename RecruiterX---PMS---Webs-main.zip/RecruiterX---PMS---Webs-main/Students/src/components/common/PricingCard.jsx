/* eslint-disable jsx-a11y/no-static-element-interactions */
/* eslint-disable tailwindcss/no-custom-classname */
/* eslint-disable jsx-a11y/label-has-associated-control */
import { useEffect, useState } from "react";

import { useAuth } from "../../contexts/AuthContext";
import { useAlert } from "../../hooks";
import { loadScript } from "../atoms/LoadScript";
import { logo } from "../../assets";
import { db } from "../../contexts/FirebaseConfig";
import { doc, getDoc } from "firebase/firestore";
import { useNavigate } from "react-router-dom";
import { IoCheckmarkDoneOutline } from "react-icons/io5";

function PricingCard() {
  const ORIGINAL_AMOUNT = 499; // Original price
  const [amount, setAmount] = useState(ORIGINAL_AMOUNT);
  const [promoCode, setPromoCode] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [promoCodes, setPromoCodes] = useState({});
  const { updateSubscription, currentUser } = useAuth();

  // Define promo codes and their corresponding discounted prices

  useEffect(() => {
    const fetchPromoCodes = async () => {
      const docRef = doc(db, "settings", "promos");
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        setPromoCodes(docSnap.data()); // Data from Firestore
      } else {
        console.error("No promo codes found in Firestore");
      }
    };

    fetchPromoCodes();
  }, []);

  // const capturePayment = async (paymentId, amount) => {
  //   try {
  //     const response = await fetch('/capturePayments', {
  //       method: 'POST',
  //       headers: {
  //         'Content-Type': 'application/json',
  //       },
  //       body: JSON.stringify({ payment_id: paymentId, amount: amount }),
  //     });

  //     const data = await response.json();
  //     if (data.success) {
  //       console.log('Payment captured successfully');
  //       // You can redirect the user or display a success message here
  //     } else {
  //       console.error('Payment capture failed:', data.message);
  //     }
  //   } catch (error) {
  //     console.error('Error in capturing payment:', error);
  //   }
  // };
  // Display Razorpay payment modal
  const displayRazorpay = async (amount) => {
    const res = await loadScript(
      "https://checkout.razorpay.com/v1/checkout.js"
    );

    if (!res) {
      useAlert(
        "error",
        "Razorpay SDK failed to load. Please check your internet connection."
      );
      return;
    }

    const options = {
      key: import.meta.env.VITE_RAZORPAY_KEY, // Replace with your
      currency: "INR",
      amount: amount * 100,
      name: "SchoolX Exams",
      description: "Thank you for your purchase!",
      image: logo,
      handler: function (response) {
        // const paymentId = response.razorpay_payment_id;
        // capturePayment(paymentId, amount);
        updateSubscription(
          currentUser.uid,
          amount,
          response.razorpay_payment_id,
          promoCode
        );
        // You can also send the payment ID to your server for verification
      },
      prefill: {
        name: currentUser.name,
        email: currentUser.email,
        contact: currentUser.phoneNumber,
      },
      theme: {
        color: "#F37254", // Customize the theme color
      },
    };

    const paymentObject = new window.Razorpay(options);
    paymentObject.open();
  };

  // Apply Promo Code
  const applyPromoCode = () => {
    const code = promoCode.trim().toUpperCase();
    if (promoCodes[code]) {
      setAmount(promoCodes[code]); // Update amount based on promo code
      setErrorMessage("");
      setSuccessMessage(`Promo code "${code}" applied!`);
    } else {
      setErrorMessage("Invalid Promo Code");
      setSuccessMessage("");
    }
  };
  const navigate = useNavigate();
  // Reset Promo Code
  const resetPromoCode = () => {
    setAmount(ORIGINAL_AMOUNT);
    setPromoCode("");
    setErrorMessage("");
    setSuccessMessage("");
  };

  const features = [
    "Expert-curated past exam question sets.",
    "Quick revision with topic-wise quizzes.",
    "Clear explanations for better understanding.",
    "Affordable, time-saving study resources.",
    "Effective practice with flashcards.",
    "GROUP IV exam insights from experts.",
    "Professionally designed syllabus for focused prep.",
  ];

  return (
    <div className="mx-auto max-w-7xl px-4">
      <div className="mb-12">
        <h2 className="page-heading">Gold Plus + </h2>
        <p className="mb-9 text-center leading-6 text-gray-500">
          Get access to the All Goverment Exam 2025 preparation resources for
          just ₹{amount}!
        </p>
      </div>

      <div className="space-y-8 sm:gap-6 lg:grid  lg:items-center lg:space-y-0 xl:gap-8">
        {/* Empty divs for spacing/layout purposes */}

        <div className="border-primary bg-indigo-100 dark:border-primary mx-auto flex max-w-lg flex-col rounded-xl border text-gray-900 transition-all duration-500 backdrop-blur-lg bg-opacity-30 ">
          {" "}
          <div className="bg-primary rounded-t-xl py-4 text-center text-2xl font-semibold uppercase text-white">
            MOST POPULAR
          </div>
          <div className="flex flex-col items-center p-4 ">
            <div className="mb-6 flex items-center">
              <span className="font-manrope text-primary mr-2 text-6xl font-semibold">
                ₹{amount}
              </span>
              <span className="text-xl text-gray-500">/ 3 month</span>
            </div>

            <ul className="mb-8 gap-4 space-y-3 text-left text-lg">
              {features.map((feature, index) => (
                <li key={index} className="flex items-center space-x-4">
                  <IoCheckmarkDoneOutline className="text-primary size-6 shrink-0" />

                  <span>{feature}</span>
                </li>
              ))}
            </ul>

            {/* Promo Code Section */}
            <div className="mb-4 w-full flex flex-row gap-3">
              <input
                className="  rounded-md border px-4 py-2 text-black w-[70%]"
                placeholder="Enter Promo Code"
                type="text"
                value={promoCode}
                onChange={(e) => setPromoCode(e.target.value)}
              />
              <button
                className="border-primary  hover:bg-primary   rounded-md border-2 px-4 py-2 transition-colors dark:text-white w-[30%]"
                onClick={applyPromoCode}
              >
                Apply 
              </button>
              
              
            </div>
            {errorMessage && (
                <p className="mt-2 text-sm text-red-500">{errorMessage}</p>
              )}
              {successMessage && (
                <p className="mt-2 text-sm text-green-500">{successMessage}</p>
              )}
              {amount !== ORIGINAL_AMOUNT && (
                <button
                  className="mt-2 w-full rounded-md bg-gray-300 px-5 py-2 text-red-700 transition-colors hover:bg-gray-400"
                  onClick={resetPromoCode}
                >
                  Remove Promo Code
                </button>
              )}
            <div
              className="bg-primary mt-4 w-full cursor-pointer rounded-lg py-3 text-center text-xl text-white"
              onClick={() => {
                if (currentUser) {
                  displayRazorpay(amount); // Proceed with payment
                } else {
                  navigate("/login");
                  useAlert("warning", "Please log in to purchase the plan."); // Show alert if not logged in
                }
              }}
            >
              {currentUser ? "Purchase Plan" : "Login and Pay"}
            </div>
          </div>
        </div>
        {/* Empty div for spacing/layout purposes */}
        <div></div>
      </div>
    </div>
  );
}

export default PricingCard;
