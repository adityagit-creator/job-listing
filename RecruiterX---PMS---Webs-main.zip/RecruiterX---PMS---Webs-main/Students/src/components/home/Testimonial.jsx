import React from "react";
import { Slider } from "./Slider";

const testimonialsData = [
  {
    name: "Santosh Bhat",
    role: "Head of Data Science at Policybazaar",
    testimonial:
      "I see a strong need for Kale in the BFSI sector. Its ability to provide real-time, contextual support directly within the app is exactly what's needed to boost customer engagement and retention.",
    image: "https://via.placeholder.com/50", // Replace with actual image URL
  },
  {
    name: "Priya Sharma",
    role: "CTO at FinTechPro",
    testimonial:
      "Kale’s AI-driven insights are game-changing. It helped us improve user retention by 40%. The team's support and product vision are truly outstanding.",
    image: "https://via.placeholder.com/50",
  },
  {
    name: "Arun Kumar",
    role: "Product Manager at TechCorp",
    testimonial:
      "The seamless integration of Kale into our app was incredible. It offers unparalleled precision in engagement and retention strategies.",
    image: "https://via.placeholder.com/50",
  },
];

const TestimonialSlider = () => {


  return (
    <div className="max-w-4xl mx-auto p-4">
      <Slider>
        {testimonialsData.map((testimonial, index) => (
          <div
            key={index}
            className="card"
          >
            <div className="flex items-center mb-4">
              <img
                src={testimonial.image}
                alt={testimonial.name}
                className="w-12 h-12 rounded-full"
              />
              <div className="ml-4">
                <h3 className="text-lg font-bold">{testimonial.name}</h3>
                <p className="text-sm text-gray-400">{testimonial.role}</p>
              </div>
            </div>
            <p className="text-sm leading-relaxed">{testimonial.testimonial}</p>
          </div>
        ))}
      </Slider>
    </div>
  );
};

export default TestimonialSlider;
