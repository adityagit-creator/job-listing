import { Link } from "react-router-dom";

function SearchBar() {
  return (
    <Link to="/learn" className=" w-full flex justify-center items-center">
      <div className="min-w-xl sm:min-w-[600px] flex items-center gap-2 sm:w-[50%] w-full rounded-2xl border bg-white p-2 focus-within:border-gray-300">
        {/* Google Search Icon */}

        <div className="  text-gray-500 material-symbols-outlined ">search</div>
        {/* Search Input */}
        <input
          className="w-full  py-2 rounded-md bg-white outline-none"
          id="search-bar"
          placeholder="Find all your Exams, Flashcards, right here."
        />
      </div>
    </Link>
  );
}

export default SearchBar;
