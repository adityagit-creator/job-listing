import React, { useEffect, useRef } from "react";
import { FiArrowLeft, FiArrowRight } from "react-icons/fi";

// ProductSlider Component
export const Slider = ({ children }) => {
  const sliderRef = useRef(null);

  // Function to scroll left
  const scrollLeft = () => {
    if (sliderRef.current) {
      sliderRef.current.scrollBy({
        left: -sliderRef.current.clientWidth,
        behavior: "smooth",
      });
    }
  };

  // Function to scroll right
  const scrollRight = () => {
    if (sliderRef.current) {
      sliderRef.current.scrollBy({
        left: sliderRef.current.clientWidth,
        behavior: "smooth",
      });
    }
  };

  useEffect(() => {
    const autoScroll = setInterval(() => {
      scrollRight();
    }, 15000);

    // Cleanup interval on unmount
    return () => clearInterval(autoScroll);
  }, []);

  return (
    <section className="mt-4 w-full">
      {/* Slider Container */}
      <div className="relative">
        {/* Slider Items */}
        <div
          ref={sliderRef}
          style={{
            scrollbarWidth: "none", // Firefox scrollbar hide
            msOverflowStyle: "none", // IE scrollbar hide
          }}
          className="flex overflow-x-auto no-scrollbar scroll-smooth gap-4 p-4"
        >
          {children}
        </div>

        {/* Navigation Arrows */}
        <button
          onClick={scrollLeft}
          className="absolute left-2 top-1/2 transform -translate-y-1/2 border-2 border-primary bg-gray-100 bg-opacity-30 backdrop-blur-lg text-white p-3 rounded-xl"
        >
          <FiArrowLeft className="text-primary" />
        </button>
        <button
          onClick={scrollRight}
          className="absolute right-2 top-1/2 transform -translate-y-1/2 border-2 border-primary bg-gray-100 bg-opacity-30 backdrop-blur-lg text-white p-3 rounded-xl"
        >
          <FiArrowRight className="text-primary" />
        </button>
      </div>
    </section>
  );
};
