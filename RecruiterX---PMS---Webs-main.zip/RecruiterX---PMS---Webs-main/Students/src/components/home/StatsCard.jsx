import React from "react";

const StatsCard = () => {
  return (
    <div className="p-4 w-full mx-auto space-y-6 bg-gradient-to-r  rounded-lg ">
      <h1 className="text-center text-4xl font-extrabold tracking-wide text-white sm:text-5xl capitalize">
      About Us
      </h1>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
        {/* Registered Students */}
        <div className="flex items-center p-4 bg-white rounded-xl ">
          <div className="flex-shrink-0 bg-indigo-200 p-2 rounded-2xl text-indigo-600 text-4xl mr-4">
            <span className="material-symbols-outlined">check_circle</span>
          </div>
          <div>
            <h3 className="text-gray-800 text-2xl font-semibold">
              Registered Students
            </h3>
            <p className="text-gray-600 text-lg font-medium">25,000+</p>
          </div>
        </div>

        {/* Student Selections */}
        <div className="flex items-center p-4 bg-white rounded-xl ">
          <div className="flex-shrink-0 bg-pink-200 p-2 rounded-2xl text-green-600 text-4xl mr-4">
            <span className="material-symbols-outlined">emoji_events</span>
          </div>
          <div>
            <h3 className="text-gray-800 text-2xl font-semibold">
              Schools & Instituion
            </h3>
            <p className="text-gray-600 text-lg font-medium">12+</p>
          </div>
        </div>

        {/* Tests Attempted */}
        <div className="flex items-center p-4 bg-white rounded-xl ">
          <div className="flex-shrink-0 bg-fuchsia-200 p-2 rounded-2xl text-red-600 text-4xl mr-4">
            <span className="material-symbols-outlined">assessment</span>
          </div>
          <div>
            <h3 className="text-gray-800 text-2xl font-semibold">
             Efficiency increased
             
            </h3>
            <p className="text-gray-600 text-lg font-medium">60% +</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StatsCard;
