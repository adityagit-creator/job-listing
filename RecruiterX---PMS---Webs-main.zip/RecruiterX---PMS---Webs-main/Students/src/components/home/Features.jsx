import React from "react";
import { Link } from "react-router-dom";

const features = [
  "Talent Pool Management",
  "Candidate Screening",
  "Job Posting",
  "Interview Scheduling",
  "Applicant Tracking",
  "Background Verification",
  "Onboarding Assistance",
  "Employer Branding",
  "Analytics & Reporting",
  "Compliance Management",
  "Recruitment Marketing",
];

const Features = () => {
  return (
    <div className="flex justify-center items-center mt-4">
      <div className="card max-w-5xl w-full">
        <p className="mb-5 text-center text-4xl font-bold uppercase tracking-wider lg:text-5xl">
          Features
        </p>
        <ul className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {features.map((feature, index) => (
            <li
              key={index}
              className="flex items-center space-x-4 card px-4 py-2 rounded-md"
            >
              <span className="text-green-400 text-3xl">🔍</span>
              <span className="text-gray-800 text-2xl font-semibold">
                {feature}
              </span>
            </li>
          ))}
        </ul>
        <Link to="/pricing">
          <button className="bg-primary text-white font-semibold w-full mt-6 py-3 rounded-md hover:bg-violet-800 transition duration-200">
            Get Started Now
          </button>
        </Link>
      </div>
    </div>
  );
};

export default Features;
