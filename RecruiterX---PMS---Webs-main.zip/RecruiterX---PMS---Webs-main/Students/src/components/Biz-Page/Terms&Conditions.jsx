import React from "react";
import Footer from "../common/Footer";

function TermsConditions() {
  return (
    <div>
      <div className=" flex flex-col mt-24">
        <div className="max-w-5xl mx-auto  p-8 my-8">
          <h2 className="text-2xl font-bold mb-4">Terms and Conditions</h2>

          <h3 className="text-lg font-semibold mb-2">
            1. Service/Product Details & User Responsibilities
          </h3>
          <p className="text-primary dark:text-white mb-6">
            SchoolX Exams Pvt. Ltd. provides a platform for peer-to-peer heavy
            machine sharing and rental services. Users are responsible for
            accurately representing their machinery, adhering to rental
            agreements, and ensuring proper usage and maintenance.
          </p>

          <h3 className="text-lg font-semibold mb-2">
            2. Payment Terms, Usage Restrictions & Intellectual Property
            Ownership
          </h3>
          <p className="text-primary dark:text-white mb-6">
            Users agree to pay the specified rental fees for the duration of
            machine usage. Usage restrictions include but are not limited to
            unauthorized modifications, subleasing, or illegal activities.
            SchoolX Exams retains ownership of all intellectual property rights
            associated with the platform.
          </p>

          <h3 className="text-lg font-semibold mb-2">
            3. Limitations of Liability
          </h3>
          <p className="text-primary dark:text-white mb-6">
            SchoolX Exams Pvt. Ltd. is not liable for any damages or losses
            resulting from the use of the platform or rented machinery. Users
            agree to indemnify and hold harmless SchoolX Exams from any claims,
            liabilities, or expenses arising from their use of the service.
          </p>

          <h3 className="text-lg font-semibold mb-2">
            4. Dispute Resolution Procedures
          </h3>
          <p className="text-primary dark:text-white mb-6">
            Any disputes arising between users and SchoolX Exams will be resolved
            through negotiation and mediation. In the event that mediation
            fails, disputes will be settled through binding arbitration in
            accordance with the laws of India.
          </p>

          <p className="text-primary dark:text-white">
            By using the SchoolX Exams platform, users agree to abide by these
            Terms and Conditions.
          </p>
         
        </div>

        <div className="max-w-5xl mx-auto  p-8 my-8 mt-[380px]">
        <div className="flex items-center justify-center container">
            <div className=" ">
              <div className="mb-[64px]">
                <h5 className="mb-6 text-center text-xl">COOKIES POLICY </h5>
                <div>
                  <div className="mb-2">
                    A cookie itself does not contain personal information and it
                    will only enable Us to relate Your use of the Platform and
                    Your behaviour on the Platform to information that You have
                    specifically and knowingly provided. The only personal
                    information that a cookie can contain is the information You
                    supply to the cookie. A cookie can’t read data off Your hard
                    disk or read cookie files created by other websites.
                  </div>
                  <div className="mb-2">
                    We may place both permanent and temporary cookies. A
                    permanent cookie will remain on Your web browser until its
                    expiry date, unless deleted prior to such expiry date.
                    However, most cookies are “session cookies” meaning that
                    they automatically get deleted from your computer system at
                    the end of the session. You can refuse cookies by turning
                    them off in Your browser or alternatively You can also set
                    your browser to warn You before accepting any cookies.
                    Therefore, You are always free to decline Our cookies if
                    Your browser permits, however We use certain cookies to
                    authenticate Users on each page after the User logs on to
                    the Platform or accesses any Services. If you, as a casual
                    visitor, have inadvertently browsed any other page of this
                    Platform prior to reading this Privacy Policy, and you do
                    not agree with the manner in which such information is
                    obtained, collected, processed, stored, used, disclosed or
                    retained, merely quitting this browser application should
                    ordinarily clear all temporary cookies installed by Us. All
                    visitors, however, are encouraged to use the “clear cookies”
                    functionality of their browsers to ensure such clearing /
                    deletion, as We cannot guarantee, predict or provide for the
                    behaviour of the equipment of all the visitors of the
                    Platform. Please note that You are not a casual visitor if
                    you have willingly submitted any personal information or
                    information to Us through any means, including email, post
                    or through the registration process on the Platform. All
                    such visitors will be deemed to be, and will be treated as
                    Users for the purposes of this Privacy Policy, and in which
                    case, this Privacy Policy applies in its entirety to such
                    persons.
                  </div>
                  <div className="mb-2">
                    The data that cookies collect will be used to process and/or
                    analyse information by third parties to help improve or
                    facilitate Our services, to provide Service on Our behalf,
                    to Platform-related services, including but not limited to;
                    maintenance services; fraud detection services; database
                    management; web analytics; monitoring; and evaluation
                    services. If you have any questions about Our cookie usage,
                    please contact Us at the contact details/information
                    mentioned below.
                  </div>
                </div>
              </div>
              <div className="mb-[64px]">
                <h5 className="mb-6 text-center text-xl">
                  COLLECTION AND USE OF NON-PERSONAL DATA
                </h5>
                <div>
                  <div>
                    Non-personal data is data that can never be used to identify
                    an individual. We may collect information regarding customer
                    activities on Our Platform. This aggregated information
                    shall be used by Us in research, analysis, to improve and
                    monitor Our services and for various promotional schemes and
                    offers. Such non personal data may be shared in aggregated,
                    non-personal form with third party to enhance customer
                    experience, offerings or services. The Platform uses
                    cookies, and while using the Platform You will be prompted
                    to accept all cookies. We may place text files in the
                    browser files of Your computer system.
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default TermsConditions;
