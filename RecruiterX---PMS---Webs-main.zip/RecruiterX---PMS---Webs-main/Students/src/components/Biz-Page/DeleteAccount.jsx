import { collection, query, where, getDocs, doc, deleteDoc } from 'firebase/firestore';
import React, { useState } from 'react';

import { db } from '../../contexts/FirebaseConfig';

const AccountDelete = () => {
  const [mobileNumber, setMobileNumber] = useState('');
  const [userDetails, setUserDetails] = useState(null);
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSearchSubmit = async (e) => {
    e.preventDefault();
    setErrorMessage('');
    setSuccessMessage('');
    setIsLoading(true);

    try {
      const q = query(collection(db, 'users'), where('phonenumber', '==', mobileNumber));
      const querySnapshot = await getDocs(q);

      if (!querySnapshot.empty) {
        const userData = querySnapshot.docs[0].data();
        setUserDetails({ id: querySnapshot.docs[0].id, ...userData });
      } else {
        setErrorMessage('No user found with the provided mobile number.');
      }
    } catch (error) {
      console.error('Error searching user:', error);
      setErrorMessage('There was an error finding the user.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteUser = async () => {
    setIsLoading(true);
    setSuccessMessage('');
    setErrorMessage('');

    try {
      await deleteDoc(doc(db, 'users', userDetails.id));
      setSuccessMessage(`User ${userDetails.username} deleted successfully.`);
      setUserDetails(null);
    } catch (error) {
      console.error('Error deleting user:', error);
      setErrorMessage('There was an error deleting the user.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="bg-secondary flex min-h-screen flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className=" px-4 py-8 shadow sm:rounded-lg sm:px-10">
          <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">
            Request Account Delete
          </h2>

          <form className="mt-8 space-y-6" onSubmit={handleSearchSubmit}>
            <div>
              <label className="block text-sm font-medium text-gray-700" htmlFor="mobile-number">
                Mobile Number
              </label>
              <input
                required
                className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 sm placeholder:text-gray-400 focus:border-indigo-500 focus:outline-none focus:ring-indigo-500 sm:text-sm"
                id="mobile-number"
                name="mobile-number"
                type="text"
                value={mobileNumber}
                onChange={(e) => setMobileNumber(e.target.value)}
              />
            </div>
            <div>
              <button
                className="flex w-full justify-center rounded-md border border-transparent bg-indigo-600 px-4 py-2 text-sm font-medium text-white sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
                disabled={isLoading}
                type="submit"
              >
                {isLoading ? 'Searching...' : 'Search User'}
              </button>
            </div>
          </form>

          {/* User details section */}
          {userDetails && (
            <div className="mt-6" id="user-details">
              <h3 className="text-lg font-medium leading-6 text-gray-900">
                Are you sure you want to delete user {userDetails.username}?
              </h3>
              <div className="mt-4">
                <button
                  className="flex w-full justify-center rounded-md border border-transparent bg-red-600 px-4 py-2 text-sm font-medium text-white sm hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2"
                  disabled={isLoading}
                  onClick={handleDeleteUser}
                >
                  {isLoading ? 'Deleting...' : 'Delete User'}
                </button>
              </div>
            </div>
          )}

          {/* Success and Error Messages */}
          {successMessage && <div className="mt-6 text-green-600">{successMessage}</div>}
          {errorMessage && <div className="mt-6 text-red-600">{errorMessage}</div>}
        </div>
      </div>
    </div>
  );
};

export default AccountDelete;
