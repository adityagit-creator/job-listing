/* eslint-disable tailwindcss/no-custom-classname */
/* eslint-disable jsx-a11y/anchor-has-content */
import { useState } from "react";

import Footer from "../common/Footer";

function Contact() {
  // State to handle form input
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(null);
  const [submitError, setSubmitError] = useState(null);

  // Handle input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSubmitSuccess(null);
    setSubmitError(null);

    try {
      // Mock API integration, replace with Razorpay or custom API
      const response = await fetch("/api/contact-us", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        throw new Error("Something went wrong.");
      }

      // Reset form data and show success message
      setFormData({ name: "", email: "", message: "" });
      setSubmitSuccess("Your message has been successfully sent!");
    } catch (error) {
      setSubmitError("Error sending message. Please try again later.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div>
      <div className="animate-reveal mx-auto flex w-[85%] flex-col items-center justify-center">
        <h1 className="page-heading">Contact Us</h1>
        <div className="my-12">
          <div className="flex sm:flex-row flex-col gap-4">
            <div className="address mt-6">
              <p className="text-lg font-semibold">Address</p>

              <p className="whitespace-wrap">
                C Block Richard Complex, No 51 TTK Road,
              </p>
              <p className="whitespace-wrap">
                Royapettah, Chennai, India – 600 014{" "}
              </p>
            </div>

            <div className="email-phone mt-6">
              <p className="text-lg font-semibold">Contact Us For Queries</p>
              <p className="whitespace-wrap">Email: growwto@gmail.com</p>
              <p className="whitespace-wrap">Phone: +91 6374380946</p>
            </div>
          </div>
        </div>

        <div className="card flex !w-full max-w-4xl flex-col gap-10 p-6 text-justify font-medium sm:w-3/5 sm:text-xl dark:text-red-300">
          <p className="indent-10 first-letter:text-xl sm:first-letter:text-2xl dark:text-gray-300">
            We would love to hear from you! Please reach out to us using the
            form below, and we will get back to you as soon as possible.
          </p>

          <form className="space-y-6" onSubmit={handleSubmit}>
            {/* Name Field */}
            <div>
              <label
                className="block text-lg font-medium dark:text-gray-300"
                htmlFor="name"
              >
                Name
              </label>
              <input
                required
                className="dark:bg-dark w-full rounded border p-2 dark:text-gray-300"
                id="name"
                name="name"
                type="text"
                value={formData.name}
                onChange={handleChange}
              />
            </div>

            {/* Email Field */}
            <div>
              <label
                className="block text-lg font-medium dark:text-gray-300"
                htmlFor="email"
              >
                Email
              </label>
              <input
                required
                className="dark:bg-dark w-full rounded border p-2 dark:text-gray-300"
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
              />
            </div>

            {/* Message Field */}
            <div>
              <label
                className="block text-lg font-medium dark:text-gray-300"
                htmlFor="message"
              >
                Message
              </label>
              <textarea
                required
                className="dark:bg-dark w-full rounded border p-2 dark:text-gray-300"
                id="message"
                name="message"
                rows="4"
                value={formData.message}
                onChange={handleChange}
              />
            </div>

            {/* Submit Button */}
            <button
              className={`w-full rounded py-2 font-bold text-white ${
                isSubmitting
                  ? "bg-gray-400"
                  : "bg-primary hover:bg-primary-dark"
              }`}
              disabled={isSubmitting}
              type="submit"
            >
              {isSubmitting ? "Submitting..." : "Submit"}
            </button>

            {/* Success/Failure Message */}
            {/* {submitSuccess && <p className="mt-4 font-semibold text-green-500">{submitSuccess}</p>}
            {submitError && <p className="mt-4 font-semibold text-red-500">{submitError}</p>} */}
          </form>
        </div>

        <span className="mt-14 block font-semibold tracking-wide">
          Developed with
          <a
            className="cursor-pointer hover:underline"
            href="https://SchoolX Exams.com"
            rel="noreferrer"
            target="_blank"
          >
            💚
          </a>
        </span>

        <div className=" mt-8 inline-flex w-full items-center justify-center">
          <hr className="bg-primary dark:bg-secondary my-8 h-1 w-64 rounded border-0" />
          <div className="bg-light dark:bg-dark absolute left-1/2 -translate-x-1/2 px-4">
            <svg
              aria-hidden="true"
              className="size-5 text-gray-700 dark:text-gray-300"
              fill="none"
              viewBox="0 0 24 27"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M14.017 18L14.017 10.609C14.017 4.905 17.748 1.039 23 0L23.995 2.151C21.563 3.068 20 5.789 20 8H24V18H14.017ZM0 18V10.609C0 4.905 3.748 1.038 9 0L9.996 2.151C7.563 3.068 6 5.789 6 8H9.983L9.983 18L0 18Z"
                fill="currentColor"
              />
            </svg>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}

export default Contact;
