import React from "react";
import Footer from "../common/Footer";

function RefundPolicies() {
  return (
    <div className="  ">
      <div className="max-w-5xl mx-auto  p-8 my-8">
        <h2 className="text-2xl font-bold mb-4">
          Refund & Cancellation Policy
        </h2>

        <h3 className="text-lg font-semibold mb-2">
          1. Refund Eligibility and Timeframes
        </h3>
        <p className="text-primary dark:text-white mb-6">
          Customers may be eligible for a refund if they cancel their order
          within a specified timeframe, typically 24 hours before the scheduled
          rental period. Refunds will be processed within 5-7 business days via
          the original payment method.
        </p>

        <h3 className="text-lg font-semibold mb-2">
          2. Return/Replace Request Process
        </h3>
        <p className="text-primary dark:text-white mb-6">
          To request a refund or cancellation, customers must contact our
          support team via email at growwto@gmail.com or by calling our
          customer service hotline at +91 6374380946. Our team will guide
          customers through the process and assist with any necessary
          documentation.
        </p>

        <h3 className="text-lg font-semibold mb-2">
          3. Non-Refundable/Non-Cancellable Products or Services
        </h3>
        <p className="text-primary dark:text-white mb-6">
          Certain products or services may be non-refundable or non-cancellable,
          as indicated at the time of purchase. This may include customized or
          special-order items, as well as services that have already been
          rendered.
        </p>

        <h3 className="text-lg font-semibold mb-2">
          4. Cancellation Procedures, Fees, and Requirements
        </h3>
        <p className="text-primary dark:text-white mb-6">
          Customers can cancel their order without incurring any fees if done
          within the specified cancellation window. However, cancellations made
          outside of this timeframe may be subject to cancellation fees,
          depending on the circumstances.
        </p>

        <p className="text-primary dark:text-white">
          For further assistance or inquiries regarding refunds and
          cancellations, please contact our customer support team.
        </p>
      </div>
      <Footer />
    </div>
  );
}

export default RefundPolicies;
