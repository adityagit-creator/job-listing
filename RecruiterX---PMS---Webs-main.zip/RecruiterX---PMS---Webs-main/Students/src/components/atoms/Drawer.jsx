import { useState } from 'react';

function ExpandableContent({ className, title, content }) {
  const [display, setDisplay] = useState(false);

  return (
    <button
      className={`card mb-6 w-full py-2 ${className}`}
      onClick={() => setDisplay((prevState) => !prevState)}
    >
      <span className="flex items-center">
        <span className="material-symbols-outlined mr-2 text-2xl text-primary dark:text-[#ffffff]">
          description
        </span>
        <span className="text-xl font-semibold uppercase text-primary dark:text-[#ffffff]">
          {title}
        </span>
        <span
          className={`material-symbols-outlined ml-auto text-3xl text-primary transition-transform duration-300 dark:text-[#ffffff] ${
            display && 'rotate-45'
          }`}
        >
          add
        </span>
      </span>
      {display && (
        <>
          <hr className="my-3 h-px border-0 bg-primary" />
          <div className="ml-6 text-left text-lg">
            {Array.isArray(content) ? (
              <ol className="list-disc">
                {content.map((item, index) => (
                  <li key={index} className="mb-1">
                    {item}
                  </li>
                ))}
              </ol>
            ) : (
              <p>{content}</p>
            )}
          </div>
        </>
      )}
    </button>
  );
}

export default ExpandableContent;
