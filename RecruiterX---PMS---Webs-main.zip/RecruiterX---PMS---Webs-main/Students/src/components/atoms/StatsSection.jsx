import React from "react";

const StatsSection = ({ stats }) => {
  return (
    <section className="py-2">
      <div className="mx-auto">
        <div className="flex flex-col flex-1 gap-5 lg:gap-0 lg:flex-row lg:justify-between">
          {stats.map((stat, index) => (
            <div
              key={index}
              className={`w-full lg:w-1/4 ${
                index < stats.length - 1 ? "border-b lg:border-b-0 lg:border-r border-gray-100" : ""
              }`}
            >
              <div className={`font-manrope font-bold text-5xl text-center ${stat.color}`}>
                {stat.count}
              </div>
              <span className={`text-xl text-gray-500 dark:text-gray-200 text-center block`}>{stat.title}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default StatsSection;
