import { IoNotifications } from "react-icons/io5";

export const MovingTextWithDiamond = () => {
  // Sample job notifications for the demonstration
  const texts = [
    "New Job Opening: Software Engineer at ACME Corp",
    "Hiring Event: Tech Career Fair on 15th June",
    "Job Alert: Data Analyst role at XYZ Analytics",
    "Career Opportunity: Product Manager at Startup Hub",
    "Stay Updated: Latest Job Openings and Career Events!"
  ];

  return (
    <div className="relative overflow-hidden w-full max-w-full h-20 bg-primary flex items-center">
      <div className="flex animate-marquee">
        {texts.concat(texts).map((text, index) => (
          <div
            key={index}
            className="flex items-center justify-center gap-5 px-4"
          >
            <span className="text-white text-xl font-medium">{text}</span>
            <IoNotifications className="text-white text-2xl" />
          </div>
        ))}
      </div>
    </div>
  );
};