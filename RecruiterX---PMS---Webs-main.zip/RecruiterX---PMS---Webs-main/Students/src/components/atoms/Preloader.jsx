import { logo} from "../../assets";
import "./loader.css";

function Preloader() {
  return (
    <div className="bg-light dark:bg-dark absolute left-0 top-0 flex h-screen w-screen flex-col items-center justify-center">
      <img
        alt="SchoolX Exams"
        className="w-42 animate-fade-upwards opacity-0 rounded-3xl"
        loading="lazy"
        src={logo}
      />

     

      <div className="mt-4 h-2 w-3/4 rounded bg-gray-200 md:w-1/2 dark:bg-gray-700">
        <div
          className="bg-primary dark:bg-primary animate-progress h-2 rounded"
          style={{ width: "0%" }}
        ></div>
      </div>
    </div>
  );
}

export default Preloader;
