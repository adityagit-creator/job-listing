import { useState } from "react";

import { placeholder } from "../../assets";

function Thumbnail({ title, link }) {
  const [imageLoaded, setImageLoaded] = useState(false);

  return (
    <div
      className="card max-w-lg cursor-pointer rounded-lg border-2 transition-all duration-300 hover:border-primary"
      title={title}
    >
      <div className="card relative aspect-video w-full overflow-hidden rounded-lg p-0">
        <img
          alt="SchoolX Exams"
          className="h- w-full animate-reveal object-cover"
          loading="lazy"
          src={link}
          onError={({ currentTarget }) => {
            currentTarget.onerror = null;
            currentTarget.src = placeholder;
          }}
          onLoad={() => setImageLoaded(false)}
        />
        {!imageLoaded && (
          <img alt="" className="size-full object-cover" src={placeholder} />
        )}
      </div>
      <div className={"flex h-28 flex-col justify-between gap-1"}>
        <p className="mt-1 line-clamp-2 overflow-hidden text-center font-semibold uppercase tracking-wide text-black dark:text-slate-300 sm:text-lg">
          {title}
        </p>
        <div className="flex items-center justify-center rounded-lg border-2 border-black/10 px-3 py-1 text-sm font-medium text-black drop-md dark:border-white/10 dark:text-slate-300 sm:text-base">
          View Years
        </div>
        {/* {type === 'quiz' && (
        
        )} */}
        {/* {type === 'popularQuiz' && (
          
        )} */}
      </div>
    </div>
  );
}

export default Thumbnail;
