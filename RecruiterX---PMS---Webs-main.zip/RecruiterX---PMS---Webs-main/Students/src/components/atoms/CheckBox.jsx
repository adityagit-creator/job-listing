function CheckBox({ className, text, feedback, ...rest }) {
  return (
    <label className={`flex items-center gap-2 ${className}`}>
      <input
        className="hidden mr-2 h-5 w-5 cursor-pointer accent-primary"
        type="checkbox"
        {...rest}
      />
      <span className="w-full select-none text-black dark:text-white">{text}</span>
      {/* Add feedback inside the checkbox */}
      {feedback && (
        <span
          className={`ml-auto text-sm font-semibold ${
            feedback === 'Correct' ? 'text-green-600' : feedback === 'Wrong' ? 'text-red-600' : ''
          }`}
        >
          {feedback}
        </span>
      )}
    </label>
  );
}

export default CheckBox;
