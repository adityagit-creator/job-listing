import { useAuth } from '../../contexts/AuthContext';


function ScoreCard({
  noq,
  correctAnswersCount,
  incorrectAnswersCount,
  unattemptedCount,
}) {
 // Calculate obtained points and percentage
 const calculateScore = (correctAnswers, totalQuestions, pointsPerQuestion = 10) => {
  const obtainedPoints = correctAnswers * pointsPerQuestion;
  const obtainedPercentage = Math.min(
    Math.max((obtainedPoints / (totalQuestions * pointsPerQuestion)) * 100, 0),
    100
  );
  return { obtainedPoints, obtainedPercentage };
};

const { obtainedPoints, obtainedPercentage } = calculateScore(correctAnswersCount, noq);

// Calculate total attempted questions

  return (
    <div className="card mx-auto flex flex-col rounded-xl lg:w-[500px]">
      {/* <span className="mb-2 w-full text-center text-4xl font-semibold uppercase tracking-wider text-black drop-xl dark:text-white lg:text-5xl">
        Score Card
      </span> */}
      <span className="mb-4 w-full text-center text-3xl font-bold text-primary drop-xl dark:text-white lg:text-4xl">
        SCORE {obtainedPercentage.toFixed(2)}%
      </span>
      <hr className="mb-6 h-px border-0 bg-gray-400 dark:bg-gray-600" />

      <div className="[&>*]:text-lg [&>*]:lg:text-2xl">
        <div className="score-row [&>*]:text-black [&>*]:dark:text-white">
          <p className="text-left">Answers</p>
          <p></p>
          <p>Points</p>
        </div>

        <div className="score-row [&>*]:text-green-500">
          <p className="text-left">Correct</p>
          <p></p>
          <p>{correctAnswersCount}</p>
        </div>

        <div className="score-row [&>*]:text-red-500">
          <p className="text-left">Incorrect</p>
          <p></p>
          <p>{incorrectAnswersCount}</p>
        </div>

        <div className="score-row [&>*]:text-gray-500">
          <p className="text-left">Unattempted</p>
          <p></p>
          <p>{unattemptedCount}</p>
        </div>
      </div>
      <hr className="mb-3 mt-4 h-px border-0 bg-gray-400 dark:bg-gray-600" />
      {/* <div className="marks">
        <div className="justify-self-start">Obtained Points</div>
        <div>{obtainedPoints}</div>
      </div> */}
      <div className="marks">
        <div className="justify-self-start">No of Questions</div>
        <div>{noq}</div>
      </div>
     
     
    </div>
  );
}

export default ScoreCard;
