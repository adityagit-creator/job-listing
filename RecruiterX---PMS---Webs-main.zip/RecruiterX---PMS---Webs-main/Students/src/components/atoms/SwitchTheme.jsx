import { useEffect, useState } from 'react';

function SwitchTheme() {
  const [theme, setTheme] = useState(
    localStorage.getItem('theme') === 'dark' ||
    (!localStorage.getItem('theme') && window.matchMedia('(prefers-color-scheme: dark)').matches)
      ? 'dark'
      : 'light'
  );

  function toggleTheme() {
    setTheme((prevTheme) => (prevTheme === 'dark' ? 'light' : 'dark'));
  }

  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  }, [theme]);

  return (
    <button className="flex items-center" title="Toggle Theme" type="button" onClick={toggleTheme}>
      {theme === 'dark' ? (
        <span className="material-symbols-outlined text-2xl xl:ml-2 xl:text-4xl" title="Light Mode">
          light_mode
        </span>
      ) : (
        <span
          className="material-symbols-outlined text-2xl text-primary xl:ml-2 xl:text-4xl"
          title="Dark Mode"
        >
          dark_mode
        </span>
      )}
    </button>
  );
}

export default SwitchTheme;
