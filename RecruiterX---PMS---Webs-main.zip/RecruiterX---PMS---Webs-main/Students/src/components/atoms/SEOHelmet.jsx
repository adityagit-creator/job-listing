// SEOHelmet.js
import { Helmet } from "react-helmet";

const SEOHelmet = ({ title, description, keywords, lang = "en" }) => {
  const defaultTitle = "SchoolX Exams - Government Exam Preparation | Quizzes, PYQs, Flashcards & More"; // Default title for your website
  const defaultDescription =
    "SchoolX Exams: Your one-stop platform for government exam preparation. Get access to quizzes, flashcards, previous year questions (PYQs), and smart learning tools. Prepare easily for exams with simple plans, expert content, and many practice tests to help you succeed. Exams SchoolX is the best platform for preparing for government exams. Access quizzes, flashcards, previous year questions (PYQs), and smart tools to make studying easy. Get expert guidance, simple study plans, and practice tests to boost your confidence and pass your exams successfully. Learn faster, practice smarter, and achieve your government job goals with SchoolX Exams.";
  const defaultKeywords =
    "SchoolX Exams, Government Exam Quiz Platform, PYQs, Competitive Exam Preparation Hub, Study Tools for Government Exams, Online Practice Tests, Adaptive Quizzes, Government Exam Resources, Personalized Study Plans, Flashcards for Government Exams, Exam Revision Tools, General Knowledge Quizzes, AI-Based Exam Prep, Exam Learning Platform, Preparation Strategies, Competitive Exam Tips, Exam Notification 2025, Practice Question Bank, General Awareness Practice, Aptitude Test Prep, Reasoning Test Resources, All Government Exams, TNPSC, Group I Exams, Group II Exams, Group IV Exams, SSC, RRB, UPSC, IBPS, TNPSC 2025, SSC CGL 2025, RRB NTPC 2025, IBPS PO 2025 ,SchoolX Exams, Government Exams, Exam Quiz Platform, PYQs, Previous Year Questions, Competitive Exams Hub, Study Tools, Online Exam Practice, Mock Tests, Adaptive Quizzes, Exam Resources, Study Plans, Flashcards, Exam Revision, General Knowledge, AI Exam Prep, Exam Learning, Easy Exam Preparation, Exam Tips, Practice Questions, General Awareness, Aptitude Tests, Reasoning Practice, All Exams, Government Jobs, TNPSC, Group Exams, SSC CGL, RRB NTPC, UPSC, IBPS PO, SSC Exams, Bank Exams, Railway Exams, TNPSC Preparation, Simple Exam Prep, Affordable Study Tools, Online Coaching, Exam Notifications, Practice Tests, GK Quizzes, Logical Reasoning, Current Affairs, All Competitive Exams, Fast Exam Prep, Learn for Exams, Online Mock Tests";

  return (
    <Helmet>
      {/* Title Tag */}
      <title>{title || defaultTitle}</title>

      {/* Meta Description */}
      <meta name="description" content={description || defaultDescription} />

      {/* Meta Keywords */}
      <meta name="keywords" content={keywords || defaultKeywords} />

      {/* Open Graph meta tags for social media sharing */}
      <meta property="og:title" content={title || defaultTitle} />
      <meta
        property="og:description"
        content={description || defaultDescription}
      />
      <meta property="og:type" content="website" />

      {/* Twitter Card meta tags */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={title || defaultTitle} />
      <meta
        name="twitter:description"
        content={description || defaultDescription}
      />

      {/* Language */}
      <html lang={lang} />
    </Helmet>
  );
};

export default SEOHelmet;
