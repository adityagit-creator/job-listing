import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { IoMdClose } from "react-icons/io";
import {
  FaUserCircle,
  FaBriefcase,
  FaClipboardList,
  FaGraduationCap,
  FaChalkboardTeacher,
  FaBell,
  FaFile
} from "react-icons/fa";
import { Menu } from "./Icons";

const Navigator = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const location = useLocation();

  const toggleModal = () => {
    setIsModalOpen(!isModalOpen);
  };

  const menuItems = [
    { to: "/profile", label: "Profile", icon: <FaUserCircle /> },
    { to: "/jobs", label: "Jobs", icon: <FaBriefcase /> },
    { to: "/applications", label: "Applications", icon: <FaClipboardList /> },
    { to: "/assessments", label: "Assessments", icon: <FaGraduationCap /> },
    { to: "/interview-prep", label: "Interview Prep", icon: <FaChalkboardTeacher /> },
    { to: "/notifications", label: "Notifications", icon: <FaBell /> },
    { to: "/offers", label: "Offers", icon: <FaFile /> }
  ];

  // Define regex patterns for hidden paths
  const quizPathRegex = /^\/Exam\/[^/]+\/year\/[^/]+\/subject\/[^/]+$/;
  const quizPathRegex1 = /^\/PYQExam\/[^/]+\/year\/[^/]+$/;

  // Check if the current path matches any hidden path pattern
  const isQuizPage =
    quizPathRegex.test(location.pathname) || quizPathRegex1.test(location.pathname);

  return (
    <div className="">
      {!isQuizPage && (
        <div className="fixed rounded-xl bottom-0 right-0 z-40 p-2 m-4">
          <button onClick={toggleModal} className="card p-2 focus:outline-none">
            <Menu />
          </button>
        </div>
      )}

      {/* Modal for Mobile Hamburger Menu */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
          <div className="card w-11/12 sm:w-3/4 md:w-1/3 p-4 max-w-lg">
            <div className="flex justify-between items-center">
              <h2 className="font-semibold text-xl">Menu</h2>
              <button onClick={toggleModal} className="text-2xl">
                <IoMdClose />
              </button>
            </div>
            <div className="mt-4 gap-4 flex flex-col">
              {menuItems.map((item, index) => (
                <Link
                  key={index}
                  to={item.to}
                  className="flex items-center gap-2 py-3 bg-gray-50 border border-gray-200 hover:bg-gray-100 px-4 rounded-md"
                  onClick={toggleModal}
                >
                  {item.icon}
                  <span>{item.label}</span>
                </Link>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Navigator;
